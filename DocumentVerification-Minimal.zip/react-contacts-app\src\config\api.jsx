// API Configuration
const API_BASE_URL = import.meta.env.VITE_API_URL || 'https://localhost:50538/api';

export { API_BASE_URL };

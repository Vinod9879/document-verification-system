﻿# Document Verification System - Minimal Setup

## Prerequisites
- .NET 8 SDK
- Node.js 18+

## Setup Commands

### 1. Backend Setup
cd webApitest
dotnet restore
dotnet build
dotnet run --urls "https://localhost:50538"

### 2. Frontend Setup
cd react-contacts-app
npm install
npm run dev

### 3. Database Setup
cd webApitest
dotnet ef database update

## Access URLs
- Frontend: http://localhost:3000
- Backend: https://localhost:50538
- Swagger: https://localhost:50538/swagger

## Default Login
- Admin: admin@example.com / Admin123!
- User: test@example.com / Test123!

## Project Structure
- webApitest/ - Backend API (.NET Core)
- react-contacts-app/ - Frontend (React + Vite)
- DocumentVerificationDLL/ - Document processing DLL

## Features
- JWT Authentication
- Document upload (PDF/PNG)
- OCR text extraction
- Document verification
- Admin dashboard
- User dashboard

## Security
- File upload validation
- Security headers
- CORS protection
- Rate limiting

Enjoy! ðŸŽ‰

﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using FNF.IPX.Common;

namespace FNF.IPX.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class UserModel : PageBaseModel
    {
        public bool HasValue { get; set; }
        public int UserID { get; set; }

        [Display(Name = "First Name")]
        [Required(ErrorMessage = "First Name is required")]
        [StringLength(50, ErrorMessage = "The {0} cannot exceed {1} characters")]
        [RegularExpression(RegulerExpression.PureStringName, ErrorMessage = "Special characted and numbers are invalid")]
        public string FirstName { get; set; }
        public string FullName { get { return FirstName + " " + LastName; } }

        [Display(Name = "Last Name")]
        [StringLength(50, ErrorMessage = "The {0} cannot exceed {1} characters")]
        [RegularExpression(RegulerExpression.PureStringName, ErrorMessage = "Special characted and numbers are invalid")]
        public string LastName { get; set; }

        [Display(Name = "User Name")]
        [Required(ErrorMessage = "User Name is required")]
        [StringLength(50, ErrorMessage = "The {0} cannot exceed {1} characters")]
        //[RegularExpression(RegulerExpression.PureStringName, ErrorMessage = "Special characted and numbers are invalid")]
        public string UserName { get; set; }

        [Display(Name = "Email Id")]
        [Required(ErrorMessage = "Email Id is required")]
        [StringLength(50, ErrorMessage = "The {0} cannot exceed {1} characters")]
        [RegularExpression(RegulerExpression.Email,ErrorMessage="Please enter a valid email address")]
        public string EMailID { get; set; }

        [Display(Name = "Password")]
        [Required(ErrorMessage = "Password is required")]
        public string Password { get; set; }

        [Display(Name = "Confirm Password")]
        [Required(ErrorMessage = "Confirm Password is required")]
        //[RegularExpression(RegulerExpression.Email, ErrorMessage = "Invalid email format")]
        [Compare("Password",ErrorMessage="Password and confirmation password do not match")]
        [StringLength(20, ErrorMessage = "The {0} must be at least {2} characters long.",MinimumLength=6)]
        public string ConfirmPassword { get; set; }
        public bool? IsActive { get; set; }

        [Display(Name = "Created By")]
        public string CreatedBy { get; set; }

        [Display(Name = "Created Date")]
        public DateTime? CreatedDate { get; set; }

        [Display(Name = "Modified By")]
        public string ModifiedBy { get; set; }

        [Display(Name = "Modified Date")]
        public DateTime? ModifiedDate { get; set; }


        public IList<string> Permission { get; set; }
        //public IList<string> Group { get; set; }

       
        public ICollection<GroupModel> GroupDefaults { get; set; }

        [Required(ErrorMessage = "Group(s) are required.")]
        public List<int> SelectedGroups { get; set; }

        public ICollection<StateModel> StateDefaults { get; set; }
        public List<int> SelectedStates { get; set; }


        public ICollection<FlashCodeModel> FlashCodeDefaults { get; set; }
        public List<int> SelectedFlashCodes { get; set; }

        //public virtual ICollection<OrderHistory> OrderHistory { get; set; }
        //public virtual ICollection<Orders> Orders { get; set; }
        //public virtual ICollection<IGroup> Group { get; set; }
        //public virtual ICollection<States> States { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

namespace FNF.IPX.Models
{
    public class TrackFlagsMasterModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Nullable<int> Priority { get; set; }
    }
}

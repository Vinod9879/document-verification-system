namespace FNF.IPX.Models
{
    using System;
    using System.Collections.Generic;
    
    public partial class PartyContactModel
    {
        public int Id { get; set; }
        public Nullable<int> PartyId { get; set; }
        public Nullable<int> OrderId { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string PersonAddress1 { get; set; }
        public string PersonAddress2 { get; set; }
        public string PersonCity { get; set; }
        public string PersonState { get; set; }
        public string PersonZipCode { get; set; }
        public string PersonWorkPhone { get; set; }
        public string PersonEmail { get; set; }
    
        public virtual OrderDetailsModel OrderDetails { get; set; }
        public virtual PartyModel Party { get; set; }
    }
}

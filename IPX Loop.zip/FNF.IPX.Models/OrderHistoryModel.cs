namespace FNF.IPX.Models
{
    using System;
    using System.Collections.Generic;
    
    public partial class OrderHistoryModel
    {
        public int Id { get; set; }
        public Nullable<int> OrderId { get; set; }
        public string Status { get; set; }
        public string Comments { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedDate { get; set; }
    
        public virtual OrderDetailsModel OrderDetails { get; set; }
    }
}

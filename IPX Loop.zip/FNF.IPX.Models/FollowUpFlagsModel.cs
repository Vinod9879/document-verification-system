﻿using System;
using System.Collections.Generic;

namespace FNF.IPX.Models
{
    public class FollowUpFlagsModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Nullable<int> Priority { get; set; }
        public string UlClass { get; set; }
        public string ButtonClass { get; set; }
    }
}

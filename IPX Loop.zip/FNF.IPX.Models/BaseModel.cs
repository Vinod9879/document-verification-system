﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FNF.IPX.Models
{

  
    public  class  PageBaseModel
    {

        public int PageNumber { get; set; }
        public int PageCount { get; set; }

        public int TotalItemCount { get; set; }
        
        public int PageSize { get; set; }
    }
}

﻿namespace FNF.IPX.Models
{
    using FNF.IPX.Common;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    
    public class OrderMetaArchiveModel
    {
        #region Constants
        public static string RecordCount = "RecordCount";
        public static string RowNumber = "RowNumber";
        public static string Str_OrderID = "Order ID";
        public static string Str_UpdatedDate = "Updated Date";
        public static string Str_SalesRep = "Sales Rep";
        public static string Str_FileNumber = "File Number";
        public static string Str_FollowupFlag = "FollowupFlag";
        public static string Str_UlClass = "UlClass";
        public static string Str_ButtonClass = "ButtonClass";
        public static int Stat_Pagesize = 25;
        public static string Str_TrackingFlag = "Tracking Flag";
        #endregion

        #region Constructor
        public OrderMetaArchiveModel()
        {
            PageIndex = 1;
            Pagesize = 25;
            Sort = Str_UpdatedDate;
            Order = "DESC";
            Headers = new List<string>();
        }
        #endregion

        #region Members
        public List<string> Headers { get; set; }
        public List<IDictionary<string, dynamic>> Results { get; set; }
        public string Sort { get; set; }
        public string Order { get; set; }
        public int PageIndex { get; set; }
        public int Pagesize { get; set; }
        public string Search { get; set; }
        public List<TemplateModel> Templates { get; set; }
        //public int TemplateID { get; set; }

        public OrderDetailsArchiveModel OrderDetails { get; set; }

        public IEnumerable<TrackFlagsMasterModel> TrackingFlags { get; set; }

        #endregion

        #region Methods
        /// <summary>
        /// Reset Page number/index to 1 if it exceeds total page numbers
        /// </summary>
        public void CheckIndex()
        {
            if (PageIndex > Results.Count / Pagesize)
                PageIndex = 1;
        }
        #endregion
    }

    public class OrderDetailsArchiveModel
    {
        #region Properties
        public int OrderID { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Division Name")]
        public string DivisionName { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Flash Code")]
        public string FlashCode { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Flash Name")]
        public string FlashName { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Operation Code")]
        public string OperationCode { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Operation Name")]
        public string OperationName { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Branch Name")]
        public string BranchName { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "File Number")]
        public string FileNumber { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Date Opened")]
        public Nullable<System.DateTime> DateOpened { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Date Closed Source System")]
        public Nullable<System.DateTime> DateClosedSourceSystem { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "DateCanceled")]
        public Nullable<System.DateTime> DateCanceled { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Order Status")]
        public string OrderStatus { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Order Type")]
        public string SettlementType { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Property Type")]
        public string PropertyType { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Property Type Group")]
        public string PropertyTypeGroup { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Transaction Type")]
        public string TransactionType { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Sales Price")]
        public Nullable<decimal> SalesPrice { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Underwriter")]
        public string UnderwriterName { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Production System Type")]
        public string ProductionSystemType { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        public string Comments { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Is Deleted")]
        public Nullable<bool> IsDeleted { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Updated Date")]
        public Nullable<System.DateTime> UpdatedDate { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Follow up")]
        public string FollowupFlag { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Created By")]
        public string CreatedBy { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Created On")]
        public Nullable<System.DateTime> CreatedDate { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Modified By")]
        public string ModifiedBy { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Modified On")]
        public Nullable<System.DateTime> ModifiedDate { get; set; }
        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Source DB")]
        public string SourceDB { get; set; }

        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Source Server")]
        public string SourceServer { get; set; }

        [DisplayFormat(NullDisplayText = GeneralConstants.NotAvailable)]
        [Display(Name = "Marketing Source")]
        public string Marketing_Source { get; set; }
        public string TrackFlag { get; set; }
        #endregion

        public virtual ICollection<LoanDetailsArchiveModel> LoanDetails_Archive { get; set; }
        public virtual ICollection<OrderHistoryArchiveModel> OrderHistory_Archive { get; set; }
        public virtual ICollection<PartyArchiveModel> Party_Archive { get; set; }
        public virtual ICollection<PartyContactArchiveModel> PartyContact_Archive { get; set; }
        public virtual ICollection<PropertyMasterArchiveModel> PropertyMaster_Archive { get; set; }
        public virtual ICollection<SalesRepArchiveModel> SalesRep_Archive { get; set; }
        public virtual ICollection<IPXSalesRepArchiveModel> IPXSalesRep_Archive { get; set; }

        public static bool FindIfContactHasData(PartyContactArchiveModel contact)
        {
            return
                Helpers.NotNullOrEmptyOrStringNULL(contact.FirstName) || Helpers.NotNullOrEmptyOrStringNULL(contact.LastName) ||
                Helpers.NotNullOrEmptyOrStringNULL(contact.PersonAddress1) || Helpers.NotNullOrEmptyOrStringNULL(contact.PersonAddress2) ||
                Helpers.NotNullOrEmptyOrStringNULL(contact.PersonCity) || Helpers.NotNullOrEmptyOrStringNULL(contact.PersonState) ||
                Helpers.NotNullOrEmptyOrStringNULL(contact.PersonZipCode) || Helpers.NotNullOrEmptyOrStringNULL(contact.PersonWorkPhone) ||
                Helpers.NotNullOrEmptyOrStringNULL(contact.PersonEmail);
        }

        public static bool FindIfContactsListHasData(IEnumerable<PartyContactArchiveModel> contactsList)
        {
            foreach (var contact in contactsList)
            {
                if (Helpers.NotNullOrEmptyOrStringNULL(contact.FirstName) || Helpers.NotNullOrEmptyOrStringNULL(contact.LastName) ||
                Helpers.NotNullOrEmptyOrStringNULL(contact.PersonAddress1) || Helpers.NotNullOrEmptyOrStringNULL(contact.PersonAddress2) ||
                Helpers.NotNullOrEmptyOrStringNULL(contact.PersonCity) || Helpers.NotNullOrEmptyOrStringNULL(contact.PersonState) ||
                Helpers.NotNullOrEmptyOrStringNULL(contact.PersonZipCode) || Helpers.NotNullOrEmptyOrStringNULL(contact.PersonWorkPhone) ||
                Helpers.NotNullOrEmptyOrStringNULL(contact.PersonEmail))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
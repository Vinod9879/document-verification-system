namespace FNF.IPX.Models
{
    using System;
    using System.Collections.Generic;

    public partial class LoanDetailsArchiveModel
    {
        public int Id { get; set; }
        public Nullable<int> OrderId { get; set; }
        public Nullable<decimal> LoanAmount { get; set; }

        public virtual OrderDetailsArchiveModel OrderDetails { get; set; }
    }
}

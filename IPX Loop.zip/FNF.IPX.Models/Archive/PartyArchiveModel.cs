namespace FNF.IPX.Models
{
    using System;
    using System.Collections.Generic;

    public partial class PartyArchiveModel
    {    
        public int PartyID { get; set; }
        public Nullable<int> OrderId { get; set; }
        public string PartyName { get; set; }
        public string PartyType { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public string CellPhone { get; set; }
        public string WorkPhone { get; set; }
        public string Email { get; set; }

        public virtual OrderDetailsArchiveModel OrderDetails { get; set; }
        public virtual ICollection<PartyContactArchiveModel> PartyContactArchive { get; set; }
    }
}

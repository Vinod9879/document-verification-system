﻿using FNF.IPX.Common;
using System.ComponentModel.DataAnnotations;

namespace FNF.IPX.Models
{
   

    public class LoginViewModel
    {

        [Required]
        [Display(Name = "User name")]
        public string UserName { get; set; }


        [Display(Name = "Email ID")]
        //[RegularExpression(RegulerExpression.Email, ErrorMessage = "Email format is invalid.")]
        public string EMailID { get; set; }
        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [Display(Name = "Remember me?")]
        public bool RememberMe { get; set; }
    }

    public class ChangePasswordViewModel
    {

        public int userId { get; set; }
        
        [Display(Name = "User name")]
        public string UserName { get; set; }

       
        [Display(Name = "Email Id")]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }


        [Required]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Password is not matching")]
        [Display(Name = "Confirm Password")]
        public string ConfirmPassword { get; set; }

       
    }


}

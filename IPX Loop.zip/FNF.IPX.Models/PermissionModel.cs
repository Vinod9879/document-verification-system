﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FNF.IPX.Models
{
  

    public partial class PermissionModel
    {
      

        public int Id { get; set; }
        public string Name { get; set; }
        public string Module { get; set; }
        public string Description { get; set; }
        public Nullable<bool> IsPrimary { get; set; }
        public Nullable<bool> IsActive { get; set; }

        //public virtual ICollection<GroupMaster> GroupMaster { get; set; }
    }
}

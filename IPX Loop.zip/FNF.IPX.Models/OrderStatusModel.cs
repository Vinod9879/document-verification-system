﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FNF.IPX.Models
{
    public class OrderStatusModel
    {
        public int Id { get; set; }
        public string Status { get; set; }
        public int Priority { get; set; }
        public Nullable<bool> IsOpenStatus { get; set; }
    }
}

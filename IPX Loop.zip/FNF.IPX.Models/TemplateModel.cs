﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace FNF.IPX.Models
{
    public class TemplateModel:PageBaseModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required.")]
        [StringLength(50, ErrorMessage = "The {0} cannot exceed {1} characters")]
        public string Name { get; set; }

     

        public bool?  IsActive { get; set; }


        [Display(Name = "Created By")]
        public string CreatedBy { get; set; }

        [Display(Name = "Created Date")]
        public DateTime? CreatedDate { get; set; }

        [Display(Name = "Modified By")]
        public string ModifiedBy { get; set; }

        [Display(Name = "Modified Date")]
        public DateTime? ModifiedDate { get; set; }

        public virtual ICollection<HeaderModel> DefaultHeaders { get; set; }

        [Required(ErrorMessage = "Header(s) are required.")]
        public virtual List<int> SelectedHeaders { get; set; }
        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FNF.IPX.Models
{
    public class PagingParm
    {
        Dictionary<string, string> _filterColumnNameValue;

        public PagingParm()
        {
            _filterColumnNameValue = new Dictionary<string, string>();
            SortColumns = new Dictionary<string, string>();
        }
        public Dictionary<string, string> FilterColumnNameValue
        {
            get { return _filterColumnNameValue; }
            set {
                _filterColumnNameValue = value;
            PageNumber = 1;
        } }
        public Dictionary<string, string> SortColumns { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace FNF.IPX.Models
{
    public class GroupModel : PageBaseModel
    {
        public GroupModel()
        {
        }

        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required.")]
        [StringLength(50, ErrorMessage = "The {0} cannot exceed {1} characters")]
        public string Name { get; set; }
        [StringLength(50, ErrorMessage = "The {0} cannot exceed {1} characters")]
        public string Description { get; set; }
        public bool? IsActive { get; set; }

        [Display(Name = "Created By")]
        public string CreatedBy { get; set; }

        [Display(Name = "Created Date")]
        public DateTime? CreatedDate { get; set; }

        [Display(Name = "Modified By")]
        public string ModifiedBy { get; set; }

        [Display(Name = "Modified Date")]
        public DateTime? ModifiedDate { get; set; }


        public ICollection<TemplateModel> DeafiltTemplates { get; set; }

        [Required(ErrorMessage = "Template(s) are required.")]
        public List<int> SelectedTemplates { get; set; }


        public ICollection<PermissionModel> DefaultPermission { get; set; }
        public List<int> SelectedPermission { get; set; }


    }


}

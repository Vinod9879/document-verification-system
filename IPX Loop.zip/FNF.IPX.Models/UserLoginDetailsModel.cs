﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FNF.IPX.Models
{
    public class UserLoginDetailsModel : PageBaseModel
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string FullName { get; set; }
        public Nullable<System.DateTime> LoginTime { get; set; }
        public Nullable<System.DateTime> LogoutTime { get; set; }
        public string Duration { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FNF.IPX.Models
{
    public class FlashCodeModel
    {
        public int Id { get; set; }
        public string Code { get; set; }
    }
}

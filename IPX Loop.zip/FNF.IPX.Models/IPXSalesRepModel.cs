namespace FNF.IPX.Models
{
    using System;
    using System.Collections.Generic;

    public partial class IPXSalesRepModel
    {
        public int Id { get; set; }
        public Nullable<int> OrderId { get; set; }
        public Nullable<int> UserId { get; set; }
        public string SalesRepName { get; set; }
        public string EmailAddress { get; set; }
    
        public virtual OrderDetailsModel OrderDetails { get; set; }
    }
}

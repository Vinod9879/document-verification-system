﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FNF.IPX.Models
{
    public class HeaderModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Datatype { get; set; }

        public int? Sorder { get; set; }
        public virtual ICollection<TemplateModel> Template { get; set; }
    }
}

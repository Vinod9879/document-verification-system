namespace FNF.IPX.Models
{
    using System;
    using System.Collections.Generic;
    
    public partial class PropertyMasterModel
    {
        public int Id { get; set; }
        public Nullable<int> OrderID { get; set; }
        public Nullable<int> SequenceNumber { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
    
        public virtual OrderDetailsModel OrderDetails { get; set; }
    }
}

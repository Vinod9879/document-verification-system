﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FNF.IPX.DataEntities
{
    public static class ContextExtensions
    {
        /// <summary>
        /// Gets the results.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="commandText">The query.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public static List<IDictionary<string, dynamic>> GetResults(this IPXEntities context, string commandText, CommandType commandType, List<SqlParameter> parameters)
        {
            //IEnumerable<FIP> results = context.Database.SqlQuery<FIP>(query, parameters);
            List<IDictionary<string, dynamic>> rv = new List<IDictionary<string, dynamic>>();
            using (DbConnection conn = context.Database.Connection)
            {
                conn.Open();
                using (DbCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = commandText;
                    cmd.CommandType = commandType;
                    if (parameters.Count > 0)
                        cmd.Parameters.AddRange(parameters.ToArray());
                    using (IDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            IDictionary<string, dynamic> eo = new ExpandoObject();
                            for (int lv = 0; lv < dr.FieldCount; lv++)
                                eo.Add(dr.GetName(lv), dr.GetValue(lv));
                            rv.Add(eo);
                        }
                    }
                }
            }
            return rv;
        }
    }
}

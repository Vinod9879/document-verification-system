﻿
namespace FNF.IPX.Common
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;


    public static class PERMISSION
    {
        public const string TemplateMenu = "TemplateMenu";
        public const string GroupMenu = "GroupMenu";
        public const string UserMenu = "UserMenu";
        public const string CanDownload = "CanDownload";
        public const string CanDeleteLeads = "CanDeleteLeads";
        public const string CanUpdateStatuses = "CanUpdateStatuses";
        public const string CanUpdateFlag = "CanUpdateFlag";
        public const string CanComments = "CanComments";
        public const string CanAddUser = "CanAddUser";
        public const string CanDeleteUser = "CanDeleteUser";
        public const string CanAddGroup = "CanAddGroup";
        public const string CanDeleteGroup = "CanDeleteGroup";
        public const string CanAddTemplate = "CanAddTemplate";
        public const string CanDeleteTemplate = "CanDeleteTemplate";
        public const string CanSeeAllOrders = "CanSeeAllOrders";
        public const string CanAssignOrderToUser = "CanAssignOrderToUser";
        public const string OrderArchiveMenu = "OrderArchiveMenu";
        public const string Action = "Action";
        public const string LoginStatisticsMenu = "LoginStatisticsMenu";

    }
}

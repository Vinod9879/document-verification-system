﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FNF.IPX.Common
{
    public static class DBConstants
    {
        public static readonly string SP_GetOrders = "Proc_GetOrderDetails";
        public static readonly string SP_GetOrderDetailsForDownload = "Proc_GetOrderDetailsForDownload";
        public static readonly string SP_GetOrders_Archive = "Proc_GetOrderDetails_Archive";
        public static readonly string SP_GetOrderDetailsForDownload_Archive = "Proc_GetOrderDetailsForDownload_Archive";

        //public static readonly string ShowOpenOrdersFilter = "[Order Status] not like '%Closed%'";
        //public static readonly string ShowOpenOrdersFilter_AND = "AND [Order Status] not like '%Closed%'";

        public static readonly string HeaderDataType_String = "string";
        public static readonly string HeaderDataType_Number = "number";
        public static readonly string HeaderDataType_DateTime = "datetime";
        public static readonly string HeaderDataType_Currency = "currency";
        public static readonly string HeaderDataType_Email = "email";

        public static readonly string[] HeaderFieldWithCommas = { "Sales Rep", "Sales Rep Email", "Marketing Source" };
    }
}

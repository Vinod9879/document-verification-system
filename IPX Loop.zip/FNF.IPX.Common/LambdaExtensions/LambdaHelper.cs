﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace FNF.IPX.Common.LambdaExtensions
{
    public static class LambdaHelper
    {
        /// <summary>
        /// Used to map Expression tree from one model to another model type. Ex: from Model to Entity or vice-versa
        /// </summary>
        /// <typeparam name="TFrom"></typeparam>
        /// <typeparam name="TTo"></typeparam>
        /// <param name="from"></param>
        /// <returns></returns>
        public static Expression<Func<TTo, bool>> Convert<TFrom, TTo>(this Expression<Func<TFrom, bool>> from)
        {
            return TypeConversionVisitor.ConvertImpl<Func<TFrom, bool>, Func<TTo, bool>>(from);
        }
    }
}

﻿

namespace FNF.IPX.Common
{

    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;


    public static class RegulerExpression
    {
        public const string Email = @"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,15}";

        /// <summary>
        /// Pure characters only
        /// </summary>
        public const string PureStringName = @"^[a-zA-Z\s\.]+$";

        /// <summary>
        /// Special characters and numbers are not  allowed 
        /// </summary>
        public const string Name = @"^[a-zA-Z.()_'-\s]{1,40}$";

        /// <summary>
        /// Allow alphanumeric characters and characters '(', ')', '-', '_' 
        /// </summary>
        public const string AlphaNumeric = @"^[a-zA-Z0-9.,*()_&-\s/]{1,100}$";

        /// <summary>
        /// For Ammount Field
        /// </summary>
        public const string Amount = @"(^\d+$)|(^\.\d{1,4}$)|(^\d*\.\d{0,4}$)";

        /// <summary>
        ///Only Numbers are allowed
        /// </summary>
        public const string OnlyNumber = @"^[0-9.]*$";

        /// <summary>
        ///Only currency format (00.000, 0.00, .00, etc.,) are allowed
        /// </summary>
        public const string Currency = @"(^\d+$)|(^\.\d{1,4}$)|(^\d*\.\d{0,4}$)";

        /// <summary>
        ///Only dates in MM/dd/yyyy are allowed
        /// </summary>
        public const string DateTime_MMddyyyy = @"^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/(19|20)\d{2}$";

     

    }
}

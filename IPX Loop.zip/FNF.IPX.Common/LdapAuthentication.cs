﻿using System;
using System.Configuration;
using System.DirectoryServices;
using System.Text;

namespace FNF.IPX.Common
{
    public class LdapAuthentication
    {
        private string _path;
        private string _filterAttribute;
        private string _domain;
        private string _server;
        // <add key="adPath" value="LDAP://10.250.129.26"/>
        public LdapAuthentication(string path, string domain, string server)
        {
            _path = path;
            _domain = domain;
            _server = server;
        }

        public bool CheckUserAvailability(string username)
        {

            try
            {

                string domainAndUsername = ConfigurationManager.AppSettings["LDAPUserName"];
                string password;
                password = ConfigurationManager.AppSettings["LDAPUserPws"];
                password = password.Decrypt();
                //password = "t<7v#9.Y3VHbbtrbGeWC";
                //password = "J{>;D93YzU}%(YWz#dGL";
                string encpassword;
                encpassword = Cipher.Encrypt(password, domainAndUsername);

                DirectoryEntry entry = new DirectoryEntry(_path, domainAndUsername, password);
                object obj = entry.NativeObject;

                DirectorySearcher search = new DirectorySearcher(entry);

                string encodedUserName = Microsoft.Security.Application.Encoder.LdapFilterEncode(username);

                search.Filter = "(SAMAccountName=" + encodedUserName + ")";

                //search.Filter = "(SAMAccountName=" + username + ")";
                search.PropertiesToLoad.Add("cn");
                SearchResult result = search.FindOne();

                if (null == result)
                {
                    return false;
                }

                //Update the new path to the user in the directory.
                _path = result.Path;
                _filterAttribute = (string)result.Properties["cn"][0];
            }
            catch (Exception ex)
            {
                throw new Exception("Error authenticating user. " + ex.Message);
                //return false;
            }

            return true;
        }

        public bool IsAuthenticated(string username, string pwd)
        {
            string domainAndUsername = _domain + "\\"+ username;
           // username = username.Split('\\')[1];
            //nslookup (from start menu)
            //> set type = all/srv
            //> _ldap._tcp.dc._msdcs.fnfisez.com / _ldap._tcp.dc._msdcs.fnfiglobal.local (and pick up any one of the server IP)

            //bool Exists = false;
            //if (DirectoryEntry.Exists(_path))
            //{
            //    Exists = true;
            //}

            DirectoryEntry entry = new DirectoryEntry(_path, domainAndUsername, pwd);
           
            //DirectoryEntry entry = new DirectoryEntry("LDAP://10.230.16.22",domainAndUsername,pwd);
            //DirectoryEntry entry = new DirectoryEntry(_path, domainAndUsername, pwd);

            try
            {

                object obj = entry.NativeObject;

                DirectorySearcher search = new DirectorySearcher(entry);


                string encodedUserName = Microsoft.Security.Application.Encoder.LdapFilterEncode(username);

                search.Filter = "(SAMAccountName=" + encodedUserName + ")";
                search.PropertiesToLoad.Add("cn");
                SearchResult result = search.FindOne();

                if (null == result)
                {
                    return false;
                }

                //Update the new path to the user in the directory.
                _path = result.Path;
                _filterAttribute = (string)result.Properties["cn"][0];
            }
            catch (Exception ex)
            {
                throw new Exception("Error authenticating user. " + ex.Message);
                //return false;
            }

            return true;
        }

        public string GetGroups()
        {
            DirectorySearcher search = new DirectorySearcher(_path);
            search.Filter = "(cn=" + _filterAttribute + ")";
            search.PropertiesToLoad.Add("memberOf");
            StringBuilder groupNames = new StringBuilder();

            try
            {
                SearchResult result = search.FindOne();
                int propertyCount = result.Properties["memberOf"].Count;
                string dn;
                int equalsIndex, commaIndex;

                for (int propertyCounter = 0; propertyCounter < propertyCount; propertyCounter++)
                {
                    dn = (string)result.Properties["memberOf"][propertyCounter];
                    equalsIndex = dn.IndexOf("=", 1);
                    commaIndex = dn.IndexOf(",", 1);
                    if (-1 == equalsIndex)
                    {
                        return null;
                    }
                    groupNames.Append(dn.Substring((equalsIndex + 1), (commaIndex - equalsIndex) - 1));
                    groupNames.Append("|");
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error obtaining group names. " + ex.Message);
            }
            return groupNames.ToString();
        }
    }

}
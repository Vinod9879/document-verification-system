﻿

namespace FNF.IPX.Common
{

    using System;
    using System.Configuration;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Security.Cryptography;
    using System.Text;
    using System.Web;
    using System.Web.Mvc;
    using System.Web.Routing;
    /// <summary>
    /// Security Extension Class for Handling Encryption, Decryption and Query String Encoding
    /// </summary>
    public static class SecurityExtensions
    {
        /// <summary>
        /// IsDebug PreProcession Wont work in MVC view, So better put it isinsode class librabry project
        /// </summary>
        /// <returns></returns>
        public static bool IsDebug()
        {
            #if DEBUG
            return true;
            #else
            return false;
            #endif
        }



        public static MvcHtmlString EncodedActionLink(this HtmlHelper htmlHelper, string linkText, string actionName,
                                                      string controllerName, object routeValues, object htmlAttributes)
        {
            var applicationPath = HttpContext.Current.Request.ApplicationPath;

            var queryString = string.Empty;
            var htmlAttributesString = string.Empty;
            if (routeValues != null)
            {
                var d = new RouteValueDictionary(routeValues);
                for (var i = 0; i < d.Keys.Count; i++)
                {
                    if (i > 0)
                    {
                        queryString += "?";
                    }
                    queryString += d.Keys.ElementAt(i) + "=" + d.Values.ElementAt(i);
                }
            }

            if (htmlAttributes != null)
            {
                var d = new RouteValueDictionary(htmlAttributes);
                for (var i = 0; i < d.Keys.Count; i++)
                {
                    htmlAttributesString += " " + d.Keys.ElementAt(i) + "= '" + d.Values.ElementAt(i) + "'";
                }
            }

            //<a href="/Answer?questionId=14">What is Entity Framework??</a>
            var ancor = new StringBuilder();
            ancor.Append("<a ");
            if (htmlAttributesString != string.Empty)
            {
                ancor.Append(htmlAttributesString);
            }
            ancor.Append(" href='");
            if (applicationPath != null && applicationPath.Trim().Length > 1)
            {
                ancor.Append(applicationPath);
            }
            if (controllerName != string.Empty)
            {
                ancor.Append("/" + controllerName);
            }

            if (actionName != "Index")
            {
                ancor.Append("/" + actionName);
            }
            if (queryString != string.Empty)
            {
                ancor.Append("?param=" + queryString.EncodeAndEncrypt());
            }
            ancor.Append("'");
            ancor.Append(">");
            ancor.Append(linkText);
            ancor.Append("</a>");
            return new MvcHtmlString(ancor.ToString());
        }

        public static MvcHtmlString EncodedActionLink(this HtmlHelper htmlHelper, string linkText, string iconClass, string actionName,
                                                      string controllerName, object routeValues, object htmlAttributes)
        {
            var applicationPath = HttpContext.Current.Request.ApplicationPath;

            var queryString = string.Empty;
            var htmlAttributesString = string.Empty;
            if (routeValues != null)
            {
                var d = new RouteValueDictionary(routeValues);
                for (var i = 0; i < d.Keys.Count; i++)
                {
                    if (i == 0)
                    {
                        queryString += "?";
                    }
                    else
                    {
                        queryString += "&";
                    }
                    queryString += d.Keys.ElementAt(i) + "=" + d.Values.ElementAt(i);
                }
            }

            if (htmlAttributes != null)
            {
                var d = new RouteValueDictionary(htmlAttributes);
                for (var i = 0; i < d.Keys.Count; i++)
                {
                    htmlAttributesString += " " + d.Keys.ElementAt(i) + "= '" + d.Values.ElementAt(i) + "'";
                }
            }

            //<a href="/Answer?questionId=14">What is Entity Framework??</a>
            var ancor = new StringBuilder();
            ancor.Append("<a ");
            if (htmlAttributesString != string.Empty)
            {
                ancor.Append(htmlAttributesString);
            }
            ancor.Append(" href='");
            if (applicationPath != null && applicationPath.Trim().Length > 1)
            {
                ancor.Append(applicationPath);
            }
            if (controllerName != string.Empty)
            {
                ancor.Append("/" + controllerName);
            }

            if (actionName != "Index")
            {
                ancor.Append("/" + actionName);
            }
            if (queryString != string.Empty)
            {
                ancor.Append("?param=" + queryString.EncodeAndEncrypt());
            }
            ancor.Append("'");
            ancor.Append(">");
            ancor.Append(string.Format("<i class=\"{0}\"></i>", iconClass));
            ancor.Append(linkText);
            ancor.Append("</a>");
            return new MvcHtmlString(ancor.ToString());
        }


        public static string Encrypt(this string plainText)
        {
            try
            {
                //string Password = "ipx123abc";
                string Password = "";
                Password = ConfigurationManager.AppSettings["LDAPUserName"];
                Password = Microsoft.Security.Application.Encoder.LdapFilterEncode(Password);

                if (string.IsNullOrEmpty(plainText)) return "";


                string encryptedData;

                encryptedData = Cipher.Encrypt(plainText, Password);

                //using (var rijndaelCipher = new RijndaelManaged())
                //{
                //    var Salt = Encoding.ASCII.GetBytes(Password.Length.ToString(CultureInfo.InvariantCulture));
                //    var PlainText = Encoding.Unicode.GetBytes(plainText);
                //    using (var secretKey = new PasswordDeriveBytes(Password, Salt))
                //    {
                //        using (var encryptor = rijndaelCipher.CreateEncryptor(secretKey.GetBytes(32), secretKey.GetBytes(16)))
                //        {
                //            using (var memoryStream = new MemoryStream())
                //            {
                //                using (var cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
                //                {
                //                    cryptoStream.Write(PlainText, 0, PlainText.Length);
                //                    cryptoStream.FlushFinalBlock();
                //                    var cipherBytes = memoryStream.ToArray();
                //                    memoryStream.Close();
                //                    cryptoStream.Close();
                //                    encryptedData = Convert.ToBase64String(cipherBytes);
                //                }
                //            }
                //        }

                //    }
                //}

                return encryptedData;

            }
            catch (Exception)
            {

                return "";
            }
        }

        public static string Decrypt(this string encryptedText, bool QueryString = false)
        {


            try
            {

                //string Password = "ipx123abc";
                if (string.IsNullOrEmpty(encryptedText)) return string.Empty;
                string Password = "";
                Password = ConfigurationManager.AppSettings["LDAPUserName"];

                string decryptedData;
                decryptedData = Cipher.Decrypt(encryptedText, Password);

                //using (var rijndaelCipher = new RijndaelManaged())
                //{
                //    var salt = Encoding.ASCII.GetBytes(Password.Length.ToString(CultureInfo.InvariantCulture));
                //    using (var secretKey = new PasswordDeriveBytes(Password, salt))
                //    {
                //        using (var decryptor = rijndaelCipher.CreateDecryptor(secretKey.GetBytes(32), secretKey.GetBytes(16)))
                //        {
                //            var encryptedData = Convert.FromBase64String(encryptedText);
                //            using (var memoryStream = new MemoryStream(encryptedData))
                //            {
                //                using (var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
                //                {

                //                    var plainText = new byte[encryptedData.Length];
                //                    var decryptedCount = cryptoStream.Read(plainText, 0, plainText.Length);
                //                    memoryStream.Close();
                //                    cryptoStream.Close();

                //                    decryptedData = Encoding.Unicode.GetString(plainText, 0, decryptedCount);
                //                }
                //            }
                //        }
                //    }
                //}

                return decryptedData;


            }
            catch (Exception ex)
            {
                string exMessage = ex.Message;
                return "";
            }
        }

        public static string EncodeAndEncrypt(this string plainText)
        {
            return Encrypt(HttpUtility.UrlEncode(plainText));
        }
        public static string DecodeAndDecrypt(this string plainText)
        {
            return HttpUtility.UrlDecode(Decrypt(plainText.Replace(" ", "+")));  
        }


        //public static bool IsNumeric(object Expression)
        //{
        //    bool isNum;
        //    double retNum;

        //    isNum = Double.TryParse(Convert.ToString(Expression), System.Globalization.NumberStyles.Any, System.Globalization.NumberFormatInfo.InvariantInfo, out retNum);
        //    return isNum;
        //}

    }
}




﻿
namespace FNF.IPX.Common
{

    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Diagnostics;
    using System.Linq;
    using System.Net.Mail;
    using System.Text;
    using System.Threading.Tasks;
    using System.Web.UI;  
    using System.Web;
    using System.Globalization;
    using System.Web.Mvc;
    using log4net;
    using log4net.Config;
  

    public  enum LogMessageType
    {
        DEBUG,
        INFORMATION,
        WARNING,
        ERROR,
        FACTAL
    }
    public static class LogErrors
    {
        private static readonly ILog logger = LogManager.GetLogger("IPX");
        static LogErrors()
        {

            XmlConfigurator.Configure();
         
        }

        public static void WriteLog(Exception exception, LogMessageType logMessageType = LogMessageType.ERROR)
        {

            switch (logMessageType)
            {
                case LogMessageType.DEBUG: logger.Debug(">>", exception);
                    break;
                case LogMessageType.INFORMATION: logger.Info(">>", exception);
                    break;
                case LogMessageType.WARNING: logger.Warn(">>", exception);
                    break;
                case LogMessageType.ERROR: logger.Error(">>", exception);
                    break;
                case LogMessageType.FACTAL: logger.Fatal(">>", exception);
                    break;
                default: logger.Error(">>", exception);
                    break;
            }
           
        }
        public static void WriteLog(String message, LogMessageType logMessageType = LogMessageType.INFORMATION)
        {
            switch (logMessageType)
            {
                case LogMessageType.DEBUG: logger.Debug(message);
                    break;
                case LogMessageType.INFORMATION: logger.Info(message);
                    break;
                case LogMessageType.WARNING: logger.Warn(message);
                    break;
                case LogMessageType.ERROR: logger.Error(message);
                    break;
                case LogMessageType.FACTAL: logger.Fatal(message);
                    break;
                default: logger.Error(message);
                    break;
            }
           

            
        }

        /// <summary>
        /// Usage :: ex.ToMessageAndCompleteStacktrace()
        /// </summary>
        /// <param name="exception"></param>
        /// <param name="errorMessage"></param>
        /// <param name="loggingCategoryNames"></param>
        public static void ToMessageAndCompleteStacktrace(this Exception exception, String errorMessage)
        {
            Exception e = exception;
            var st = new StackTrace(e, true);
            var s = new StringBuilder();
            s.Append(errorMessage);


            try
            {
                if (exception != null)
                    s.AppendLine("Error Short Description  : " + exception.Message);

                try
                {
                    double n;
                    bool isNumeric = double.TryParse(e.HelpLink, out n);
                    if (isNumeric)
                        s.AppendLine("\n\n IPX application error message code for support tracking :" + e.HelpLink);

                }
                catch (Exception ext)
                {
                    WriteLog(ext.Message);
                }
               
                s.AppendLine("\n**********************************************************************\n");
                s.AppendLine("\n\nUserName :" + HttpContext.Current.User.Identity.Name);
                s.AppendLine("\nRoles Associated :");

                foreach (var role in HttpContext.Current.User.Identity.GetInfo().Permissions)
                    s.AppendFormat("{0}," , role.ToString());

                 s.AppendLine("\nAbsoluteUri :" + HttpContext.Current.Request.Url.AbsoluteUri);
                s.AppendLine("\nHttpMethod :" + HttpContext.Current.Request.HttpMethod);
                s.AppendLine("\nRequest ContentType :" + HttpContext.Current.Request.ContentType);    
                s.AppendLine("\nBrowser Information :" + GetBrowserInfo());
                //CultureInfo culture = CultureInfo.CreateSpecificCulture(CultureInfo.CurrentCulture.Name);
                //s.AppendLine("\nClient Culture EnglishName :" + culture.EnglishName);
                //s.AppendLine("\nClient Culture Name:" + culture.Name);
                //s.AppendLine("\nClient Culture Code:" + culture.ThreeLetterWindowsLanguageName);
                s.AppendLine("\n**********************************************************************\n");
            }
            catch (Exception ex)
            {
               WriteLog(ex.Message);
            }

            while (e != null)
            {
                s.AppendLine("\nException type: " + e.GetType().FullName);
                s.AppendLine("\nMessage       : " + e.Message);
                s.AppendLine("\nStacktrace:");
                s.AppendLine(e.StackTrace);
                s.AppendLine();
                var frame = st.GetFrame(0);

                // Get the line number from the stack frame
                var line = frame.GetFileLineNumber();

                s.Append("\nLine number of exception :: " + line);
                s.Append("\nInnter Exception : " +  e.InnerException );
                e = e.InnerException;
            }

           WriteLog(s.ToString());

          
          
        }

        private static string GetBrowserInfo()
        {
            string UserData = "";
            var browser = HttpContext.Current.Request.Browser;
            // UserData += Request.ServerVariables["HTTP_X_FORWARDED_FOR"] ?? Request.UserHostAddress;
            UserData += browser.Type;
            UserData += browser.Browser;
            UserData += browser.Version;
            UserData += browser.Platform;
            //  UserData += loginsBusiness.DetermineComputerNameByIp(Request.ServerVariables["HTTP_X_FORWARDED_FOR"] ?? Request.UserHostAddress);


            return UserData;
        }
    }
}

﻿namespace FNF.IPX.Common
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Text;
    using System.Threading.Tasks;
    using System.Collections;
    using System.Configuration;
    using System.Runtime.Serialization;
    using System.Net;
    using System.IO;
    using System.Collections.Specialized;
    using System.Web.Mvc;
    using System.Web.Mvc.Html;
    using System.Xml.Linq;
    using FNF.IPX.Common.LambdaExtensions;
   

    public class Helpers
    {
        /// <summary>
        /// Creates a clone of the object: this is an exact copy, which does not contain any references to the original object
        /// </summary>
        /// <typeparam name="TType">The type of the object</typeparam>
        /// <param name="sourceObject">The object that will be cloned</param>
        /// <returns></returns>
        public static TType Clone<TType>(TType sourceObject)
          where TType : class
        {
            if (sourceObject == null) return null;
            TType clone = null;
            DataContractSerializer serializer = new DataContractSerializer(typeof(TType));
            using (MemoryStream memStream = new MemoryStream())
            {
                serializer.WriteObject(memStream, sourceObject);
                memStream.Position = 0;
                object deserialisedValue = serializer.ReadObject(memStream);
                if (deserialisedValue != null)
                {
                    clone = (TType)deserialisedValue;
                }
            }
            return clone;
        }

        //public static dynamic GetFormattedData(dynamic info)
        //{
        //    if(info != null)
        //    {
        //        string sInfo = Convert.ToString(info);
        //        if(sInfo != null && !string.IsNullOrEmpty(sInfo.Trim()))
        //        {
        //            double finfo;
        //            if(double.TryParse(sInfo, out finfo))
        //            {
        //                return finfo.ToString("c");
        //            }
        //        }
        //    }
        //    return info;
        //}

        public static bool NotNullOrEmptyOrStringNULL(string info)
        {
            return !string.IsNullOrEmpty(info) && info.Trim().ToLower() != "null";
        }
    }


  



        


}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FNF.IPX.Common
{
    public static class GeneralConstants
    {
        public static readonly string DateFormat = "MM/dd/yyyy";
        public static readonly string DateFormat_Longer = "MM/dd/yyyy h:mm:ss tt";
        public const string NotAvailable = "NA";
        
        //Used in Search
        /// <summary>
        /// handle AND within search strings
        /// while setting search fields on search popup_load (SetSearch javascript function), the entire search string is split
        /// based on AND keyword, so changing the 'AND' within the individual field's search string to ensure
        /// the split in Search popup_load does not split this value.
        /// replace back ### in code, prior to sending to DB for execution
        /// replace back ### in Search popup_load, while populating the value into the search field textbox        /// 
        /// </summary>
        public static readonly string AND_Placeholder = "**$[{A]}$**";
    }
}

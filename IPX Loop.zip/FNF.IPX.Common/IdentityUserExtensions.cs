﻿

namespace FNF.IPX.Common
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Security.Claims;
    using System.Security.Cryptography;
    using System.Security.Principal;
    using System.Text;
    using System.Web;
    using System.Web.Mvc;
    using System.Web.Routing;

    /// <summary>
    /// Security Extension Class for Handling Encryption, Decryption and Query String Encoding
    /// </summary>
    public static class IdentityUserExtensions
    {

        public static UserIdentity GetInfo(this IIdentity Identity)
        {
            return new UserIdentity(Identity);
        }

    }


    /// <summary>
    /// used for IdentityUserExtensions methode only
    /// </summary>
    public class UserIdentity
    {
        IIdentity Identity;
        private string GetValue(string type)
        {
            try
            {
                var result = ((ClaimsIdentity)Identity).Claims.Where(x => x.Type == type);
                if (result != null)
                {
                    return (result.Select(x => x.Value)).FirstOrDefault().ToString();
                }
                else
                    return string.Empty;

            }
            catch (Exception)
            {

                return "";
            }

        }
        private List<string> GetList(string type)
        {

            return (((ClaimsIdentity)Identity).Claims.Where(x => x.Type == type).Select(x => x.Value).ToList());

        }


        public UserIdentity(IIdentity Identity)
        {
            this.Identity = Identity;

        }


        public int UserId { get { return Convert.ToInt32(GetValue(ClaimTypes.NameIdentifier)); } }

        public String FullName { get { return FirstName + " " + Lastname; } }
        public String Username { get { return GetValue(ClaimTypes.Name); } }

        public String FirstName { get { return GetValue("FirstName"); } }

        public String Lastname { get { return GetValue("LastName"); } }

        public String Email { get { return GetValue(ClaimTypes.Email); } }
        public String LoginId { get { return GetValue("LoginId"); } }

        public List<string> Permissions { get { return GetList(ClaimTypes.Role); } }

        public List<string> Groups { get { return GetList("Groups"); } }


    }
}
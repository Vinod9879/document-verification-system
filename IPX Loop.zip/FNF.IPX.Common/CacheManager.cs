﻿

namespace FNF.IPX.Common
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Web;

    public static class CacheManager
    {

        public static T GetFromCache<T>(string cacheKey)
        {
            T cachedItem = default(T);
            if (IsExist(cacheKey))
            {
                cachedItem = (T)HttpRuntime.Cache[cacheKey];
            }
            return cachedItem;
        }

        /// <summary>
        /// Helper method for adding/retrieving a value from/to the cache.
        /// </summary>
        /// <param name="cacheKey">The key of the cached item</param>
        /// <param name="f">If the key is not found in the cache execute the f() function to retrieve the object</param>
        /// <returns></returns>
        public static T GetFromCache<T>(string cacheKey, Func<T> f)
        {
            return GetFromCache(cacheKey, true, f);
        }

        /// <summary>
        /// Helper method for adding/retrieving a value from/to the cache.
        /// </summary>
        /// <param name="cacheKey">The key of the cached item</param>
        /// <param name="getFromCache">True if a cached vaersion cand be returned. If false, f() will be used to get the data</param>
        /// <param name="f">If the key is not found in the cache execute the f() function to retrieve the object</param>
        /// <returns></returns>
        public static T GetFromCache<T>(string cacheKey, bool getFromCache, Func<T> f)
        {
            T cachedItem = default(T);
            if (getFromCache && IsExist(cacheKey))
                cachedItem = (T)HttpRuntime.Cache[cacheKey];

            if (cachedItem == null)
            {
                cachedItem = f();
                if (cachedItem != null)
                    HttpRuntime.Cache.Insert(cacheKey, cachedItem, null, DateTime.Now.AddSeconds(10), TimeSpan.Zero);
            }

            return cachedItem;
        }

        public static void AddToCache(string cacheKey, object data)
        {
            if (string.IsNullOrWhiteSpace(cacheKey))
                throw new NullReferenceException("Cache Key should not be blank or null");
            HttpRuntime.Cache.Insert(cacheKey, data, null, DateTime.Now.AddSeconds(10), TimeSpan.Zero);
        }

        public static void RemoveFromCache(string cacheKey)
        {
            if (IsExist(cacheKey))
            {
                HttpRuntime.Cache.Remove(cacheKey);
            }
        }

        public static bool IsExist(string cacheKey)
        {
            return HttpRuntime.Cache[cacheKey] != null;
        }
    }
}

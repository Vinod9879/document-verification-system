﻿
namespace FNF.IPX.Common
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;


    /// <summary>
    /// This class contains LINQ extension methods that are 
    /// not present in Standard set by default.
    /// </summary>
    public static class LinqExtension
    {


       public  static Expression<Func<T, bool>> OrElse<T>(this Expression<Func<T, bool>> lhs, Expression<Func<T, bool>> rhs)
        {
            var row = Expression.Parameter(typeof(T), "row");
            var body = Expression.OrElse(
                Expression.Invoke(lhs, row),
                Expression.Invoke(rhs, row));
            return Expression.Lambda<Func<T, bool>>(body, row);
        }
       public static Expression<Func<T, bool>> AndAlso<T>(this Expression<Func<T, bool>> lhs, Expression<Func<T, bool>> rhs)
       {
           if (lhs == null)
           {
    
               return rhs;

               //var row = Expression.Parameter(typeof(T), "row");
               //var body = Expression.And(
               //    Expression.Invoke(rhs, row),
               //    Expression.Invoke(rhs, row));
               //return Expression.Lambda<Func<T, bool>>(body, row);
           }
           else
           {
               var row = Expression.Parameter(typeof(T), "row");
               var body = Expression.AndAlso(
                   Expression.Invoke(lhs, row),
                   Expression.Invoke(rhs, row));
               return Expression.Lambda<Func<T, bool>>(body, row);
           }
       }

        #region IQueryable
        /// <summary>
        /// Usage :  var result = source.In(items);
        /// </summary>
        public static IQueryable<T> In<T>(this IQueryable<T> source, IQueryable<T> checkAgainst)
        {
            return from s in source
                   where checkAgainst.Contains(s)
                   select s;
        }

        public static IQueryable<T> NotIn<T>(this IQueryable<T> source, IQueryable<T> checkAgainst)
        {
            return from s in source
                   where !checkAgainst.Contains(s)
                   select s;
        }
        #endregion

        #region IEnumerable

        /// <summary>
        /// Usage :  var result = source.In(items);
        /// </summary>
        public static IEnumerable<T> In<T>(this IEnumerable<T> source, IEnumerable<T> checkAgainst)
        {
            return from s in source
                   where checkAgainst.Contains(s)
                   select s;
        }

        public static IEnumerable<T> NotIn<T>(this IEnumerable<T> source, IEnumerable<T> checkAgainst)
        {
            return from s in source
                   where !checkAgainst.Contains(s)
                   select s;
        }
        #endregion

    }
}

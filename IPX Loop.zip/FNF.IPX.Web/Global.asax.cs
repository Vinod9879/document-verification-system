﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using System.Configuration;

namespace FNF.IPX.Web
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            AntiForgeryConfig.UniqueClaimTypeIdentifier = ClaimTypes.NameIdentifier;

         
        }

        // Set Secure Flag on Session Cookie
        protected void Application_EndRequest(Object sender, EventArgs e)
        {
            if (ConfigurationManager.AppSettings["ApplicationStage"] != "Local")
            {
                foreach (string sCookie in Response.Cookies)
                {
                    // Set the cookie to be secure. Browsers will send the cookie only to pages requested with https              
                    var httpCookie = Response.Cookies[sCookie];
                    if (httpCookie != null)
                        httpCookie.Secure = true;
                }
            }
            Response.AppendHeader("Cache-Control", "no-cache, no-store, must-revalidate");
            Response.AppendHeader("Pragma", "no-cache");
            Response.AppendHeader("Expires", "0");
        }
    }
}

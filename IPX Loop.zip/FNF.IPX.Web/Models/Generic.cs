﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FNF.IPX.Web.Models
{
    public class Generic
    {
        public string Field { get; set; }
        public string Value { get; set; }
    }
}
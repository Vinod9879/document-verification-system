﻿function validateModelForm()
{
    $.validator.unobtrusive.parse("#formPartial");
    $('#formPartial').validate();
    return $('#formPartial').valid();
}


function ShowAjaxModelPopUpGeneral(PartialViewResultUrl, data, MainDivId, callbackOkButton, callbackCancelButton, onloadCallback)
    {
        ShowAjaxModelPopUp(this, PartialViewResultUrl, MainDivId, callbackOkButton, callbackCancelButton,onloadCallback,data);
      
    }

// Please refer Template Create/Edit Methode on template index cshtml
    function ShowAjaxModelPopUp(thisbutton, PartialViewResultUrl, MainDivId, callbackOkButton, callbackCancelButton,onloadCallback,data) {
      
    var ItemId = $(thisbutton).attr("ItemId");

    if(!data)
        data= { id: ItemId };

    doajax(PartialViewResultUrl,data, function (result) {

        $('#' + MainDivId).html(result);

        attachkpe($('#' + MainDivId));

        $('#' + MainDivId+' .modelDiv').modal({
            backdrop: 'static', keyboard: true, autoOpen: false,
            resizable: false,
            modal: true,
            //width: 'auto',
            //create: function (event, ui) {
            //    // Set maxWidth
            //    $(this).css("width", "460px");
            //}
        }, 'show');
        $('.multiselect').multiSelect();

        $('#' + MainDivId + ' .modelDiv .btnModelPopUpOk').on("click", function () {
            //  $('form').validate("submit");
            //debugger;
            var model = $('#' + MainDivId + ' .modelDiv');
            var ItemId = $('#' + MainDivId + ' .modelDiv .hdfModelPopUpId').val();
            callbackOkButton(ItemId, model);
            Loader('self',this);
        });

        $('#' + MainDivId + ' .modelDiv .btnModelPopUpCancel').on("click", function () {

            $('#' + MainDivId + ' .modelDiv .btnModelPopUpOk').off('click');
            $('#' + MainDivId + ' .modelDiv .btnModelPopUpCancel').off('click');

            var model = $('#' + MainDivId + ' .modelDiv');
            var ItemId = $('#' + MainDivId + ' .modelDiv .hdfModelPopUpId').val();
            callbackCancelButton(ItemId, model);
        });

        if (onloadCallback)
        onloadCallback($('#' + MainDivId));
    });
}


function doajax(url, params, callback) {

    var RequestVerificationToken = $("[name=__RequestVerificationToken]").val();

    $.ajax({
        type: 'POST', url: url, cache: false, contentType: 'application/json; charset=utf-8',
        beforeSend: function (request) {
            Loader('body');
            request.setRequestHeader("RequestVerificationToken", RequestVerificationToken);
        },
        statusCode: {
            401: function () { alert("Session timeout"); RedirectToLogin(); },
            404: function () { alert("404"); },
            //200: function () { alert("200"); },
            201: function () { alert("201"); },
            202: function () { alert("202"); }
        },
        data: JSON.stringify(params), error: (function onerror(jqxhr, status, error) {
            try {
                alert(JSON.parse(jqxhr.responseText).Message);
            } catch (e) { }

            Loader('close');

        }), success: (function (resutl) {
            callback(resutl);
            Loader('close');
        }),
        error: (function (xhr) {
            if (xhr.status=="500")
            ShowAjaxModelPopUpOnError(xhr.status);
                  // alert(xhr)
                   // Loader('close');
                })
    });
}



var PagingParm = {
    FilterColumnNameValue: {},
    SortColumns: {},
    PageNumber: 1,
    PageSize: 10
}

function SetGridViewParams(pagingparm) {


    var o = pagingparm.SortColumns;

    //for (var prop in o) {
    //    if (o.hasOwnProperty(prop)) {
    //        $(".sort[sortcolumn='" + prop + "']").removeClass("glyphicon-arrow-up").removeClass("glyphicon-arrow-down");

    //    }
    //}
    for (var prop in o) {
        if (o.hasOwnProperty(prop)) {
            var val = o[prop];
            //console.log('Value = ', val, ', Prop =', prop, ', Owner=', o);
          
            // UI attribute;
            var element = $(".sort[sortcolumn='" + prop + "']");
           

            if (val == "asc")
            {
                element.find('i').addClass("glyphicon-arrow-up");
                element.attr("sorderOrder", "desc");
            }
                
            else
            {
                element.find('i').addClass("glyphicon-arrow-down");
                element.attr("sorderOrder", "asc");
            }
               

        }
    }
    
    var f = pagingparm.FilterColumnNameValue;
    var SearchFilter=false;
    for (var prop in f) {
        if (f.hasOwnProperty(prop)) {
            var val = f[prop];
            //console.log('Value = ', val, ', Prop =', prop, ', Owner=', o);

            // UI attribute;
            var element = $("#txtsearch");
            if (val != "") {
                SearchFilter = true;
            }
            element.val(val);

            $('#selsearch').val(prop);

        }
    }

    if (SearchFilter == false)
    {
        //debugger;
        PagingParm.FilterColumnNameValue = {};
    }
      

}

function GridViewPagingButtonInit()
{
  
    var pagenumber = parseInt($("#GRDPagingMianDiv").attr("pagenumber"));
    var pagecount = parseInt($("#GRDPagingMianDiv").attr("pagecount"));

    $('.grdbutton').removeAttr("disabled");

    if (pagenumber <= 1)
    {
        $('#GRDbtnprevious').attr("disabled", "disabled");
    }

    if (pagenumber >= pagecount) {
        $('#GRDbtnnext').attr("disabled", "disabled");
    }
}

function GridViewInit(Callback)
{

    attachkpe($('form'));
    GridViewPagingButtonInit();
    var pagingparms = $.parseJSON('[' + $('.pagingparm').val() + ']');

    SetGridViewParams(pagingparms[0])





    $('#GRDbtnfirst').on('click', function () {

        PagingParm.PageNumber = 1;

        Callback();

        return false;



    });
    $('#GRDbtnprevious').on('click', function () {

        var pagenumber = parseInt( $(this).parent().attr("pagenumber"));

        if (pagenumber>1)
            PagingParm.PageNumber = pagenumber-1;

        Callback();

        return false;
    });
    $('#GRDbtnnext').on('click', function () {
        debugger;
        var pagenumber = parseInt($(this).parent().attr("pagenumber"));
        var pagecount = parseInt($(this).parent().attr("pagecount"));
        //var totalitemcount = $(this).parent().attr("totalitemcount");
        //var pagesize = $(this).parent().attr("pagesize");

        if (pagenumber < pagecount)
            PagingParm.PageNumber = pagenumber +1;

        Callback();

        return false;

    });
    $('#GRDbtnlast').on('click', function () {

        var pagenumber = parseInt($(this).parent().attr("pagenumber"));
        var pagecount = parseInt($(this).parent().attr("pagecount"));
        //var totalitemcount = $(this).parent().attr("totalitemcount");
        //var pagesize = $(this).parent().attr("pagesize");

     
       PagingParm.PageNumber = pagecount;

        Callback();

        return false;

    });

    $('.custompageindex').on("click", function () {

        //callbackOkButton
        PagingParm.PageNumber = $(this).attr('pagenumber');

        Callback();

        return false;
    });


    $('.sort').on("click", function () {

        //  debugger;
        //callbackOkButton
        //if (SortColumns == null)
        // SortColumns = new Array();

        var key = $(this).attr('sortcolumn');
        var value = $(this).attr('sorderOrder');

        if (value == null) {
            value = "asc";
        }
        PagingParm.SortColumns = {};// forcing single sorting column

        PagingParm.SortColumns[key] = value;

       

        Callback();

        return false;

    });



    $('#btnsearch').on("click", function () {

        //debugger;
        var searchFeild=$('#selsearch').val();

        var value = $('#txtsearch').val();
        if (value=="")
        {
              PagingParm.FilterColumnNameValue = {};
        }
        else
        {
            PagingParm.FilterColumnNameValue = {};//forcing one search filter at a time
            PagingParm.FilterColumnNameValue[searchFeild] = value;
        }
       


        Callback();

        return false;

    });

    //Following methods only for UserLoginDetails view
    var location = window.location.toString();
    if (location.indexOf("UserLoginDetails") != -1) {

        $(document).on('change', '#selsearch', SearchBoxUpdated);
        $('#txtDate').datepicker();

        function SearchBoxUpdated() {
            if ($(this).val() == 'LoginTime') {
                $('#spDate').attr('disabled', false);
                $('#spDate').show();
                $('#txtsearch').hide();
                $('#txtDate').val('');
                $('#txtDate').show();
            }
            else {
                $('#spDate').attr('disabled', true);
                $('#spDate').hide();
                $('#txtsearch').show();
                $('#txtsearch').val('');
                $('#txtDate').val('');
                $('#txtDate').hide();
            }
        }

        if ($('#selsearch').val() == 'LoginTime') {
            $('#spDate').attr('disabled', false);
            $('#spDate').show();
            $('#txtsearch').hide();
            if ($('#txtsearch').val() != undefined && $('#txtsearch').val().length > 0)
                $('#txtDate').val($('#txtsearch').val());
            $('#txtsearch').val('');
            $('#txtDate').show();
        }
        else {
            $('#spDate').attr('disabled', true);
            $('#spDate').hide();
            $('#txtsearch').show();
            //$('#txtsearch').val('');
            $('#txtDate').val('');
            $('#txtDate').hide();
        }

        //Below method is specifically for User Login Statistics Page/View
        $('#btnsearchLoginStatistics').on("click", function () {

            if (validateModelForm() == true) {
                var searchFeild = $('#selsearch').val();

                var value = searchFeild == "LoginTime" ? $('#txtDate').val() : $('#txtsearch').val();
                if (value == "") {
                    PagingParm.FilterColumnNameValue = {};
                }
                else {
                    PagingParm.FilterColumnNameValue = {};//forcing one search filter at a time
                    PagingParm.FilterColumnNameValue[searchFeild] = value;
                }



                Callback();

                return false;
            }
        });

    }
}


//if (window.addEventListener) window.addEventListener('DOMMouseScroll', wheel, false);
//window.onmousewheel = document.onmousewheel = wheel;

//function wheel(event) {
//    var delta = 0;
//    if (event.wheelDelta) delta = event.wheelDelta / 120;
//    else if (event.detail) delta = -event.detail / 3;

//    handle(delta);
//    if (event.preventDefault) event.preventDefault();
//    event.returnValue = false;
//}

//function handle(delta) {
//    var time = 500;
//    var distance = 300;

//    $('html, body, div').stop().animate({
//        scrollTop: $(window).scrollTop() - (distance * delta)
//    }, time);
//}


$.fn.hScroll = function (options) {
    function scroll(obj, e) {
        var evt = e.originalEvent;
        var direction = evt.detail ? evt.detail * (-120) : evt.wheelDelta;

        if (direction > 0) {
            direction = $(obj).scrollLeft() - 120;
        }
        else {
            direction = $(obj).scrollLeft() + 120;
        }

      //  $(obj).animate({ scrollLeft: direction }, 800);
      
        $(obj).scrollLeft(direction);

        //e.preventDefault();
    }

   // $(this).width($(this).find('div').width());

    $(this).bind('DOMMouseScroll mousewheel', function (e) {
        scroll(this, e);
    });
}

//autocomplete
$(document).ready(function () {
    $(document).on('focus', ':input', function () {
        $(this).attr('autocomplete', 'off');
    });
});
﻿var ShowOpenOrdersFilter = "[Order Status] not like '%Closed%'";
var ShowOpenOrdersFilter_AND = "AND [Order Status] not like '%Closed%'";

var m_skeys = new Array();
m_skeys.push(8); //Backspace
m_skeys.push(9); //Tab
m_skeys.push(46); //Delete
m_skeys.push(36); //Home
m_skeys.push(35); //End
m_skeys.push(37); //Left
m_skeys.push(39); //Right

var m_mustkeys = new Array();
m_mustkeys.push(32); //space
m_mustkeys.push(47); // - /
m_mustkeys.push(58); // - :
m_mustkeys.push(64); // - @
m_mustkeys.push(46); // - .

function IsAlphaNumeric(e, txt) {
    if (txt.prop('type') === 'password') return true;
    var keyCode = e.keyCode == 0 ? e.charCode : e.keyCode;
    //console.log(keyCode);
    var ret = ((keyCode >= 48 && keyCode <= 57) || (keyCode >= 65 && keyCode <= 90) || (keyCode >= 97 && keyCode <= 122) || (m_skeys.indexOf(e.keyCode) != -1 && e.charCode != e.keyCode) || (m_mustkeys.indexOf(keyCode) != -1));
    return ret;
}

$(function () {
    attachkpe($('form'));
});

function attachkpe(root) {
    $(root).find('input').each(function () {
        var checkIfSpecialAllowed = this.hasAttribute('AllowSpecial');
        if (checkIfSpecialAllowed == undefined || checkIfSpecialAllowed == false) {
            $(this).keypress(function (e) {
                return IsAlphaNumeric(e, $(this));
            });

            $(this).on('paste', function () {
                var element = this;
                setTimeout(function () {
                    var text = $(element).val();
                    //doing nothing please
                }, 100);
            });
        }
    });
}


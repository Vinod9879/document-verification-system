﻿$(function () {
    $('.multiselect').multiSelect();
    $('.ms-selection .ms-list').sortable(
        {
            update: function (event, ui) {
                var lbh = $('#Headers'), id, msvs = new Array();
                $('.ms-selection .ms-list li:visible').each(function () {
                    id = $(this).prop('id').replace('-selection', '');
                    msvs.push(id);
                });
                var opts = lbh.find('option:selected');
                opts.remove();
                $.each(msvs, function (index, item) {
                    lbh.append(opts.filter('[value=' + item + ']').prop('selected', 'selected'));
                });
            }
        }
    );
});
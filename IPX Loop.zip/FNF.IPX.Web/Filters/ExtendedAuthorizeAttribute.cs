﻿
using FNF.IPX.Common;
namespace FNF.IPX.Web.Filters
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Web;
    using System.Web.Helpers;
    using System.Web.Mvc;
    using System.Web.Routing;
    using System.Globalization;
    using System.Threading;
    using System.Security.Principal;

    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = true, AllowMultiple = false)]
    public class ExtendedAuthorizeAttribute : AuthorizeAttribute
    {

        public string[] Permission = null;

        /// <summary>
        /// The name of the master page or view to use when rendering the view on authorization failure.  Default
        /// is null, indicating to use the master page of the specified view.
        /// </summary>
        public virtual string MasterName { get; set; }

        /// <summary>
        /// The name of the view to render on authorization failure.  Default is "Error".
        /// </summary>
        public virtual string ViewName { get; set; }

        public ExtendedAuthorizeAttribute()
            : base()
        {
            this.ViewName = "Error";
        }

        protected void CacheValidateHandler(HttpContext context, object data, ref HttpValidationStatus validationStatus)
        {
            validationStatus = OnCacheAuthorization(new HttpContextWrapper(context));
        }

        public override void OnAuthorization(AuthorizationContext filterContext)
        {


            //CultureInfo culture = CultureInfo.CreateSpecificCulture(CultureInfo.CurrentCulture.Name);
            //var CultureEnGB = new CultureInfo("en-GB");
            //culture.DateTimeFormat = CultureEnGB.DateTimeFormat;
            //culture.NumberFormat = CultureEnGB.NumberFormat;
            //Thread.CurrentThread.CurrentCulture = culture;
            //Thread.CurrentThread.CurrentUICulture = culture;


            if (filterContext == null)
            {
                throw new ArgumentNullException("filterContext");
            }
            var httpContext = filterContext.HttpContext;
            var request = httpContext.Request;
            var response = httpContext.Response;
            var user = httpContext.User;

            if (request.IsAjaxRequest())
            {

                if (AuthorizeCore(filterContext))
                {

                }
                else //if (user.Identity.IsAuthenticated == false)
                {
                    // HandleUnauthorizedRequest will handle request

                    response.StatusCode = (int)HttpStatusCode.Unauthorized;
                    response.SuppressFormsAuthenticationRedirect = true;
                    response.End();
                    filterContext.Result = new HttpUnauthorizedResult();

                }
                //else
                //   response.StatusCode = (int)HttpStatusCode.OK;

            }
            else
            {

                if (AuthorizeCore(filterContext))
                {
                    SetCachePolicy(filterContext);
                }
                else if (!filterContext.HttpContext.User.Identity.IsAuthenticated)
                {
                    // auth failed, redirect to login page
                    filterContext.Result = new HttpUnauthorizedResult();
                }
                else
                {
                    ViewDataDictionary viewData = new ViewDataDictionary();
                    viewData.Add("Message", "You do not have sufficient privileges for this operation.");
                    viewData.Add("ErrorCode", "401");
                    filterContext.Result = new ViewResult { MasterName = this.MasterName, ViewName = this.ViewName, ViewData = viewData };
                }
            }


        }

        protected virtual bool AuthorizeCore(AuthorizationContext filterContext)
        {
            base.OnAuthorization(filterContext);
            if (filterContext.HttpContext == null)
            {
                throw new ArgumentNullException("httpContext");
            }

            var user = filterContext.HttpContext.User;
            if (!user.Identity.IsAuthenticated)
            {
                return false;
            }


            if (Permission != null)
                if (!Permission.Any(user.IsInRole))
                {
                    return false;
                }



            return true;
        }

        protected void SetCachePolicy(AuthorizationContext filterContext)
        {
            // ** IMPORTANT **
            // Since we're performing authorization at the action level, the authorization code runs
            // after the output caching module. In the worst case this could allow an authorized user
            // to cause the page to be cached, then an unauthorized user would later be served the
            // cached page.
            HttpCachePolicyBase cachePolicy = filterContext.HttpContext.Response.Cache;
            cachePolicy.SetProxyMaxAge(new TimeSpan(0));
            cachePolicy.AddValidationCallback(CacheValidateHandler, null /* data */);
        }

        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {

            if (filterContext.HttpContext.Request.IsAjaxRequest())
            {
                filterContext.HttpContext.Response.TrySkipIisCustomErrors = true;
                filterContext.Result = new HttpStatusCodeResult(403, "Sorry, you do not have the required permission to perform this action.");

            }
            else
            {
                var viewResult = new ViewResult();

                ViewDataDictionary viewData = new ViewDataDictionary();
                filterContext.HttpContext.Response.TrySkipIisCustomErrors = true;
                filterContext.HttpContext.Response.StatusCode = 403;
                viewData.Add("Message", "You do not have sufficient privileges for this operation.");
                viewData.Add("ErrorCode", "401");
                filterContext.Result = new ViewResult { MasterName = this.MasterName, ViewName = this.ViewName, ViewData = viewData };

                //viewResult.ViewName = "~/Views/Errors/_Unauthorized.cshtml";
                //filterContext.HttpContext.Response.TrySkipIisCustomErrors = true;
                //filterContext.HttpContext.Response.StatusCode = 403;
                //filterContext.Result = viewResult;
            }

            //   base.HandleUnauthorizedRequest(filterContext);
        }


    }

}
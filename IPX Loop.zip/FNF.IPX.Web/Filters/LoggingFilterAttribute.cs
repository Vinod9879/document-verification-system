﻿using FNF.IPX.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace FNF.IPX.Web.Filters
{


    public class LoggingFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            //filterContext.HttpContext.Trace.Write("(Logging Filter)Action Executing: " +
            //    filterContext.ActionDescriptor.ActionName);

            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Controller:{0}/Action :{1} is executing.. ", filterContext.ActionDescriptor.ControllerDescriptor.ControllerName, filterContext.ActionDescriptor.ActionName);
            LogErrors.WriteLog(sb.ToString());

            base.OnActionExecuting(filterContext);
        }

        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Controller:{0}/Action :{1} has executed.. ", filterContext.ActionDescriptor.ControllerDescriptor.ControllerName , filterContext.ActionDescriptor.ActionName);
            LogErrors.WriteLog(sb.ToString());

            base.OnActionExecuted(filterContext);
        }

    }


    //base control have on excepion Logging
    //public class LoggingFilterAttribute : HandleErrorAttribute
    //{
    //    public override void OnException(ActionExecutedContext filterContext)
    //    {
    //        StringBuilder sb = new StringBuilder();
    //        sb.AppendFormat("Controller:{O}/Action :{1} has error  ", filterContext.ActionDescriptor.ControllerDescriptor, filterContext.ActionDescriptor.ActionName);
    //        sb.AppendFormat("Controller:{O}/");
    //        LogErrors.WriteLog(sb.ToString());

    //        base.OnActionExecuted(filterContext);
    //    }
    //}


}
﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(FNF.IPX.Web.Startup))]
namespace FNF.IPX.Web
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}

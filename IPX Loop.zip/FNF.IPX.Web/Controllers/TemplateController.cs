﻿using FNF.IPX.BusinessLogicLayer.BusinessClasses;
using FNF.IPX.Common;
using FNF.IPX.Models;
using FNF.IPX.Web.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;

namespace FNF.IPX.Web.Controllers
{

    [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.TemplateMenu })]
    public class TemplateController : BaseController
    {
        TemplateBussinessLogic _templateBussiness;
        HeaderBussinessLogic _headerBussiness;
        private TemplateBussinessLogic TemplateBussiness
        {
            get
            {
                if (_templateBussiness == null)
                {
                    _templateBussiness = new TemplateBussinessLogic();
                }
                return _templateBussiness;
            }
        }

        private HeaderBussinessLogic HeaderBussiness
        {
            get
            {
                if (_headerBussiness == null)
                {
                    _headerBussiness = new HeaderBussinessLogic();
                }
                return _headerBussiness;
            }
        }

        #region Constructor
        public TemplateController()
            : base()
        {

        }
        #endregion

        #region Action
        //
        // GET: /Template/
        public ActionResult Index()
        {

            var EmptyModel = new List<TemplateModel>();
            return View(EmptyModel);
        }

        [ValidateAntiForgeryTokenForAjaxPosts]
        public PartialViewResult List(PagingParm PagingParm)
        {


            if (PagingParm.SortColumns.Count == 0)
                PagingParm.SortColumns.Add("CreatedDate", "desc");



            ViewBag.PagingParm = new JavaScriptSerializer().Serialize(PagingParm);

            var model = TemplateBussiness.GetAllPagedItems(PagingParm.FilterColumnNameValue, PagingParm.SortColumns, PagingParm.PageNumber, PagingParm.PageSize).ToList<TemplateModel>();


            return PartialView(model);
        }


        [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.CanAddTemplate })]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public PartialViewResult CreatePartial()
        {
            ViewBag.Title = "Add Template";
            ViewBag.OkButtonName = "Add";
            return PartialView("Save", GetVm(null));
        }

        [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.CanAddTemplate })]
        [HttpPost]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public JsonResult Create(TemplateModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (TemplateBussiness.GetByName(model.Name) == null)
                    {

                        model.CreatedBy = User.Identity.Name;
                        model.CreatedDate = DateTime.Now;

                        TemplateBussiness.FromUI(model, delegate(int id) { return HeaderBussiness.GetById(id); });
                        TemplateBussiness.Save(model);
                        return Json(new { Status = "Success" }, JsonRequestBehavior.AllowGet);
                    }

                    return Json(new { Status = "Failed", Message = "Template already exists" }, JsonRequestBehavior.AllowGet);

                }
                return Json(new { Status = "Failed", Message = "Validation Error" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogErrors.WriteLog(ex);
                return Json(new { Status = "Failed", Message = ex.Message }, JsonRequestBehavior.AllowGet);
            }



        }

        [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.CanAddTemplate })]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public PartialViewResult EditPartial(int id = 0)
        {
            var model = TemplateBussiness.GetById(id);

            ViewBag.Title = "Edit Template";
            ViewBag.OkButtonName = "Save";
            return PartialView("Save", GetVm(model));
        }

        //
        // POST: /User/Edit/5

        [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.CanAddTemplate })]
        [HttpPost]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public JsonResult Edit(TemplateModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {

                    var t = new TemplateBussinessLogic().GetByName(model.Name);
                    if (t == null || t.Id == model.Id)
                    {

                        model.ModifiedBy = User.Identity.Name;
                        model.ModifiedDate = DateTime.Now;

                        TemplateBussiness.FromUI(model, delegate(int id) { return HeaderBussiness.GetById(id); });
                        TemplateBussiness.Update(model);
                        return Json(new { Status = "Success" }, JsonRequestBehavior.AllowGet);
                    }

                    return Json(new { Status = "Failed", Message = "Template already exists" }, JsonRequestBehavior.AllowGet);
                }
                return Json(new { Status = "Failed", Message = "Validation Error" }, JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {
                LogErrors.WriteLog(ex);
                return Json(new { Status = "Failed", Message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }


        [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.CanDeleteTemplate })]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public PartialViewResult DeletePartail(int id = 0)
        {
            var model = TemplateBussiness.GetById(id);
            ViewBag.Title = "Are you sure you want to delete this Template?";
            ViewBag.OkButtonName = "Yes";
            return PartialView("Delete", GetVm(model));
        }

        //
        // POST: /User/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryTokenForAjaxPosts]

        [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.CanDeleteTemplate })]
        public JsonResult DeleteConfirmed(int id)
        {
            try
            {
                TemplateBussiness.Delete(id);
                return Json(new { Status = "Success" }, JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {
                LogErrors.WriteLog(ex);
                if (ex.InnerException.StackTrace.Contains("Mapping"))
                {
                    // var tmeplate = TemplateBussiness.GetById(id);

                    return Json(new { Status = "Failed", Message = "Cannot delete this template because this template is associated to one or more groups " }, JsonRequestBehavior.AllowGet);
                }
                return Json(new { Status = "Failed", Message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [ValidateAntiForgeryTokenForAjaxPosts]
        public PartialViewResult Details(int id = 0)
        {
            var model = TemplateBussiness.GetById(id);
            ViewBag.Title = "Details";
            ViewBag.OkButtonName = null;// hide button
            return PartialView(GetVm(model));
        }

        #endregion

        #region Helper Methods
        TemplateModel GetVm(TemplateModel model)
        {

            TemplateBussiness.ToUI(model);//if null then do not polulated selected items
            model = model == null ? new TemplateModel() : model;
            model.DefaultHeaders = HeaderBussiness.GetAll().OrderBy(o => o.Name).ToList();
            return model;
        }

        #endregion
    }
}
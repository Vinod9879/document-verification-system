﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using System.Threading;
using System.Text;
using System.Globalization;

using FNF.IPX.Common;

namespace FNF.IPX.Web.Controllers
{

    [OutputCache(NoStore = true, Location = System.Web.UI.OutputCacheLocation.None)]
    public class BaseController : Controller
    {
      
        public BaseController()
        {
        }

        protected UserIdentity GetUserInfo
        {
            get { return User.Identity.GetInfo(); }
        }

        protected override void OnException(ExceptionContext filterContext)
        {
            Exception ex = filterContext.Exception;

            var random = new Random();
            string randm = random.Next(10000, 99999).ToString("D5");
            ex.HelpLink = randm;//custom error Code to track cleint screen shot 
            ex.ToMessageAndCompleteStacktrace("Unhandled exception on View");//loggin
            filterContext.ExceptionHandled = true;
            filterContext.Result = new ViewResult()
            {
                ViewName = "Error",
            };

            var v = filterContext.Result as ViewResult;
            v.ViewBag.ErrorCode = ex.HelpLink;//custom error 
            v.ViewBag.Message = ex.Message;
            v.ViewBag.StackTrace = ex.StackTrace;
            v.ViewBag.IsAjaxRequest = HttpContext.Request.IsAjaxRequest();
        }




   

    }
}
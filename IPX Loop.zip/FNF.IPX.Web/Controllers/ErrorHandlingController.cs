﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using FNF.IPX.Common;
namespace FNF.IPX.Web.Controllers
{
    public class ErrorHandlingController : Controller
    {
        //
        // GET: /ErrorHandling/
        public ActionResult Error(int Id = 0, string Ids = "")
        {
            Ids = Ids.Decrypt();
            if (string.IsNullOrEmpty(Ids))
                ViewBag.ErrorCode = Id;// from iis error code custome error section form web.cinfig
            else
                ViewBag.ErrorCode = Ids;
            ViewBag.Message = "";
            ViewBag.StackTrace = "";
            ViewBag.IsAjaxRequest = false;
            return View("Error");
        }
      
    }
}
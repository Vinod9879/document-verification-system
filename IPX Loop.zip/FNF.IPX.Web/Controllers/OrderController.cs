﻿using FNF.IPX.BusinessLogicLayer.BusinessClasses;
using FNF.IPX.Common;
using FNF.IPX.Models;
using FNF.IPX.Web.Filters;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace FNF.IPX.Web.Controllers
{
    [ExtendedAuthorize]
    public class OrderController : BaseController
    {
        private OrderBussinessLogic orderBL;
        private TemplateBussinessLogic templateBL;

        private OrderBussinessLogic OrderBLInstance
        {
            get
            {
                if (orderBL == null)
                {
                    orderBL = new OrderBussinessLogic();
                }
                return orderBL;
            }
        }

        private TemplateBussinessLogic TemplateBLInstance
        {
            get
            {
                if (templateBL == null)
                {
                    templateBL = new TemplateBussinessLogic();
                }
                return templateBL;
            }
        }

        #region Actions

        [AllowAnonymous]
        public ActionResult View1()
        {
            return View();
        }

        public ActionResult Index()
        {
            var orderVM = new OrderMetaModel();

            if (!User.IsInRole(PERMISSION.CanSeeAllOrders))
            {
                orderVM.Search = string.Format("[Sales Price] > {0} ", ConfigurationManager.AppSettings["SalesPriceFilter"]);

                //initialize to show only open orders
                orderVM.Search += CommonStaticClass.ShowOpenOrdersFilter_AND;
            }
            else
            {
                orderVM.Search = CommonStaticClass.ShowOpenOrdersFilter;
            }
            //always first page
            return View(OrderBLInstance.GetOrdersVMForUser(this.GetUserInfo.UserId, orderVM));
        }

        [ExtendedAuthorize(Permission = new string[] { PERMISSION.CanDownload })]
        public FileContentResult Download(string param)
        {
            string templateIds = string.Empty, searchCriteria = string.Empty;
            if(!string.IsNullOrEmpty(param))
            {
                param = param.DecodeAndDecrypt();
                var qArr = param.Split('&');
                templateIds = qArr[0].Substring(qArr[0].IndexOf("=") + 1);
                searchCriteria = qArr[1].Substring(qArr[1].IndexOf("=") + 1);
            }
            if (!string.IsNullOrEmpty(templateIds))
            {
                var results = OrderBLInstance.GetOrdersFromSPForDownload(templateIds, searchCriteria);
                if (results != null && results.Count > 0)
                {
                    StringBuilder sb = new StringBuilder();
                    string format = "\"{0}\",";
                    foreach (IDictionary<string, dynamic> dict in results)
                    {
                        if (sb.Length == 0) //append the header
                        {
                            foreach (KeyValuePair<string, dynamic> kvp in dict)
                                sb.AppendFormat(format, kvp.Key);
                        }
                        sb.AppendLine();
                        foreach (KeyValuePair<string, dynamic> kvp in dict)
                            sb.AppendFormat(format, CommonStaticClass.GetFormattedData(kvp.Key, kvp.Value));
                    }
                    FileContentResult rv = File(new System.Text.UTF8Encoding().GetBytes(sb.ToString()), "text/csv", string.Format("{0}_Order_{1}.csv", GetUserInfo.FirstName + " " + GetUserInfo.Lastname, DateTime.Now.ToString("MMddyyyyHHmm")));
                    sb.Clear();
                    return rv;
                }
                else
                {
                    return null;
                }
            }
            else
            {
                throw new Exception("Error: The current user has not been granted access or group/template is not configured correctly.");
            }
        }
        #endregion

        #region Ajax Actions
        [ValidateAntiForgeryTokenForAjaxPosts]
        public ActionResult GetResults(OrderMetaModel orderVM)
        {
            orderVM = OrderBLInstance.GetOrdersVMForUser(this.GetUserInfo.UserId, orderVM);
            return PartialView(GetPartialView("Order", "_Index"), orderVM);
        }

        [ValidateAntiForgeryTokenForAjaxPosts]
        public ActionResult GetSearchColumns(List<int> templateIds)
        {

            ViewBag.Title = "Order Filter";
            ViewBag.OkButtonName = "Search";

            return PartialView(GetPartialView("Shared", "_Search"), OrderBLInstance.GetHeadersForSearch(templateIds));
        }

        [ValidateAntiForgeryTokenForAjaxPosts]
        public ActionResult GetOrder(int orderId)
        {
            OrderMetaModel vm = new OrderMetaModel();
            vm.OrderDetails = (orderId == 0) ? new OrderDetailsModel() : OrderBLInstance.GetOrderById(orderId);
            
            //Get all templates for current user
            vm.Templates = OrderBLInstance.GetTemplatesForUser(this.GetUserInfo.UserId);

            //Get all headers by templates for current user
            vm.Headers = OrderBLInstance.GetHeaders(vm.Templates);

           
            //OrderMetaModel vm = new OrderMetaModel() { Order2 = (orderid == 0) ? new DataAccess.Order() : db.Orders.Find(orderid), Headers = GetContextHeaders(templateid) };
            return PartialView(GetPartialView("Order", "_Detail"), vm);
        }

        //[ValidateAntiForgeryTokenForAjaxPosts]
        //public ActionResult SaveOrder(OrderMetaModel orderVM)
        //{
        //    if (orderVM != null && orderVM.OrderDetails != null)
        //    {
        //        OrderBLInstance.SaveOrder(orderVM);
        //    }
        //    return new EmptyResult();
        //}

        [ExtendedAuthorize(Permission = new string[] { PERMISSION.CanAssignOrderToUser })]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public PartialViewResult UpdateOrderAssignment(List<int> orderIds, List<string> fileNos, string emailID, string name, int userId)
        {
            OrderBLInstance.UpdateOrderAssignment(orderIds, emailID, name, userId);
            ViewBag.Title = "Orders Assigned";

            ViewBag.Message = string.Format("Orders with {0}(s) {1} have been assigned to {2}.", OrderMetaModel.Str_FileNumber, string.Join(", ", fileNos), name);

            return PartialView("_MessagePopup");
            //return Json("{result: success}", JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="orderId"></param>
        /// <param name="statusId"></param>
        /// <returns></returns>
        [ExtendedAuthorize(Permission = new string[] { PERMISSION.CanUpdateStatuses })]
        [HttpPost]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public JsonResult UpdateOrderStatus(int orderId, string status, string comments)
        {
            OrderBLInstance.UpdateStatusOrFollowUp(orderId, status, comments);
            return Json("{result: success}");
        }


        [ExtendedAuthorize(Permission = new string[] { PERMISSION.CanUpdateFlag })]
        [HttpPost]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public JsonResult UpdateFollowupStatus(int orderId, string flag, string comments)
        {
            OrderBLInstance.UpdateStatusOrFollowUp(orderId, flag, comments, true);
            return Json("{result: success}");
        }

        [HttpPost]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public JsonResult UpdateTrackingFlag(int orderId, string flag)
        {
            OrderBLInstance.UpdateTrackingFlag(orderId, flag);
            return Json("{result: success}");
        }

        [ExtendedAuthorize(Permission = new string[] { PERMISSION.CanDeleteLeads })]
        [HttpPost]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public JsonResult DeleteOrder(int orderId, string comments)
        {
            OrderBLInstance.UpdateDeleteFlag(orderId, comments);
            return Json("{result: success}");

        }

        [ValidateAntiForgeryTokenForAjaxPosts]
        public JsonResult GetOrderAsJson(int orderId)
        {
            var orderVm = OrderBLInstance.GetOrderById(orderId);
            return Json(orderVm, JsonRequestBehavior.AllowGet);
        }

        [ValidateAntiForgeryTokenForAjaxPosts]
        public PartialViewResult GetOrderAsPartialView(int orderid)
        {
            var orderVm = OrderBLInstance.GetOrderById(orderid);
            return PartialView("_ViewOrderDetails", orderVm);
        }

        [ValidateAntiForgeryTokenForAjaxPosts]
        public PartialViewResult GetOrderHistoryAsPartialView(int orderid)
        {
            var orderVm = OrderBLInstance.GetOrderHistoryByOrderId(orderid);
            return PartialView("_OrderHistory", orderVm);
        }
        #endregion

        #region Helper Methods
        string GetPartialView(string folder, string template)
        {
            return string.Format("~/Views/{0}/{1}.cshtml", folder, template);
        }
        #endregion

        protected override void Dispose(bool disposing)
        {
            OrderBLInstance.Dispose();
            TemplateBLInstance.Dispose();
            base.Dispose(disposing);
        }
    }
}
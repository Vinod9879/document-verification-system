﻿using FNF.IPX.BusinessLogicLayer.BusinessClasses;
using FNF.IPX.BusinessLogicLayer.Translators;
using FNF.IPX.Models;
using FNF.IPX.Web.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using FNF.IPX.Common;

namespace FNF.IPX.Web.Controllers
{

    [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.GroupMenu })]
    public class GroupController : BaseController
    {
        #region priavte member
        GroupBussinessLogic _groupBussinessLogic;
        TemplateBussinessLogic _templateBussinessLogic;

        PermissionBussinessLogic _permissionBussinessLogic;
        private GroupBussinessLogic GroupBussiness
        {
            get
            {
                if (_groupBussinessLogic == null)
                {
                    _groupBussinessLogic = new GroupBussinessLogic();
                }
                return _groupBussinessLogic;
            }
        }

        private TemplateBussinessLogic TemplateBussiness
        {
            get
            {
                if (_templateBussinessLogic == null)
                {
                    _templateBussinessLogic = new TemplateBussinessLogic();
                }
                return _templateBussinessLogic;
            }
        }

        private PermissionBussinessLogic PermissionBussiness
        {
            get
            {
                if (_permissionBussinessLogic == null)
                {
                    _permissionBussinessLogic = new PermissionBussinessLogic();
                }
                return _permissionBussinessLogic;
            }
        }
        #endregion

        #region Constructor
        public GroupController()
            : base()
        {

        }
        #endregion

        #region Action
        //
        // GET: /Template/
        public ActionResult Index()
        {

            var EmptyModel = new List<GroupModel>();

            return View(EmptyModel);
        }


        [ValidateAntiForgeryTokenForAjaxPosts]
        public PartialViewResult List(PagingParm PagingParm)
        {


            if (PagingParm.SortColumns.Count == 0)
                PagingParm.SortColumns.Add("CreatedDate", "desc");



            ViewBag.PagingParm = new JavaScriptSerializer().Serialize(PagingParm);

            var model = GroupBussiness.GetAllPagedItems(PagingParm.FilterColumnNameValue, PagingParm.SortColumns, PagingParm.PageNumber, PagingParm.PageSize).ToList<GroupModel>();


            return PartialView(model);
        }




        [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.CanAddGroup })]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public PartialViewResult CreatePartial()
        {
            ViewBag.Title = "Add Group";
            ViewBag.OkButtonName = "Add";
            return PartialView("Save", GetVm(null));
        }

        [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.CanAddGroup })]
        [HttpPost]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public JsonResult Create(GroupModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (GroupBussiness.GetByName(model.Name) == null)
                    {
                        model.CreatedBy = User.Identity.Name;
                        model.CreatedDate = DateTime.Now;
                        if (model.SelectedPermission != null)
                            GroupBussiness.FromUI(model, delegate(int id) { return PermissionBussiness.GetById(id); });
                        GroupBussiness.FromUI(model, delegate(int id) { return TemplateBussiness.GetById(id); });
                        GroupBussiness.Save(model);
                        return Json(new { Status = "Success" }, JsonRequestBehavior.AllowGet);
                    }

                    return Json(new { Status = "Failed", Message = "Group already exists" }, JsonRequestBehavior.AllowGet);
                }
                return Json(new { Status = "Failed", Message = "Validation Error" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogErrors.WriteLog(ex);
                return Json(new { Status = "Failed", Message = ex.Message }, JsonRequestBehavior.AllowGet);
            }



        }

        [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.CanAddGroup })]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public PartialViewResult EditPartial(int id = 0)
        {
            var model = GroupBussiness.GetById(id);

            ViewBag.Title = "Edit Group";
            ViewBag.OkButtonName = "Save";
            return PartialView("Save", GetVm(model));
        }

        //
        // POST: /User/Edit/5

        [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.CanAddGroup })]
        [HttpPost]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public JsonResult Edit(GroupModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var g=new GroupBussinessLogic().GetByName(model.Name);
                    if (g == null || g.Id==model.Id )
                    {
                        model.ModifiedBy = User.Identity.Name;
                        model.ModifiedDate = DateTime.Now;

                        if (model.SelectedPermission != null)
                            GroupBussiness.FromUI(model, delegate(int id) { return PermissionBussiness.GetById(id); });
                        GroupBussiness.FromUI(model, delegate(int id) { return TemplateBussiness.GetById(id); });
                        GroupBussiness.Update(model);
                        return Json(new { Status = "Success" }, JsonRequestBehavior.AllowGet);
                    }

                    return Json(new { Status = "Failed", Message = "Group already exists" }, JsonRequestBehavior.AllowGet);
                }
                return Json(new { Status = "Failed", Message = "Validation Error" }, JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {
                LogErrors.WriteLog(ex);
                return Json(new { Status = "Failed", Message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }


        [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.CanDeleteGroup })]

        [ValidateAntiForgeryTokenForAjaxPosts]
        public PartialViewResult DeletePartail(int id = 0)
        {
            var model = GroupBussiness.GetById(id);
            ViewBag.Title = "Are you sure you want to delete this Group?";
            ViewBag.OkButtonName = "Yes";
            return PartialView("Delete", GetVm(model));
        }

        //
        // POST: /User/Delete/5

        [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.CanDeleteGroup })]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public JsonResult DeleteConfirmed(int id)
        {
            try
            {
                GroupBussiness.Delete(id);
                return Json(new { Status = "Success" }, JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {
                LogErrors.WriteLog(ex);

                if (ex.InnerException.StackTrace.Contains("Mapping"))
                {
                    // var tmeplate = TemplateBussiness.GetById(id);

                    return Json(new { Status = "Failed", Message = " Cannot delete this group because this group is associated to one or more users" }, JsonRequestBehavior.AllowGet);
                }
                return Json(new { Status = "Failed", Message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [ValidateAntiForgeryTokenForAjaxPosts]
        public PartialViewResult Details(int id = 0)
        {
            var model = GroupBussiness.GetById(id);
            ViewBag.Title = "Details";
            ViewBag.OkButtonName = null;// hide button
            return PartialView(GetVm(model));
        }

        #endregion

        #region Helper Methods
        GroupModel GetVm(GroupModel model)
        {

            GroupBussiness.ToUI(model);//if null then do not polulated selected items
            model = model == null ? new GroupModel() : model;
            model.DeafiltTemplates = TemplateBussiness.GetAll().OrderBy(o => o.Name).ToList();
            model.DefaultPermission = PermissionBussiness.GetAll().OrderBy(o => o.Module).ToList();
            return model;
        }

        #endregion
    }
}
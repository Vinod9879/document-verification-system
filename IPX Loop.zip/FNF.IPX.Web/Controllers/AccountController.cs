﻿using System;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.Owin.Security;
using FNF.IPX.Common;
using FNF.IPX.Models;
using FNF.IPX.BusinessLogicLayer.BusinessClasses;
using System.Configuration;


namespace FNF.IPX.Web.Controllers
{
    [Authorize]
    public class AccountController : BaseController
    {
        private UserBussinessLogic userBL;
        private UserBussinessLogic UserBussiness
        {
            get
            {
                if (userBL == null)
                {
                    userBL = new UserBussinessLogic();
                }
                return userBL;
            }
        }

        private LoginDetailsBussinessLogic userLoginDetailsBL;
        private LoginDetailsBussinessLogic UserLoginDetailsBussiness
        {
            get
            {
                if (userLoginDetailsBL == null)
                {
                    userLoginDetailsBL = new LoginDetailsBussinessLogic();
                }
                return userLoginDetailsBL;
            }
        }

        // GET: /Account/Login
        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }

        //
        // POST: /Account/Login
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Login(LoginViewModel model, string returnUrl)
        {
            if (ModelState.IsValid)
            {

                bool IsUserAuthenticated = false;

                UserLoginBussinessLogic userLoginBll = new UserLoginBussinessLogic();

                string encodedUserName = Microsoft.Security.Application.Encoder.LdapFilterEncode(model.UserName);
                string encodedPassword = Microsoft.Security.Application.Encoder.LdapFilterEncode(model.Password);

                encodedUserName = HttpUtility.HtmlEncode(encodedUserName);
                encodedPassword = HttpUtility.HtmlEncode(encodedPassword);

                //var user = UserBussiness.GetUserByUserName(encodedUserName);
                var user = UserBussiness.GetUserByUserName(model.UserName);

                if (user != null)
                {
             

                  string _path= ConfigurationManager.AppSettings["LDAPPath"];
                  string _domain = ConfigurationManager.AppSettings["LDAPDomain"];
                  string _server = ConfigurationManager.AppSettings["LDAPServer"];

                  LdapAuthentication ldapAuthentication = new LdapAuthentication(_path, _domain, _server);

                    bool isValid = false;
                    try
                    {
                        //isValid = ldapAuthentication.IsAuthenticated(encodedUserName, encodedPassword);
                        isValid = ldapAuthentication.IsAuthenticated(model.UserName, model.Password);
                    }
                    catch (Exception ex)
                    {
                        LogErrors.WriteLog("LDAP failed with following reason for the user " + encodedUserName);
                        LogErrors.WriteLog(ex);
                    }
                  

                    if (isValid == true)
                        IsUserAuthenticated = true;

                }
                else
                {
                    LogErrors.WriteLog("User not found in Database User Name :" + encodedUserName);
                }
                //else
                //{
                //    var userDb = userLoginBll.ValidateUserByEmailIDPassword(model.EMailID, model.Password.Encrypt());

                //    if (userDb != null)
                //    {
                //        IsUserAuthenticated = true;
                //        user = userDb;
                //    }
                //}


                //var user = userLoginBll.ValidateUserByEmailIDPassword(model.EMailID, model.Password.Encrypt());

                if (IsUserAuthenticated == true)
                {
                    ClaimsIdentity claims = new ClaimsIdentity(DefaultAuthenticationTypes.ApplicationCookie);
                    claims.AddClaim(new Claim(ClaimTypes.NameIdentifier, user.UserID.ToString()));
                    claims.AddClaim(new Claim(ClaimTypes.Name, user.UserName == null ? "" : user.UserName));
                    claims.AddClaim(new Claim(ClaimTypes.Email, user.EMailID));
                    claims.AddClaim(new Claim("FirstName", user.FirstName));
                    claims.AddClaim(new Claim("LastName", user.LastName != null ? user.LastName : string.Empty));

                    //Aug 2017 Changes - Record Login
                    var loginId = RecordLogin(user);

                    //Aug 2017 Changes - Login statistics
                    claims.AddClaim(new Claim("LoginId", loginId.ToString()));

                    if (user.Permission != null)
                        foreach (var p in user.Permission)
                            claims.AddClaim(new Claim(ClaimTypes.Role, p.Trim()));

                    if (user.GroupDefaults != null)
                        foreach (var g in user.GroupDefaults)
                            claims.AddClaim(new Claim("Group", g.Name.Trim()));


                    await SignInAsync(claims, model.RememberMe);

                    return RedirectToLocal(returnUrl);
                }
                else
                {
                    ModelState.AddModelError("", "Invalid username or password.");
                }

            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }

        private int RecordLogin(UserModel user)
        {
            var sessionTimeout = Convert.ToInt32(ConfigurationManager.AppSettings["SessionTimeout"]);

            var objLoginDetails = new UserLoginDetailsModel();
            objLoginDetails.Username = user.UserName == null ? "" : user.UserName;
            objLoginDetails.FullName = user.FirstName + " " + user.LastName;
            objLoginDetails.LoginTime = DateTime.Now;
            objLoginDetails.LogoutTime = DateTime.Now.AddMinutes(sessionTimeout);
            objLoginDetails.Duration = Convert.ToInt32(((TimeSpan)(objLoginDetails.LogoutTime - objLoginDetails.LoginTime)).TotalMinutes) + " Minute(s)";
            return UserLoginDetailsBussiness.Save(objLoginDetails);
        }

        private void RecordLogoff()
        {
            var loginId = Convert.ToInt32(User.Identity.GetInfo().LoginId);
            if (loginId > 0)
            {
                UserLoginDetailsBussiness.UpdateByLoginId(loginId);
            }
            else
            {
                LogErrors.WriteLog("LoginID is not recorded or empty, hence could not update logout time", LogMessageType.WARNING);
            }
        }


        //
        // POST: /Account/LogOff
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            //Aug 2017 Changes - Record Logoff
            RecordLogoff();

            AuthenticationManager.SignOut();
            return RedirectToAction("Index", "Order");
        }


        public PartialViewResult ManageView()
        {
            var model = new ChangePasswordViewModel();
            model.Email = User.Identity.GetInfo().Email;

            ViewBag.Title = "Change Password";
            ViewBag.OkButtonName = "Save";

            return PartialView("_Manage", model);
        }

        [HttpPost]
        public JsonResult Manage(ChangePasswordViewModel model)
        {
            try
            {
                UserBussinessLogic UserBussiness = new UserBussinessLogic();
                if (ModelState.IsValid)
                {

                    model.userId = User.Identity.GetInfo().UserId;

                    UserBussiness.ChangePassword(model.userId, model.Password.Encrypt());


                    return Json(new { Status = "Success" }, JsonRequestBehavior.AllowGet);

                }
                return Json(new { Status = "Failed", Message = "Validation Error" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogErrors.WriteLog("UserController/Create error");
                LogErrors.WriteLog(ex);
                return Json(new { Status = "Failed", Message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }



        #region Helpers
        // Used for XSRF protection when adding external logins
        private const string XsrfKey = "XsrfId123abc@";

        private IAuthenticationManager AuthenticationManager
        {
            get
            {
                return HttpContext.GetOwinContext().Authentication;
            }
        }


        private async Task SignInAsync(ClaimsIdentity identity, bool isPersistent)
        {
            AuthenticationManager.SignOut(DefaultAuthenticationTypes.ExternalCookie);
            //var identity = await UserManager.CreateIdentityAsync(user, DefaultAuthenticationTypes.ApplicationCookie);
            AuthenticationManager.SignIn(new AuthenticationProperties() { IsPersistent = isPersistent }, identity);

        }


        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error);
            }
        }



        public enum ManageMessageId
        {
            ChangePasswordSuccess,
            SetPasswordSuccess,
            RemoveLoginSuccess,
            Error
        }

        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl) && !returnUrl.Contains("Account"))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction("Index", "Order");
            }
        }

        private class ChallengeResult : HttpUnauthorizedResult
        {
            public ChallengeResult(string provider, string redirectUri)
                : this(provider, redirectUri, null)
            {
            }

            public ChallengeResult(string provider, string redirectUri, string userId)
            {
                LoginProvider = provider;
                RedirectUri = redirectUri;
                UserId = userId;
            }

            public string LoginProvider { get; set; }
            public string RedirectUri { get; set; }
            public string UserId { get; set; }

            public override void ExecuteResult(ControllerContext context)
            {
                var properties = new AuthenticationProperties() { RedirectUri = RedirectUri };
                if (UserId != null)
                {
                    properties.Dictionary[XsrfKey] = UserId;
                }
                context.HttpContext.GetOwinContext().Authentication.Challenge(properties, LoginProvider);
            }
        }
        #endregion
    }
}
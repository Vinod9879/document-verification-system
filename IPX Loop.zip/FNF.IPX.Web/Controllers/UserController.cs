﻿namespace WebApp.Controllers
{
    using System;
    using System.Linq;
    using System.Web;
    using System.Web.Mvc;
    using System.Data.Entity;
    using System.Collections.Generic;
    using FNF.IPX.Web.Controllers;
    using System.Threading.Tasks;
    using FNF.IPX.BusinessLogicLayer;
    using FNF.IPX.Models;
    using FNF.IPX.BusinessLogicLayer.BusinessClasses;
    using FNF.IPX.Common;
    using FNF.IPX.Web.Filters;
    using System.Web.Script.Serialization;
    using System.Configuration;


    [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.UserMenu })]
    public class UserController : BaseController
    {
        private UserBussinessLogic userBL;
        private GroupBussinessLogic groupBL;
        private StateBussinessLogic stateBL;
        private FlashCodeBusinessLogic flashBL;
        private UserBussinessLogic UserBussiness
        {
            get
            {
                if (userBL == null)
                {
                    userBL = new UserBussinessLogic();
                }
                return userBL;
            }
        }

        private GroupBussinessLogic GroupBLInstance
        {
            get
            {
                if (groupBL == null)
                {
                    groupBL = new GroupBussinessLogic();
                }
                return groupBL;
            }
        }

        private StateBussinessLogic StateBLInstance
        {
            get
            {
                if (stateBL == null)
                {
                    stateBL = new StateBussinessLogic();
                }
                return stateBL;
            }
        }

        private FlashCodeBusinessLogic FlashBLInstance
        {
            get
            {
                if(flashBL == null)
                {
                    flashBL = new FlashCodeBusinessLogic();
                }
                return flashBL;
            }
        }

        #region Constructor
        public UserController()
            : base()
        {

        }
        #endregion

        #region Actions

        public ActionResult Index()
        {

            var EmptyModel = new List<UserModel>();

            return View(EmptyModel);
        }


        [ValidateAntiForgeryTokenForAjaxPosts]
        public PartialViewResult List(PagingParm PagingParm)
        {


            if (PagingParm.SortColumns.Count == 0)
                PagingParm.SortColumns.Add("CreatedDate", "desc");

            

            ViewBag.PagingParm = new JavaScriptSerializer().Serialize(PagingParm);

            var model = UserBussiness.GetAllPagedItems(PagingParm.FilterColumnNameValue, PagingParm.SortColumns, PagingParm.PageNumber, PagingParm.PageSize).ToList<UserModel>();


            return PartialView(model);
        }



        [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.CanAddUser })]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public PartialViewResult CreatePartial()
        {
            ViewBag.Title = "Add User";
            ViewBag.OkButtonName = "Add";
            return PartialView("Save", GetVm(null));
        }


        [HttpPost]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public JsonResult ValidateLADPUserName(string userName)
        {
            string _path = ConfigurationManager.AppSettings["LDAPPath"];
            string _domain = ConfigurationManager.AppSettings["LDAPDomain"];
            string _server = ConfigurationManager.AppSettings["LDAPServer"];



            LdapAuthentication ldapAuthentication = new LdapAuthentication(_path, _domain, _server);

          
            bool isValid = false;
            try
            {
                isValid = ldapAuthentication.CheckUserAvailability(userName);
                if (isValid==true)
                {
                    return Json(new { Status = "true"}, JsonRequestBehavior.AllowGet);  
                }
            }
            catch (Exception ex)
            {
                string exErrorMsg = ex.Message;
            }

            return Json(new { Status = "false"}, JsonRequestBehavior.AllowGet);     
        }

        [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.CanAddUser })]
        [HttpPost]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public JsonResult Create(UserModel model)
        {
            try
            {
                //if (ModelState.IsValid)
                //{

                    var user=UserBussiness.GetUserByUserName(model.UserName);
                    if (user==null )
                    {
                        user = UserBussiness.GetUserByEmailId(model.EMailID);
                        if (user == null)
                        {
                            model.CreatedBy = User.Identity.Name;
                            model.CreatedDate = DateTime.Now;
                            SaveUser(model);
                            return Json(new { Status = "Success" }, JsonRequestBehavior.AllowGet);
                        }
                        else
                        {
                            return Json(new { Status = "Failed", Message = "Email Id already in use" });
                        }
                    }
                    else
                    {
                        return Json(new { Status = "Failed", Message = "UserName already in use" }, JsonRequestBehavior.AllowGet);
  
                    }
                 
                   
                //}
               // return Json(new { Status = "Failed", Message = "Validation Error" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogErrors.WriteLog("UserController/Create error");
                LogErrors.WriteLog(ex);
                return Json(new { Status = "Failed", Message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }


        [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.CanAddUser })]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public PartialViewResult EditPartial(int id = 0)
        {
            var model = UserBussiness.GetUserById(id);
            model.Password = model.Password.Decrypt();

            ViewBag.Title = "Edit User";
            ViewBag.OkButtonName = "Save";
            return PartialView("Save", GetVm(model));
        }


        [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.CanAddUser })]
        [HttpPost]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public ActionResult Edit(UserModel model)
        {
            try
            {
               // if (ModelState.IsValid)
                //{
                   
                    model.ModifiedBy = User.Identity.Name;
                    model.ModifiedDate = DateTime.Now;
                    SaveUser(model);
                    return Json(new { Status = "Success" }, JsonRequestBehavior.AllowGet);
               // }
                //return Json(new { Status = "Failed", Message = "Validation Error" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogErrors.WriteLog("UserController/Edit error");
                LogErrors.WriteLog(ex);
                return Json(new { Status = "Failed", Message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.CanDeleteUser })]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public PartialViewResult DeletePartail(int id = 0)
        {
            var model = UserBussiness.GetUserById(id);
            ViewBag.Title = "Are you sure you want to delete this User?";
            ViewBag.OkButtonName = "Yes";
            return PartialView("Delete", GetVm(model));
        }

        //
        // POST: /User/Delete/5
        [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.CanDeleteUser })]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                UserBussiness.DeleteUser(id);
                return Json(new { Status = "Success" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogErrors.WriteLog("UserController/Delete error");
                LogErrors.WriteLog(ex);
                return Json(new { Status = "Failed", Message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [ValidateAntiForgeryTokenForAjaxPosts]
        public PartialViewResult Details(int id = 0)
        {
            var model = UserBussiness.GetUserById(id);
            ViewBag.Title = "Details";
            ViewBag.OkButtonName = null;// hide button
            return PartialView(GetVm(model));
        }

        #endregion

        #region Helper Methods
        UserModel GetVm(UserModel user)
        {
            user = user == null ? new UserModel() : user;
            user.GroupDefaults = GroupBLInstance.GetAll().OrderBy(o => o.Name).ToList();
            user.StateDefaults = StateBLInstance.GetStates().OrderBy(o => o.Code).ToList();
            user.FlashCodeDefaults = FlashBLInstance.GetFlashDetails().OrderBy(o => o.Code).ToList();
            //UserBLInstance.ToUI(user);

            return user;
        }

        void SaveUser(UserModel vm)
        {
            if (vm.Password !=null)
            {
                vm.Password = vm.Password.Encrypt();
            }
            UserBussiness.FromUI(vm, delegate(int g) { return GroupBLInstance.GetById(g); });

            if (vm.SelectedStates != null)
            {
                vm.StateDefaults = StateBLInstance.GetStates()
                                                        .Where(t => vm.SelectedStates.Any(s => s == t.Id)).ToList();

                //vm.FromUIforState(delegate(string s) { return db.States.Find(s); });
            }

            if(vm.SelectedFlashCodes != null)
            {
                vm.FlashCodeDefaults = FlashBLInstance
                                        .GetFlashDetails()
                                        .Where(t => vm.SelectedFlashCodes.Any(s => s == t.Id)).ToList();
            }
            UserBussiness.SaveUser(vm);
        }






        #endregion

        protected override void Dispose(bool disposing)
        {
            this.GroupBLInstance.Dispose();
            this.StateBLInstance.Dispose();
            this.FlashBLInstance.Dispose();
            this.UserBussiness.Dispose();

            base.Dispose(disposing);
        }
    }
}
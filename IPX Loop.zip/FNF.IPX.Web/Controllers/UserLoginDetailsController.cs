﻿namespace WebApp.Controllers
{
    using System;
    using System.Linq;
    using System.Web;
    using System.Web.Mvc;
    using System.Data.Entity;
    using System.Collections.Generic;
    using FNF.IPX.Web.Controllers;
    using System.Threading.Tasks;
    using FNF.IPX.BusinessLogicLayer;
    using FNF.IPX.Models;
    using FNF.IPX.BusinessLogicLayer.BusinessClasses;
    using FNF.IPX.Common;
    using FNF.IPX.Web.Filters;
    using System.Web.Script.Serialization;
    using System.Configuration;


    [ExtendedAuthorizeAttribute(Permission = new string[] { PERMISSION.LoginStatisticsMenu })]
    public class UserLoginDetailsController : BaseController
    {
        private LoginDetailsBussinessLogic userLoginDetailsBL;
        private LoginDetailsBussinessLogic UserLoginDetailsBussiness
        {
            get
            {
                if (userLoginDetailsBL == null)
                {
                    userLoginDetailsBL = new LoginDetailsBussinessLogic();
                }
                return userLoginDetailsBL;
            }
        }

        #region Constructor
        public UserLoginDetailsController()
            : base()
        {

        }
        #endregion

        public ActionResult Index()
        {

            var EmptyModel = new List<UserLoginDetailsModel>();

            return View(EmptyModel);
        }


        [ValidateAntiForgeryTokenForAjaxPosts]
        public PartialViewResult List(PagingParm PagingParm)
        {
            if (PagingParm.SortColumns.Count == 0)
                PagingParm.SortColumns.Add("LoginTime", "desc");

            ViewBag.PagingParm = new JavaScriptSerializer().Serialize(PagingParm);

            var model = UserLoginDetailsBussiness.GetAllPagedItems(PagingParm.FilterColumnNameValue, PagingParm.SortColumns, PagingParm.PageNumber, PagingParm.PageSize).ToList<UserLoginDetailsModel>();
            return PartialView(model);
        }

        protected override void Dispose(bool disposing)
        {
            this.UserLoginDetailsBussiness.Dispose();

            base.Dispose(disposing);
        }
    }
}
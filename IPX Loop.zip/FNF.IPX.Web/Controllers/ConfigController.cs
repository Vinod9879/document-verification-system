﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FNF.IPX.Common;
using FNF.IPX.Web.Filters;
using FNF.IPX.Web.Models;

namespace FNF.IPX.Web.Controllers
{
    //[ExtendedAuthorize(Permission = new string[] { PERMISSION.UserMenu, PERMISSION.TemplateMenu, PERMISSION.GroupMenu})]
    public class ConfigController : BaseController
    {
        //
        // GET: /Config/
        public ActionResult Index()
        {
            return View("Common");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Encrypt(Generic gen)
        {
            if (gen != null)
            {
                gen.Value = gen.Field.Encrypt();
                return View("Common", gen);
            }
            else
            {
                ViewBag.Message = "Could not get input values";
                return View("Common");
            }
        }
	}
}
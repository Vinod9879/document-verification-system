﻿using FNF.IPX.BusinessLogicLayer.BusinessClasses;
using FNF.IPX.Common;
using FNF.IPX.Models;
using FNF.IPX.Web.Filters;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace FNF.IPX.Web.Controllers
{
    [ExtendedAuthorize]
    public class OrderArchiveController : BaseController
    {
        private OrderBussinessLogic orderBL;
        private OrderArchiveBussinessLogic orderArchiveBL;
        private TemplateBussinessLogic templateBL;

        private OrderBussinessLogic OrderBLInstance
        {
            get
            {
                if (orderBL == null)
                {
                    orderBL = new OrderBussinessLogic();
                }
                return orderBL;
            }
        }

        private OrderArchiveBussinessLogic OrderArchiveBLInstance
        {
            get
            {
                if (orderArchiveBL == null)
                {
                    orderArchiveBL = new OrderArchiveBussinessLogic();
                }
                return orderArchiveBL;
            }
        }

        private TemplateBussinessLogic TemplateBLInstance
        {
            get
            {
                if (templateBL == null)
                {
                    templateBL = new TemplateBussinessLogic();
                }
                return templateBL;
            }
        }

        #region Actions

        [AllowAnonymous]
        public ActionResult View1()
        {
            return View();
        }

        public ActionResult Index()
        {
            var orderVM = new OrderMetaArchiveModel();

            if (!User.IsInRole(PERMISSION.CanSeeAllOrders))
            {
                orderVM.Search = string.Format("[Sales Price] > {0} AND ", ConfigurationManager.AppSettings["SalesPriceFilter"]);

                //initialize to show only open orders
                //orderVM.Search += CommonStaticClass.ShowOpenOrdersFilter_AND;
            }
            orderVM.Search += string.Format("[Date Opened] >= '{0}' ", DateTime.Now.AddYears(-Convert.ToInt32(ConfigurationManager.AppSettings["ShowArchiveForYears"])).ToString(GeneralConstants.DateFormat));

            //always first page
            return View(OrderArchiveBLInstance.GetOrdersVMForUser(this.GetUserInfo.UserId, orderVM));
        }

        [ExtendedAuthorize(Permission = new string[] { PERMISSION.CanDownload })]
        public FileContentResult Download(string param)
        {
            string templateIds = string.Empty, searchCriteria = string.Empty;
            if (!string.IsNullOrEmpty(param))
            {
                param = param.DecodeAndDecrypt();
                var qArr = param.Split('&');
                templateIds = qArr[0].Substring(qArr[0].IndexOf("=") + 1);
                searchCriteria = qArr[1].Substring(qArr[1].IndexOf("=") + 1);
            }
            if (!string.IsNullOrEmpty(templateIds))
            {
                var results = OrderArchiveBLInstance.GetOrdersFromSPForDownload(templateIds, searchCriteria);
                if (results != null && results.Count > 0)
                {
                    StringBuilder sb = new StringBuilder();
                    string format = "\"{0}\",";
                    foreach (IDictionary<string, dynamic> dict in results)
                    {
                        if (sb.Length == 0) //append the header
                        {
                            foreach (KeyValuePair<string, dynamic> kvp in dict)
                                sb.AppendFormat(format, kvp.Key);
                        }
                        sb.AppendLine();
                        foreach (KeyValuePair<string, dynamic> kvp in dict)
                            sb.AppendFormat(format, CommonStaticClass.GetFormattedData(kvp.Key, kvp.Value));
                    }
                    FileContentResult rv = File(new System.Text.UTF8Encoding().GetBytes(sb.ToString()), "text/csv", string.Format("{0}_Order_{1}.csv", GetUserInfo.FirstName + " " + GetUserInfo.Lastname, DateTime.Now.ToString("MMddyyyyHHmm")));
                    sb.Clear();
                    return rv;
                }
                else
                {
                    return null;
                }
            }
            else
            {
                throw new Exception("Error: The current user has not been granted access or group/template is not configured correctly.");
            }
        }
        #endregion

        #region Ajax Actions
        [ValidateAntiForgeryTokenForAjaxPosts]
        public ActionResult GetResults(OrderMetaArchiveModel orderVM)
        {
            orderVM = OrderArchiveBLInstance.GetOrdersVMForUser(this.GetUserInfo.UserId, orderVM);
            return PartialView(GetPartialView("OrderArchive", "_Index"), orderVM);
        }

        [ValidateAntiForgeryTokenForAjaxPosts]
        public ActionResult GetSearchColumns(List<int> templateIds)
        {
            ViewBag.Title = "Order Filter";
            ViewBag.OkButtonName = "Search";

            return PartialView(GetPartialView("Shared", "_Search"), OrderBLInstance.GetHeadersForSearch(templateIds));
        }

        [HttpPost]
        [ValidateAntiForgeryTokenForAjaxPosts]
        public JsonResult UpdateTrackingFlag(int orderId, string flag)
        {
            OrderArchiveBLInstance.UpdateTrackingFlag(orderId, flag);
            return Json("{result: success}");
        }

        [ValidateAntiForgeryTokenForAjaxPosts]
        public JsonResult GetOrderAsJson(int orderId)
        {
            var orderVm = OrderArchiveBLInstance.GetOrderById(orderId);
            return Json(orderVm, JsonRequestBehavior.AllowGet);
        }

        [ValidateAntiForgeryTokenForAjaxPosts]
        public PartialViewResult GetOrderAsPartialView(int orderid)
        {
            var orderVm = OrderArchiveBLInstance.GetOrderById(orderid);
            return PartialView("_ViewOrderDetails", orderVm);
        }

        [ValidateAntiForgeryTokenForAjaxPosts]
        public PartialViewResult GetOrderHistoryAsPartialView(int orderid)
        {
            var orderVm = OrderArchiveBLInstance.GetOrderHistoryByOrderId(orderid);
            return PartialView("_OrderHistory", orderVm);
        }
        #endregion

        #region Helper Methods
        string GetPartialView(string folder, string template)
        {
            return string.Format("~/Views/{0}/{1}.cshtml", folder, template);
        }
        #endregion

        protected override void Dispose(bool disposing)
        {
            OrderArchiveBLInstance.Dispose();
            OrderBLInstance.Dispose();
            TemplateBLInstance.Dispose();
            base.Dispose(disposing);
        }
    }
}
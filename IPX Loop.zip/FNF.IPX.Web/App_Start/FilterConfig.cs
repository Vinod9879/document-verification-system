﻿using FNF.IPX.Web.Filters;
using System.Web;
using System.Web.Mvc;

namespace FNF.IPX.Web
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());

            filters.Add(new LoggingFilterAttribute());
        }
    }
}

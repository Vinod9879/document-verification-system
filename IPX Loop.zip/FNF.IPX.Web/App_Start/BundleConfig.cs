﻿using System.Web;
using System.Web.Optimization;

namespace FNF.IPX.Web
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                          "~/Scripts/jquery-{version}.js", 
                          "~/Scripts/jquery-ui.js", 
                          "~/Scripts/jquery.multi-select.js",
                          "~/Scripts/UtilityScripts.js"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                        "~/Scripts/bootstrap.js", "~/Scripts/common.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.unobtrusive*",
                        "~/Scripts/jquery.validate*"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/duallistbox").Include(
                        "~/Scripts/jquery.bootstrap-duallistbox.js"));

            bundles.Add(new StyleBundle("~/Content/css").Include("~/Content/bootstrap.css"
                //, "~/Content/AdminLTE.css"
                , "~/Content/jquery-ui.css"
                , "~/Content/jquery-ui.structure.css"
                , "~/Content/jquery-ui.theme.css"
                , "~/Content/multi-select.css"
                , "~/Content/Site.css"
                ));

            bundles.Add(new StyleBundle("~/Content/jqueryui").Include(
                        "~/Content/jquery-ui.css"
                        ));

            bundles.Add(new StyleBundle("~/Content/duallistbox").Include(
                        "~/Content/bootstrap-duallistbox.css"
                        ));
        }
    }
}

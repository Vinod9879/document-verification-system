﻿using FNF.IPX.DataEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FNF.IPX.DataAccessLayer
{
    public class UnitofWork : IDisposable
    {
        public IPXEntities Context;
        private GenericRepository<UserDetails> userRepository;
        private GenericRepository<GroupMaster> groupRepository;
        private GenericRepository<Template> templateRepository;
        private GenericRepository<HeaderMaster> headerRepository;
        private GenericRepository<OrderDetails> ordersRepository;
        private GenericRepository<OrderDetails_Archive> ordersArchiveRepository;
        private GenericRepository<OrderStatus> orderStatusRepository;
        private GenericRepository<OrderHistory> orderHistoryRepository;
        private GenericRepository<OrderHistory_Archive> orderHistoryArchiveRepository;
        private GenericRepository<StateMaster> stateRepository;
        private GenericRepository<PermissionMaster> permissionMasterRepository;
        private GenericRepository<FollowUpFlagsMaster> followUpFlagsMasterRepository;
        private GenericRepository<SalesRep> salesRepRepository;
        private GenericRepository<IPXSalesRep> ipxSalesRepRepository;
        private GenericRepository<HeaderTemplateAssociation> headerTemplateAssociationRepository;
        private GenericRepository<FlashCode> flashCodeRepository;
        private GenericRepository<TrackFlagsMaster> trackFlagsMasterRepository;
        private GenericRepository<UserLoginDetails> userLoginDetailsRepository;

        public UnitofWork(IPXEntities context)
        {
            this.Context = context;
        }

        public GenericRepository<UserDetails> UserRepository
        {
            get
            {
                if(userRepository == null)
                {
                    userRepository = new GenericRepository<UserDetails>(Context);
                }
                return userRepository;
            }
        }

        public GenericRepository<GroupMaster> GroupRepository
        {
            get
            {
                if (groupRepository == null)
                {
                    groupRepository = new GenericRepository<GroupMaster>(Context);
                }
                return groupRepository;
            }
        }
     
        public GenericRepository<Template> TemplateRepository
        {
            get
            {
                if (templateRepository == null)
                {
                    templateRepository = new GenericRepository<Template>(Context);
                }
                return templateRepository;
            }
        }

        public GenericRepository<HeaderMaster> HeaderRepository
        {
            get
            {
                if (headerRepository == null)
                {
                    headerRepository = new GenericRepository<HeaderMaster>(Context);
                }
                return headerRepository;
            }
        }

        public GenericRepository<OrderDetails> OrdersRepository
        {
            get
            {
                if (ordersRepository == null)
                {
                    ordersRepository = new GenericRepository<OrderDetails>(Context);
                }
                return ordersRepository;
            }
        }

        public GenericRepository<OrderDetails_Archive> OrdersArchiveRepository
        {
            get
            {
                if (ordersArchiveRepository == null)
                {
                    ordersArchiveRepository = new GenericRepository<OrderDetails_Archive>(Context);
                }
                return ordersArchiveRepository;
            }
        }

        public GenericRepository<OrderStatus> OrderStatusRepository
        {
            get
            {
                if (orderStatusRepository == null)
                {
                    orderStatusRepository = new GenericRepository<OrderStatus>(Context);
                }
                return orderStatusRepository;
            }
        }

        public GenericRepository<OrderHistory> OrderHistoryRepository
        {
            get
            {
                if (orderHistoryRepository == null)
                {
                    orderHistoryRepository = new GenericRepository<OrderHistory>(Context);
                }
                return orderHistoryRepository;
            }
        }

        public GenericRepository<OrderHistory_Archive> OrderHistoryArchiveRepository
        {
            get
            {
                if (orderHistoryArchiveRepository == null)
                {
                    orderHistoryArchiveRepository = new GenericRepository<OrderHistory_Archive>(Context);
                }
                return orderHistoryArchiveRepository;
            }
        }

        public GenericRepository<StateMaster> StateRepository
        {
            get
            {
                if (stateRepository == null)
                {
                    stateRepository = new GenericRepository<StateMaster>(Context);
                }
                return stateRepository;
            }
        }

        public GenericRepository<PermissionMaster> PermissionMasterRepository
        {
            get
            {
                if (permissionMasterRepository == null)
                {
                    permissionMasterRepository = new GenericRepository<PermissionMaster>(Context);
                }
                return permissionMasterRepository;
            }
        }

        public GenericRepository<FollowUpFlagsMaster> FollowUpFlagsMasterRepository
        {
            get
            {
                if (followUpFlagsMasterRepository == null)
                {
                    followUpFlagsMasterRepository = new GenericRepository<FollowUpFlagsMaster>(Context);
                }
                return followUpFlagsMasterRepository;
            }
        }
        public GenericRepository<HeaderTemplateAssociation> HeaderTemplateAssociationRepository
        {
            get
            {
                if (headerTemplateAssociationRepository == null)
                {
                    headerTemplateAssociationRepository = new GenericRepository<HeaderTemplateAssociation >(Context);
                }
                return headerTemplateAssociationRepository;
            }
        }

        public GenericRepository<SalesRep> SalesRepRepository
        {
            get
            {
                if (salesRepRepository == null)
                {
                    salesRepRepository = new GenericRepository<SalesRep>(Context);
                }
                return salesRepRepository;
            }
        }

        public GenericRepository<IPXSalesRep> IPXSalesRepRepository
        {
            get
            {
                if (ipxSalesRepRepository == null)
                {
                    ipxSalesRepRepository = new GenericRepository<IPXSalesRep>(Context);
                }
                return ipxSalesRepRepository;
            }
        }

        public GenericRepository<FlashCode> FlashCodeRepository
        {
            get
            {
                if (flashCodeRepository == null)
                {
                    flashCodeRepository = new GenericRepository<FlashCode>(Context);
                }
                return flashCodeRepository;
            }
        }

        public GenericRepository<TrackFlagsMaster> TrackFlagsMasterRepository
        {
            get
            {
                if (trackFlagsMasterRepository == null)
                {
                    trackFlagsMasterRepository = new GenericRepository<TrackFlagsMaster>(Context);
                }
                return trackFlagsMasterRepository;
            }
        }

        public GenericRepository<UserLoginDetails> UserLoginDetailsRepository
        {
            get
            {
                if (userLoginDetailsRepository == null)
                {
                    userLoginDetailsRepository = new GenericRepository<UserLoginDetails>(Context);
                }
                return userLoginDetailsRepository;
            }
        }

        public void Save()
        {
            Context.SaveChanges();
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
                Context.Dispose();

            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}

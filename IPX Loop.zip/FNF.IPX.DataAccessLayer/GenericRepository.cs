﻿using FNF.IPX.DataEntities;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

using PagedList;
namespace FNF.IPX.DataAccessLayer
{
    /// <summary>
    /// Generic repository for all entity types
    /// </summary>
    /// <typeparam name="Entity"></typeparam>
    public class GenericRepository<Entity> where Entity : class
    {
        private IPXEntities Context;
        public DbSet<Entity> DbSet;

        /// <summary>
        /// Accept a database context instance and initialize the entity set variable
        /// </summary>
        /// <param name="context"></param>
        public GenericRepository(IPXEntities context)
        {
            this.Context = context;
            this.DbSet = Context.Set<Entity>();
        }

        /// <summary>
        /// Get operation
        /// </summary>
        /// <param name="filter">Lambda expression for filters that goes in the 'Where' method of IQueryable</param>
        /// <param name="orderByList">List of Lambda expression for multiple order by clauses that goes in the 'OrderBy' method of IQueryable
        /// and 'ThenBy' method of IOrderedQueryable</param>
        /// <param name="includeProperties">Comma-separated list of navigation properties for eager loading</param>
        /// <returns></returns>
        //public virtual IEnumerable<Entity> Get(Expression<Func<Entity, bool>> filter = null,
        //                                        IEnumerable<Expression<Func<Entity, dynamic>>> orderByList = null,
        //                                        string includeProperties = null)
        //{
        //    //Declare IQueryable variable, assigning it to DBSet, which is of type IQueryable
        //    IQueryable<Entity> query = DbSet;

        //    //apply the filter in where method, if present
        //    if(filter != null)
        //    {
        //        query = query.Where(filter);
        //    }

        //    //include navigation properties for eager loading, if present
        //    if(!string.IsNullOrEmpty(includeProperties))
        //    {
        //        foreach (var property in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
        //        {
        //            query = query.Include(property);
        //        }
        //    }

        //    //apply sorting, if specified
        //    if(orderByList != null)
        //    {
        //        for (int i = 0; i < orderByList.Count(); i++)
        //        {
        //            if(i == 0)
        //            {
        //                query = query.OrderBy(orderByList.ElementAt(i));
        //            }
        //            else
        //            {
        //                query = ((IOrderedQueryable<Entity>) query)
        //                                                    .ThenBy(orderByList.ElementAt(i));
        //            }
        //        }
        //    }

        //    return query.ToList();
        //}

        /// <summary>
        /// Get operation
        /// </summary>
        /// <param name="filter">Lambda expression for filters that goes in the 'Where' method of IQueryable</param>
        /// <param name="orderByList">Lambda expression for order by clause. Ex: To sort by FirstName, use q => q.FirstName</param>
        /// <param name="includeProperties">Comma-separated list of navigation properties for eager loading</param>
        /// <returns></returns>
        public virtual List<Entity> Get(Expression<Func<Entity, bool>> filter = null,
                                                Func<IQueryable<Entity>, IOrderedQueryable<Entity>> orderBy = null,
                                                string includeProperties = null)
        {
            //Declare IQueryable variable, assigning it to DBSet, which is of type IQueryable
            IQueryable<Entity> query = DbSet;

            //apply the filter in where method, if present
            if (filter != null)
            {
                query = query.Where(filter);
            }

            //include navigation properties for eager loading, if present
            if (!string.IsNullOrEmpty(includeProperties))
            {
                foreach (var property in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(property);
                }
            }

            //apply sorting, if specified
            if (orderBy != null)
            {
                query = orderBy(query);
            }

            return query.ToList();
        }

        public virtual IPagedList<Entity> GetAllPagedItems(Expression<Func<Entity, bool>> filter, IDictionary<string, string> SortColumns,
                                        int PageNumber = 1, Int32 PageSize = 10)
        {
            //Declare IQueryable variable, assigning it to DBSet, which is of type IQueryable
            IQueryable<Entity> query = DbSet;

            //apply the filter in where method, if present
            if (filter != null)
            {
                query = query.Where(filter);
            }


            foreach (var sortcolumn in SortColumns)
            {
                query = GetOrderByExpression(query, sortcolumn.Key, sortcolumn.Value );
            }
            //query = GetOrderByExpression(query, "CreatedDate", "desc");
           
            return query.ToPagedList(PageNumber, PageSize);
        }

        public IQueryable<Entity>  GetOrderByExpression( IQueryable<Entity> query, string ColumnName, string orderType = "asc")
        {
            var arg = Expression.Parameter(typeof(Entity), "GroupMaster");
            var sortProperty = Expression.Property(arg, ColumnName);
            var lambda = Expression.Lambda(sortProperty, arg);

            var param = Expression.Parameter(typeof(IQueryable<Entity>));

              MethodCallExpression orderByCall=null ;

              

            if(orderType=="asc")
                orderByCall = Expression.Call(typeof(Queryable), "OrderBy", new Type[] { typeof(Entity), sortProperty.Type }, new Expression[] { param, lambda });
            else
             orderByCall = Expression.Call(typeof(Queryable), "OrderByDescending", new Type[] { typeof(Entity), sortProperty.Type }, new Expression[] { param, lambda });
           
            var orderLambda = Expression.Lambda<Func<IQueryable<Entity>, IQueryable<Entity>>>(orderByCall, param).Compile();


            IQueryable<Entity> orderlist;

            orderlist = orderLambda(query);// ToList(); 

            return orderlist;
        }

        public virtual Entity GetById(object id)
        {
            return DbSet.Find(id);
        }

        public virtual void Insert(ICollection<Entity> entities)
        {

            foreach (var entity in entities)
                DbSet.Add(entity);
        }

        public virtual Entity Insert(Entity entity)
        {
            return DbSet.Add(entity);
        }

        public virtual void Delete(object id)
        {
            var entity = DbSet.Find(id);
            Delete(entity);
        }

        public virtual void Delete(IEnumerable<Entity> entities)
        {
            foreach (var entity in entities)
            {
                if (Context.Entry(entity).State == EntityState.Detached)
                {
                    DbSet.Attach(entity);
                }
                DbSet.Remove(entity);
            }
        }

        public virtual void Delete(Entity entity)
        {
            if (Context.Entry(entity).State == EntityState.Detached)
            {
                DbSet.Attach(entity);
            }
            DbSet.Remove(entity);
        }

        public virtual void Update(Entity entity)
        {
            DbSet.Attach(entity);
            Context.Entry(entity).State = EntityState.Modified;
        }
    }
}

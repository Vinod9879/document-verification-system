﻿using FNF.IPX.DataEntities;
using FNF.IPX.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FNF.IPX.BusinessLogicLayer.Translators
{
    /// <summary>
    /// 
    /// </summary>
    public static class OrderHistoryArchiveTranslator
    {
        public static OrderHistoryArchiveModel OrderEntityToModel(OrderHistory_Archive orderHistory)
        {
            if (orderHistory == null)
                return null;

            OrderHistoryArchiveModel orderHistoryModel = new OrderHistoryArchiveModel();
            if (orderHistory != null)
            {
                orderHistoryModel.Id = orderHistory.Id;
                orderHistoryModel.OrderId = orderHistory.OrderId;
                orderHistoryModel.Status = orderHistory.Status;
                orderHistoryModel.Comments = orderHistory.Comments;
                orderHistoryModel.CreatedBy = orderHistory.CreatedBy;
                orderHistoryModel.CreatedDate = orderHistory.CreatedDate;
            }
            return orderHistoryModel;

        }

        public static OrderHistory_Archive OrderModelToEntity(OrderHistoryArchiveModel orderHistoryModel)
        {
            if (orderHistoryModel == null)
                return null;

            OrderHistory_Archive orderHistory = new OrderHistory_Archive();
            if (orderHistoryModel != null)
            {
                orderHistory.Id = orderHistoryModel.Id;
                orderHistory.OrderId = orderHistoryModel.OrderId;
                orderHistory.Status = orderHistoryModel.Status;
                orderHistory.Comments = orderHistoryModel.Comments;
                orderHistory.CreatedBy = orderHistoryModel.CreatedBy;
                orderHistory.CreatedDate = orderHistoryModel.CreatedDate;
            }

            return orderHistory;
        }

        public static List<OrderHistoryArchiveModel> OrderEntityListToModelList(List<OrderHistory_Archive> orderHistoryColl)
        {
            if (orderHistoryColl != null && orderHistoryColl.Count > 0)
            {
                var orderHistoryModelColl = new List<OrderHistoryArchiveModel>();
                foreach (var orderHistory in orderHistoryColl)
                {
                    var orderHistoryModel = OrderEntityToModel(orderHistory);
                    orderHistoryModelColl.Add(orderHistoryModel);
                }
                return orderHistoryModelColl;
            }
            return null;
        }
        public static List<OrderHistory_Archive> OrderModelListToEntityList(List<OrderHistoryArchiveModel> orderHistoryModelColl)
        {
            if (orderHistoryModelColl != null && orderHistoryModelColl.Count > 0)
            {
                var orderHistoryColl = new List<OrderHistory_Archive>();
                foreach (var orderHistoryModel in orderHistoryModelColl)
                {
                    var orderHistory = OrderModelToEntity(orderHistoryModel);
                    orderHistoryColl.Add(orderHistory);
                }
                return orderHistoryColl;
            }
            return null;
        }
    }
}

﻿using FNF.IPX.DataEntities;
using FNF.IPX.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FNF.IPX.BusinessLogicLayer.Translators
{
    /// <summary>
    /// 
    /// </summary>
    public static class OrderHistoryTranslator
    {
        public static OrderHistoryModel OrderEntityToModel(OrderHistory orderHistory)
        {
            if (orderHistory == null)
                return null;

            OrderHistoryModel orderHistoryModel = new OrderHistoryModel();
            if (orderHistory != null)
            {
                orderHistoryModel.Id = orderHistory.Id;
                orderHistoryModel.OrderId = orderHistory.OrderId;
                orderHistoryModel.Status = orderHistory.Status;
                orderHistoryModel.Comments = orderHistory.Comments;
                orderHistoryModel.CreatedBy = orderHistory.CreatedBy;
                orderHistoryModel.CreatedDate = orderHistory.CreatedDate;
            }
            return orderHistoryModel;

        }

        public static OrderHistory OrderModelToEntity(OrderHistoryModel orderHistoryModel)
        {
            if (orderHistoryModel == null)
                return null;

            OrderHistory orderHistory = new OrderHistory();
            if (orderHistoryModel != null)
            {
                orderHistory.Id = orderHistoryModel.Id;
                orderHistory.OrderId = orderHistoryModel.OrderId;
                orderHistory.Status = orderHistoryModel.Status;
                orderHistory.Comments = orderHistoryModel.Comments;
                orderHistory.CreatedBy = orderHistoryModel.CreatedBy;
                orderHistory.CreatedDate = orderHistoryModel.CreatedDate;
            }

            return orderHistory;
        }

        public static List<OrderHistoryModel> OrderEntityListToModelList(List<OrderHistory> orderHistoryColl)
        {
            if (orderHistoryColl != null && orderHistoryColl.Count > 0)
            {
                var orderHistoryModelColl = new List<OrderHistoryModel>();
                foreach (var orderHistory in orderHistoryColl)
                {
                    var orderHistoryModel = OrderEntityToModel(orderHistory);
                    orderHistoryModelColl.Add(orderHistoryModel);
                }
                return orderHistoryModelColl;
            }
            return null;
        }
        public static List<OrderHistory> OrderModelListToEntityList(List<OrderHistoryModel> orderHistoryModelColl)
        {
            if (orderHistoryModelColl != null && orderHistoryModelColl.Count > 0)
            {
                var orderHistoryColl = new List<OrderHistory>();
                foreach (var orderHistoryModel in orderHistoryModelColl)
                {
                    var orderHistory = OrderModelToEntity(orderHistoryModel);
                    orderHistoryColl.Add(orderHistory);
                }
                return orderHistoryColl;
            }
            return null;
        }
    }
}

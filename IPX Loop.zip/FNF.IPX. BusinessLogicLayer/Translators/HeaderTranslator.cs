﻿using FNF.IPX.DataEntities;
using FNF.IPX.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FNF.IPX.Common;
using FNF.IPX.DataAccessLayer;

namespace FNF.IPX.BusinessLogicLayer.Translators
{
    /// <summary>
    /// 
    /// </summary>
    public static class HeaderTranslator
    {
        public static HeaderModel EntityToModel(HeaderMaster entity)
        {
            HeaderModel model = new HeaderModel();

            if (entity == null)
                return null ;

            model.Id = entity.Id;
            model.Name = entity.Name;
            model.Datatype = entity.Datatype;

            return model;

        }

        public static HeaderMaster ModelToEntity(HeaderModel model)
        {
            HeaderMaster entity = new HeaderMaster();

            if (model == null)
                return null;

            entity.Id = model.Id;
            entity.Name = model.Name;
            entity.Datatype = model.Datatype;
            return entity;

        }
    }
}

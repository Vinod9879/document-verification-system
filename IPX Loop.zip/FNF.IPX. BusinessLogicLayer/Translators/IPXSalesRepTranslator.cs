﻿using FNF.IPX.DataEntities;
using FNF.IPX.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FNF.IPX.Common;
using FNF.IPX.DataAccessLayer;

namespace FNF.IPX.BusinessLogicLayer.Translators
{
    /// <summary>
    /// 
    /// </summary>
    public static class IPXSalesRepTranslator
    {
        public static IPXSalesRepModel EntityToModel(IPXSalesRep entity)
        {
            IPXSalesRepModel model = new IPXSalesRepModel();

            if (entity == null)
                return null ;

            model.Id  = entity.Id;
            model.EmailAddress = entity.EmailAddress;
            model.UserId = entity.UserId;
            //model.OrderDetails = entity.OrderDetails;
            model.OrderId = entity.OrderId;
            model.SalesRepName = entity.SalesRepName;

            //model.DeafiltTemplates = entity.Template.Select(x => new TemplateModel() { Id = x.Id, Name = x.Name }).ToList();

            //model.DefaultPermission = entity.PermissionMaster.Select(x => new PermissionModel () { Id = x.Id, Name = x.Name,IsPrimary =x.IsPrimary  }).ToList();

            //model.SelectedTemplates = entity.Template.Select(x => x.Id).ToList();
            //model.SelectedPermission = entity.PermissionMaster.Select(x => x.Id).ToList();

            return model;

        }

        public static IPXSalesRep ModelToEntity(IPXSalesRepModel model)
        {
            IPXSalesRep entity = new IPXSalesRep();

            if (model == null)
                return null;

            entity.Id = model.Id;
            entity.EmailAddress = model.EmailAddress;
            entity.UserId = model.UserId;
            //entity.OrderDetails = model.OrderDetails;
            entity.OrderId = model.OrderId;
            entity.SalesRepName = model.SalesRepName;


            //entity.PermissionMaster = model.DefaultPermission.Select(x => new PermissionMaster() { Id = x.Id, Name = x.Name,IsPrimary=x.IsPrimary  }).ToList();

            //entity.Template = model.DeafiltTemplates.Select(x => new Template () { Id = x.Id, Name = x.Name }).ToList();

            //group.Template = UnitofWork
            //                .TemplateRepository
            //                .Get(t => groupModel
            //                            .SelectedTemplates
            //                            .Any(s => t.Id == s), orderBy: null)
            //                .ToList();

            return entity;

        }
    }
}

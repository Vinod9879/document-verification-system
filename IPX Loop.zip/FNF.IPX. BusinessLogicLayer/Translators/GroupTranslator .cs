﻿using FNF.IPX.DataEntities;
using FNF.IPX.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FNF.IPX.Common;
using FNF.IPX.DataAccessLayer;
using System.Linq.Expressions;
using System.Web;

namespace FNF.IPX.BusinessLogicLayer.Translators
{
    /// <summary>
    /// 
    /// </summary>
    public static class GroupTranslator
    {
        public static GroupModel EntityToModel(GroupMaster entity)
        {
            GroupModel model = new GroupModel();

            if (entity == null)
                return null;

            model.Id = entity.Id;
            model.Name = entity.Name;
            model.Description = entity.Description;
            model.IsActive = entity.IsActive;
            model.CreatedBy = entity.CreatedBy;
            model.CreatedDate = entity.CreatedDate;
            model.ModifiedBy = entity.ModifiedBy;
            model.ModifiedDate = entity.ModifiedDate;

            model.DeafiltTemplates = entity.Template.Select(x => new TemplateModel() { Id = x.Id, Name = x.Name }).ToList();

            model.DefaultPermission = entity.PermissionMaster.Select(x => new PermissionModel() { Id = x.Id, Name = x.Name, IsPrimary = x.IsPrimary }).ToList();

            //model.SelectedTemplates = entity.Template.Select(x => x.Id).ToList();
            //model.SelectedPermission = entity.PermissionMaster.Select(x => x.Id).ToList();

            return model;

        }

        public static GroupMaster ModelToEntity(GroupModel model)
        {
            GroupMaster entity = new GroupMaster();

            if (model == null)
                return null;

            entity.Id = model.Id;
            entity.Name = HttpUtility.HtmlEncode(model.Name);
            entity.Description = HttpUtility.HtmlEncode(model.Description);
            entity.IsActive = model.IsActive;
            entity.CreatedBy = model.CreatedBy;
            entity.CreatedDate = model.CreatedDate;
            entity.ModifiedBy = model.ModifiedBy;
            entity.ModifiedDate = model.ModifiedDate;

            entity.PermissionMaster = model.DefaultPermission.Select(x => new PermissionMaster() { Id = x.Id, Name = x.Name, IsPrimary = x.IsPrimary }).ToList();

            entity.Template = model.DeafiltTemplates.Select(x => new Template() { Id = x.Id, Name = x.Name }).ToList();

            //group.Template = UnitofWork
            //                .TemplateRepository
            //                .Get(t => groupModel
            //                            .SelectedTemplates
            //                            .Any(s => t.Id == s), orderBy: null)
            //                .ToList();

            return entity;

        }
    }


 

    public class GroupFilterTranslator
    {
        public Expression<Func<GroupMaster, bool>> Filters { get; private set; }

 
        public GroupFilterTranslator(IDictionary<string, string> FilterColumnNameValue, IDictionary<string, string> SortColumns)
        {
            if (FilterColumnNameValue != null)
                AddFilters(FilterColumnNameValue);

            
        }

        private void AddFilters(IDictionary<string, string> FilterColumnNameValue)
        {
            Expression<Func<GroupMaster, bool>> filter = null;//=   y => y.CreatedBy==""  ;


            object value = FilterColumnNameValue.Where(x => x.Key == "IsActive").FirstOrDefault().Value;
            if (value != null)
            {
                var v = Convert.ToBoolean(value);
                filter = (y => y.IsActive == v);
            }

            value = FilterColumnNameValue.Where(x => x.Key == "Name").FirstOrDefault().Value;
            if (value != null)
            {
                var v = value.ToString();
                filter = (y => y.Name.Contains(v));
            }

            value = FilterColumnNameValue.Where(x => x.Key == "Description").FirstOrDefault().Value;
            if (value != null)
            {
                var v = value.ToString();
                filter = (y => y.Description.Contains(v) );
            }

            value = FilterColumnNameValue.Where(x => x.Key == "CreatedBy").FirstOrDefault().Value;
            if (value != null)
            {
                var v = value.ToString();
                filter = (y => y.CreatedBy.Contains(v));
            }

            value = FilterColumnNameValue.Where(x => x.Key == "CreatedDate").FirstOrDefault().Value;
            if (value != null)
            {
                var v = Convert.ToDateTime(value);
                filter = (y => y.CreatedDate == v);
            }

            value = FilterColumnNameValue.Where(x => x.Key == "ModifiedBy").FirstOrDefault().Value;
            if (value != null)
            {
                var v = value.ToString();
                filter = (y => y.ModifiedBy.Contains(v));
            }

            value = FilterColumnNameValue.Where(x => x.Key == "ModifiedDate").FirstOrDefault().Value;
            if (value != null)
            {
                var v = Convert.ToDateTime(value);
                filter = (y => y.ModifiedDate == v);
            }

            Filters = filter;
        }
     

    }
}

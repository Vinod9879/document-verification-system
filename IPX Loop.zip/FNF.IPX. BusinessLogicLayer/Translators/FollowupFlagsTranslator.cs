﻿using FNF.IPX.DataEntities;
using FNF.IPX.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FNF.IPX.Common;
using FNF.IPX.DataAccessLayer;

namespace FNF.IPX.BusinessLogicLayer.Translators
{
    /// <summary>
    /// 
    /// </summary>
    public static class FollowupFlagsTranslator
    {
        public static FollowUpFlagsModel OrderFollowupFlagsEntityToModel(FollowUpFlagsMaster followUpFlagsMaster)
        {
            FollowUpFlagsModel followUpFlagsModel = new FollowUpFlagsModel();

            if (followUpFlagsMaster == null)
                return null ;

            followUpFlagsModel.Id = followUpFlagsMaster.Id;
            followUpFlagsModel.Name = followUpFlagsMaster.Name;
            followUpFlagsModel.Priority = followUpFlagsMaster.Priority;
            followUpFlagsModel.UlClass = followUpFlagsMaster.UlClass;
            followUpFlagsModel.ButtonClass = followUpFlagsMaster.ButtonClass;
            
            return followUpFlagsModel;

        }

        public static FollowUpFlagsMaster OrderFollowupFlagsModelToEntity(FollowUpFlagsModel followUpFlagsModel)
        {
            FollowUpFlagsMaster followUpFlagsMaster = new FollowUpFlagsMaster();

            if (followUpFlagsModel == null)
                return null;

            followUpFlagsMaster.Id = followUpFlagsModel.Id;
            followUpFlagsMaster.Name = followUpFlagsModel.Name;
            followUpFlagsMaster.Priority = followUpFlagsModel.Priority;
            followUpFlagsModel.UlClass = followUpFlagsMaster.UlClass;
            followUpFlagsModel.ButtonClass = followUpFlagsMaster.ButtonClass;

            return followUpFlagsMaster;
        }
    }
}

﻿using FNF.IPX.DataEntities;
using FNF.IPX.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FNF.IPX.BusinessLogicLayer.Translators
{
    /// <summary>
    /// 
    /// </summary>
    public static class OrderTranslator
    {
        public static OrderDetailsModel OrderEntityToModel(OrderDetails order)
        {
            OrderDetailsModel orderModel = new OrderDetailsModel();

            if (order == null)
                return null;

            orderModel.OrderID = order.OrderID;
            orderModel.DivisionName = order.DivisionName;
            orderModel.FlashCode = order.FlashCode;
            orderModel.FlashName = order.FlashName;
            orderModel.OperationCode = order.OperationCode;
            orderModel.OperationName = order.OperationName;
            orderModel.BranchName = order.BranchName;
            orderModel.FileNumber = order.FileNumber;
            orderModel.DateOpened = order.DateOpened;
            orderModel.DateClosedSourceSystem = order.DateClosedSourceSystem;
            orderModel.DateCanceled = order.DateCanceled;
            orderModel.OrderStatus = order.OrderStatus;
            orderModel.SettlementType = order.SettlementType;
            orderModel.PropertyType = order.PropertyType;
            orderModel.PropertyTypeGroup = order.PropertyTypeGroup;
            orderModel.TransactionType = order.TransactionType;
            orderModel.SalesPrice = order.SalesPrice;
            orderModel.SourceDB = order.SourceDB;
            orderModel.SourceServer = order.SourceServer;
            orderModel.UnderwriterName = order.UnderwriterName;
            orderModel.ProductionSystemType = order.ProductionSystemType;
            orderModel.Comments = order.Comments;
            orderModel.IsDeleted = order.IsDeleted;
            orderModel.UpdatedDate = order.UpdatedDate;
            orderModel.FollowupFlag = order.FollowupFlag;
            orderModel.CreatedBy = order.CreatedBy;
            orderModel.CreatedDate = order.CreatedDate;
            orderModel.ModifiedBy = order.ModifiedBy;
            orderModel.ModifiedDate = order.ModifiedDate;
            orderModel.TrackFlag = order.TrackFlag;

            if (order.LoanDetails != null && order.LoanDetails.Count > 0)
            {
                orderModel.LoanDetails = new List<LoanDetailsModel>();
                foreach (var loan in order.LoanDetails)
                {
                    var loanVm = new LoanDetailsModel();
                    loanVm.Id = loan.Id;
                    loanVm.LoanAmount = loan.LoanAmount;
                    loanVm.OrderId = loan.OrderId;
                    orderModel.LoanDetails.Add(loanVm);
                }
            }


            if (order.OrderHistory != null && order.OrderHistory.Count > 0)
            {
                orderModel.OrderHistory = new List<OrderHistoryModel>();
                foreach (var hist in order.OrderHistory)
                {
                    var history = new OrderHistoryModel();
                    history.Id = hist.Id;
                    history.OrderId = hist.OrderId;
                    history.Status = hist.Status;
                    history.Comments = hist.Comments;
                    history.CreatedBy = hist.CreatedBy;
                    history.CreatedDate = hist.CreatedDate;

                    orderModel.OrderHistory.Add(history);
                }
            }

            if (order.PropertyMaster != null && order.PropertyMaster.Count > 0)
            {
                orderModel.PropertyMaster = new List<PropertyMasterModel>();
                foreach (var property in order.PropertyMaster)
                {
                    var propertyVm = new PropertyMasterModel();
                    propertyVm.Id = property.Id;
                    propertyVm.OrderID = property.OrderID;
                    propertyVm.SequenceNumber = property.SequenceNumber;
                    propertyVm.Address1 = property.Address1;
                    propertyVm.Address2 = property.Address2;
                    propertyVm.City = property.City;
                    propertyVm.State = property.State;
                    propertyVm.ZipCode = property.ZipCode;
                    orderModel.PropertyMaster.Add(propertyVm);
                }
            }

            if (order.SalesRep != null && order.SalesRep.Count > 0)
            {
                orderModel.SalesRep = new List<SalesRepModel>();
                foreach (var rep in order.SalesRep)
                {
                    var salesUser = new SalesRepModel();
                    salesUser.Id = rep.Id;
                    salesUser.OrderId = rep.OrderId;
                    salesUser.SalesRepName = rep.SalesRepName;
                    salesUser.EmailAddress = rep.EmailAddress;
                    orderModel.SalesRep.Add(salesUser);
                }
            }

            if (order.Party != null && order.Party.Count > 0)
            {
                orderModel.Party = new List<PartyModel>();
                foreach (var party in order.Party)
                {
                    var partyVm = new PartyModel();
                    partyVm.PartyID = party.PartyID;
                    partyVm.OrderId = party.OrderId;
                    partyVm.PartyName = party.PartyName;
                    partyVm.PartyType = party.PartyType;
                    partyVm.Address1 = party.Address1;
                    partyVm.Address2 = party.Address2;
                    partyVm.City = party.City;
                    partyVm.State = party.State;
                    partyVm.ZipCode = party.ZipCode;
                    partyVm.CellPhone = party.CellPhone;
                    partyVm.WorkPhone = party.WorkPhone;
                    partyVm.Email = party.Email;

                    if (party.PartyContact != null && party.PartyContact.Count > 0)
                    {
                        partyVm.PartyContact = new List<PartyContactModel>();
                        foreach (var contact in party.PartyContact)
                        {
                            var contactVm = new PartyContactModel();
                            contactVm.Id = contact.Id;
                            contactVm.PartyId = contact.PartyId;
                            contactVm.OrderId = contact.OrderId;
                            contactVm.FirstName = contact.FirstName;
                            contactVm.MiddleName = contact.MiddleName;
                            contactVm.LastName = contact.LastName;
                            contactVm.PersonAddress1 = contact.PersonAddress1;
                            contactVm.PersonAddress2 = contact.PersonAddress2;
                            contactVm.PersonCity = contact.PersonCity;
                            contactVm.PersonState = contact.PersonState;
                            contactVm.PersonZipCode = contact.PersonZipCode;
                            contactVm.PersonWorkPhone = contact.PersonWorkPhone;
                            contactVm.PersonEmail = contact.PersonEmail;

                            partyVm.PartyContact.Add(contactVm);
                        }
                    }

                    orderModel.Party.Add(partyVm);
                }

                if (order.PartyContact != null && order.PartyContact.Count > 0)
                {
                    orderModel.PartyContact = new List<PartyContactModel>();
                    foreach (var contact in order.PartyContact)
                    {
                        var contactVm = new PartyContactModel();
                        contactVm.Id = contact.Id;
                        contactVm.PartyId = contact.PartyId;
                        contactVm.OrderId = contact.OrderId;
                        contactVm.FirstName = contact.FirstName;
                        contactVm.MiddleName = contact.MiddleName;
                        contactVm.LastName = contact.LastName;
                        contactVm.PersonAddress1 = contact.PersonAddress1;
                        contactVm.PersonAddress2 = contact.PersonAddress2;
                        contactVm.PersonCity = contact.PersonCity;
                        contactVm.PersonState = contact.PersonState;
                        contactVm.PersonZipCode = contact.PersonZipCode;
                        contactVm.PersonWorkPhone = contact.PersonWorkPhone;
                        contactVm.PersonEmail = contact.PersonEmail;

                        orderModel.PartyContact.Add(contactVm);
                    }
                }
            }

            return orderModel;

        }

        public static OrderDetails OrderModelToEntity(OrderDetailsModel orderModel)
        {
            OrderDetails order = new OrderDetails();

            if (orderModel == null)
                return null;

            order.OrderID = orderModel.OrderID;
            order.DivisionName = orderModel.DivisionName;
            order.FlashCode = orderModel.FlashCode;
            order.FlashName = orderModel.FlashName;
            order.OperationCode = orderModel.OperationCode;
            order.OperationName = orderModel.OperationName;
            order.BranchName = orderModel.BranchName;
            order.FileNumber = orderModel.FileNumber;
            order.DateOpened = orderModel.DateOpened;
            order.DateClosedSourceSystem = orderModel.DateClosedSourceSystem;
            order.DateCanceled = orderModel.DateCanceled;
            order.OrderStatus = orderModel.OrderStatus;
            order.SettlementType = orderModel.SettlementType;
            order.PropertyType = orderModel.PropertyType;
            order.PropertyTypeGroup = orderModel.PropertyTypeGroup;
            order.TransactionType = orderModel.TransactionType;
            order.SalesPrice = orderModel.SalesPrice;
            order.UnderwriterName = orderModel.UnderwriterName;
            order.SourceDB = orderModel.SourceDB;
            order.SourceServer = orderModel.SourceServer;
            order.ProductionSystemType = orderModel.ProductionSystemType;
            order.Comments = orderModel.Comments;
            order.IsDeleted = orderModel.IsDeleted;
            order.UpdatedDate = orderModel.UpdatedDate;
            order.FollowupFlag = orderModel.FollowupFlag;
            order.CreatedBy = orderModel.CreatedBy;
            order.CreatedDate = orderModel.CreatedDate;
            order.ModifiedBy = orderModel.ModifiedBy;
            order.ModifiedDate = orderModel.ModifiedDate;
            order.TrackFlag = orderModel.TrackFlag;

            if (orderModel.LoanDetails != null && orderModel.LoanDetails.Count > 0)
            {
                order.LoanDetails = new List<LoanDetails>();
                foreach (var loanVm in orderModel.LoanDetails)
                {
                    var loan = new LoanDetails();
                    loan.Id = loanVm.Id;
                    loan.LoanAmount = loanVm.LoanAmount;
                    loan.OrderId = loanVm.OrderId;
                    order.LoanDetails.Add(loan);
                }
            }


            if (orderModel.OrderHistory != null && orderModel.OrderHistory.Count > 0)
            {
                order.OrderHistory = new List<OrderHistory>();
                foreach (var histVm in orderModel.OrderHistory)
                {
                    var history = new OrderHistory();
                    history.Id = histVm.Id;
                    history.OrderId = histVm.OrderId;
                    history.Status = histVm.Status;
                    history.Comments = histVm.Comments;
                    history.CreatedBy = histVm.CreatedBy;
                    history.CreatedDate = histVm.CreatedDate;

                    order.OrderHistory.Add(history);
                }
            }

            if (orderModel.Party != null && orderModel.Party.Count > 0)
            {
                order.Party = new List<Party>();
                foreach (var partyVm in orderModel.Party)
                {
                    var party = new Party();
                    party.PartyID = partyVm.PartyID;
                    party.OrderId = partyVm.OrderId;
                    party.PartyName = partyVm.PartyName;
                    party.PartyType = partyVm.PartyType;
                    party.Address1 = partyVm.Address1;
                    party.Address2 = partyVm.Address2;
                    party.City = partyVm.City;
                    party.State = partyVm.State;
                    party.ZipCode = partyVm.ZipCode;
                    party.CellPhone = partyVm.CellPhone;
                    party.WorkPhone = partyVm.WorkPhone;
                    party.Email = partyVm.Email;

                    if (partyVm.PartyContact != null && partyVm.PartyContact.Count > 0)
                    {
                        party.PartyContact = new List<PartyContact>();
                        foreach (var contactVm in partyVm.PartyContact)
                        {
                            var contact = new PartyContact();
                            contact.Id = contactVm.Id;
                            contact.PartyId = contactVm.PartyId;
                            contact.OrderId = contactVm.OrderId;
                            contact.FirstName = contactVm.FirstName;
                            contact.MiddleName = contactVm.MiddleName;
                            contact.LastName = contactVm.LastName;
                            contact.PersonAddress1 = contactVm.PersonAddress1;
                            contact.PersonAddress2 = contactVm.PersonAddress2;
                            contact.PersonCity = contactVm.PersonCity;
                            contact.PersonState = contactVm.PersonState;
                            contact.PersonZipCode = contactVm.PersonZipCode;
                            contact.PersonWorkPhone = contactVm.PersonWorkPhone;
                            contact.PersonEmail = contactVm.PersonEmail;

                            party.PartyContact.Add(contact);
                        }
                    }

                    order.Party.Add(party);
                }

                if (orderModel.PartyContact != null && orderModel.PartyContact.Count > 0)
                {
                    order.PartyContact = new List<PartyContact>();
                    foreach (var contactVm in orderModel.PartyContact)
                    {
                        var contact = new PartyContact();
                        contact.Id = contactVm.Id;
                        contact.PartyId = contactVm.PartyId;
                        contact.OrderId = contactVm.OrderId;
                        contact.FirstName = contactVm.FirstName;
                        contact.MiddleName = contactVm.MiddleName;
                        contact.LastName = contactVm.LastName;
                        contact.PersonAddress1 = contactVm.PersonAddress1;
                        contact.PersonAddress2 = contactVm.PersonAddress2;
                        contact.PersonCity = contactVm.PersonCity;
                        contact.PersonState = contactVm.PersonState;
                        contact.PersonZipCode = contactVm.PersonZipCode;
                        contact.PersonWorkPhone = contactVm.PersonWorkPhone;
                        contact.PersonEmail = contactVm.PersonEmail;

                        order.PartyContact.Add(contact);
                    }
                }
            }

            if (orderModel.PropertyMaster != null && orderModel.PropertyMaster.Count > 0)
            {
                order.PropertyMaster = new List<PropertyMaster>();
                foreach (var propertyVm in orderModel.PropertyMaster)
                {
                    var property = new PropertyMaster();
                    property.Id = propertyVm.Id;
                    property.OrderID = propertyVm.OrderID;
                    property.SequenceNumber = propertyVm.SequenceNumber;
                    property.Address1 = propertyVm.Address1;
                    property.Address2 = propertyVm.Address2;
                    property.City = propertyVm.City;
                    property.State = propertyVm.State;
                    property.ZipCode = propertyVm.ZipCode;
                    order.PropertyMaster.Add(property);
                }
            }

            if (orderModel.SalesRep != null && orderModel.SalesRep.Count > 0)
            {
                order.SalesRep = new List<SalesRep>();
                foreach (var rep in orderModel.SalesRep)
                {
                    var salesUser = new SalesRep();
                    salesUser.Id = rep.Id;
                    salesUser.OrderId = rep.OrderId;
                    salesUser.SalesRepName = rep.SalesRepName;
                    salesUser.EmailAddress = rep.EmailAddress;
                    order.SalesRep.Add(salesUser);
                }
            }

            return order;

        }
    }
}

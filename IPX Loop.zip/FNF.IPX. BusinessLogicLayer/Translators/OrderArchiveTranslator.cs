﻿using FNF.IPX.DataEntities;
using FNF.IPX.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FNF.IPX.BusinessLogicLayer.Translators
{
    /// <summary>
    /// 
    /// </summary>
    public static class OrderArchiveTranslator
    {
        public static OrderDetailsArchiveModel OrderEntityToModel(OrderDetails_Archive order)
        {
            OrderDetailsArchiveModel orderModel = new OrderDetailsArchiveModel();

            if (order == null)
                return null;

            orderModel.OrderID = order.OrderID;
            orderModel.DivisionName = order.DivisionName;
            orderModel.FlashCode = order.FlashCode;
            orderModel.FlashName = order.FlashName;
            orderModel.OperationCode = order.OperationCode;
            orderModel.OperationName = order.OperationName;
            orderModel.BranchName = order.BranchName;
            orderModel.FileNumber = order.FileNumber;
            orderModel.DateOpened = order.DateOpened;
            orderModel.DateClosedSourceSystem = order.DateClosedSourceSystem;
            orderModel.DateCanceled = order.DateCanceled;
            orderModel.OrderStatus = order.OrderStatus;
            orderModel.SettlementType = order.SettlementType;
            orderModel.PropertyType = order.PropertyType;
            orderModel.PropertyTypeGroup = order.PropertyTypeGroup;
            orderModel.TransactionType = order.TransactionType;
            orderModel.SalesPrice = order.SalesPrice;
            orderModel.SourceDB = order.SourceDB;
            orderModel.SourceServer = order.SourceServer;
            orderModel.UnderwriterName = order.UnderwriterName;
            orderModel.ProductionSystemType = order.ProductionSystemType;
            orderModel.Comments = order.Comments;
            orderModel.IsDeleted = order.IsDeleted;
            orderModel.UpdatedDate = order.UpdatedDate;
            orderModel.FollowupFlag = order.FollowupFlag;
            orderModel.CreatedBy = order.CreatedBy;
            orderModel.CreatedDate = order.CreatedDate;
            orderModel.ModifiedBy = order.ModifiedBy;
            orderModel.ModifiedDate = order.ModifiedDate;
            orderModel.TrackFlag = order.TrackFlag;

            if (order.LoanDetails_Archive != null && order.LoanDetails_Archive.Count > 0)
            {
                orderModel.LoanDetails_Archive = new List<LoanDetailsArchiveModel>();
                foreach (var loan in order.LoanDetails_Archive)
                {
                    var loanVm = new LoanDetailsArchiveModel();
                    loanVm.Id = loan.Id;
                    loanVm.LoanAmount = loan.LoanAmount;
                    loanVm.OrderId = loan.OrderId;
                    orderModel.LoanDetails_Archive.Add(loanVm);
                }
            }


            if (order.OrderHistory_Archive != null && order.OrderHistory_Archive.Count > 0)
            {
                orderModel.OrderHistory_Archive = new List<OrderHistoryArchiveModel>();
                foreach (var hist in order.OrderHistory_Archive)
                {
                    var history = new OrderHistoryArchiveModel();
                    history.Id = hist.Id;
                    history.OrderId = hist.OrderId;
                    history.Status = hist.Status;
                    history.Comments = hist.Comments;
                    history.CreatedBy = hist.CreatedBy;
                    history.CreatedDate = hist.CreatedDate;

                    orderModel.OrderHistory_Archive.Add(history);
                }
            }

            if (order.PropertyMaster_Archive != null && order.PropertyMaster_Archive.Count > 0)
            {
                orderModel.PropertyMaster_Archive = new List<PropertyMasterArchiveModel>();
                foreach (var property in order.PropertyMaster_Archive)
                {
                    var propertyVm = new PropertyMasterArchiveModel();
                    propertyVm.Id = property.Id;
                    propertyVm.OrderID = property.OrderID;
                    propertyVm.SequenceNumber = property.SequenceNumber;
                    propertyVm.Address1 = property.Address1;
                    propertyVm.Address2 = property.Address2;
                    propertyVm.City = property.City;
                    propertyVm.State = property.State;
                    propertyVm.ZipCode = property.ZipCode;
                    orderModel.PropertyMaster_Archive.Add(propertyVm);
                }
            }
            if (order.Party_Archive != null && order.Party_Archive.Count > 0)
            {
                orderModel.Party_Archive = new List<PartyArchiveModel>();
                foreach (var party in order.Party_Archive)
                {
                    var partyVm = new PartyArchiveModel();
                    partyVm.PartyID = party.PartyID;
                    partyVm.OrderId = party.OrderId;
                    partyVm.PartyName = party.PartyName;
                    partyVm.PartyType = party.PartyType;
                    partyVm.Address1 = party.Address1;
                    partyVm.Address2 = party.Address2;
                    partyVm.City = party.City;
                    partyVm.State = party.State;
                    partyVm.ZipCode = party.ZipCode;
                    partyVm.CellPhone = party.CellPhone;
                    partyVm.WorkPhone = party.WorkPhone;
                    partyVm.Email = party.Email;

                    if (party.PartyContact_Archive != null && party.PartyContact_Archive.Count > 0)
                    {
                        partyVm.PartyContactArchive = new List<PartyContactArchiveModel>();
                        foreach (var contact in party.PartyContact_Archive)
                        {
                            var contactVm = new PartyContactArchiveModel();
                            contactVm.Id = contact.Id;
                            contactVm.PartyId = contact.PartyId;
                            contactVm.OrderId = contact.OrderId;
                            contactVm.FirstName = contact.FirstName;
                            contactVm.MiddleName = contact.MiddleName;
                            contactVm.LastName = contact.LastName;
                            contactVm.PersonAddress1 = contact.PersonAddress1;
                            contactVm.PersonAddress2 = contact.PersonAddress2;
                            contactVm.PersonCity = contact.PersonCity;
                            contactVm.PersonState = contact.PersonState;
                            contactVm.PersonZipCode = contact.PersonZipCode;
                            contactVm.PersonWorkPhone = contact.PersonWorkPhone;
                            contactVm.PersonEmail = contact.PersonEmail;

                            partyVm.PartyContactArchive.Add(contactVm);
                        }
                    }

                    orderModel.Party_Archive.Add(partyVm);
                }

                if (order.PartyContact_Archive != null && order.PartyContact_Archive.Count > 0)
                {
                    orderModel.PartyContact_Archive = new List<PartyContactArchiveModel>();
                    foreach (var contact in order.PartyContact_Archive)
                    {
                        var contactVm = new PartyContactArchiveModel();
                        contactVm.Id = contact.Id;
                        contactVm.PartyId = contact.PartyId;
                        contactVm.OrderId = contact.OrderId;
                        contactVm.FirstName = contact.FirstName;
                        contactVm.MiddleName = contact.MiddleName;
                        contactVm.LastName = contact.LastName;
                        contactVm.PersonAddress1 = contact.PersonAddress1;
                        contactVm.PersonAddress2 = contact.PersonAddress2;
                        contactVm.PersonCity = contact.PersonCity;
                        contactVm.PersonState = contact.PersonState;
                        contactVm.PersonZipCode = contact.PersonZipCode;
                        contactVm.PersonWorkPhone = contact.PersonWorkPhone;
                        contactVm.PersonEmail = contact.PersonEmail;

                        orderModel.PartyContact_Archive.Add(contactVm);
                    }
                }

                if (order.PropertyMaster_Archive != null && order.PropertyMaster_Archive.Count > 0)
                {
                    orderModel.PropertyMaster_Archive = new List<PropertyMasterArchiveModel>();
                    foreach (var property in order.PropertyMaster_Archive)
                    {
                        var propertyVm = new PropertyMasterArchiveModel();
                        propertyVm.Id = property.Id;
                        propertyVm.OrderID = property.OrderID;
                        propertyVm.SequenceNumber = property.SequenceNumber;
                        propertyVm.Address1 = property.Address1;
                        propertyVm.Address2 = property.Address2;
                        propertyVm.City = property.City;
                        propertyVm.State = property.State;
                        propertyVm.ZipCode = property.ZipCode;
                        orderModel.PropertyMaster_Archive.Add(propertyVm);
                    }
                }

                if (order.SalesRep_Archive != null && order.SalesRep_Archive.Count > 0)
                {
                    orderModel.SalesRep_Archive = new List<SalesRepArchiveModel>();
                    foreach (var rep in order.SalesRep_Archive)
                    {
                        var salesUser = new SalesRepArchiveModel();
                        salesUser.Id = rep.Id;
                        salesUser.OrderId = rep.OrderId;
                        salesUser.SalesRepName = rep.SalesRepName;
                        salesUser.EmailAddress = rep.EmailAddress;
                        orderModel.SalesRep_Archive.Add(salesUser);
                    }
                }
            }

            return orderModel;

        }

        public static OrderDetails_Archive OrderModelToEntity(OrderDetailsArchiveModel orderModel)
        {
            OrderDetails_Archive order = new OrderDetails_Archive();

            if (orderModel == null)
                return null;

            order.OrderID = orderModel.OrderID;
            order.DivisionName = orderModel.DivisionName;
            order.FlashCode = orderModel.FlashCode;
            order.FlashName = orderModel.FlashName;
            order.OperationCode = orderModel.OperationCode;
            order.OperationName = orderModel.OperationName;
            order.BranchName = orderModel.BranchName;
            order.FileNumber = orderModel.FileNumber;
            order.DateOpened = orderModel.DateOpened;
            order.DateClosedSourceSystem = orderModel.DateClosedSourceSystem;
            order.DateCanceled = orderModel.DateCanceled;
            order.OrderStatus = orderModel.OrderStatus;
            order.SettlementType = orderModel.SettlementType;
            order.PropertyType = orderModel.PropertyType;
            order.PropertyTypeGroup = orderModel.PropertyTypeGroup;
            order.TransactionType = orderModel.TransactionType;
            order.SalesPrice = orderModel.SalesPrice;
            order.UnderwriterName = orderModel.UnderwriterName;
            order.SourceDB = orderModel.SourceDB;
            order.SourceServer = orderModel.SourceServer;
            order.ProductionSystemType = orderModel.ProductionSystemType;
            order.Comments = orderModel.Comments;
            order.IsDeleted = orderModel.IsDeleted;
            order.UpdatedDate = orderModel.UpdatedDate;
            order.FollowupFlag = orderModel.FollowupFlag;
            order.CreatedBy = orderModel.CreatedBy;
            order.CreatedDate = orderModel.CreatedDate;
            order.ModifiedBy = orderModel.ModifiedBy;
            order.ModifiedDate = orderModel.ModifiedDate;
            order.TrackFlag = orderModel.TrackFlag;

            if (orderModel.LoanDetails_Archive != null && orderModel.LoanDetails_Archive.Count > 0)
            {
                order.LoanDetails_Archive = new List<LoanDetails_Archive>();
                foreach (var loanVm in orderModel.LoanDetails_Archive)
                {
                    var loan = new LoanDetails_Archive();
                    loan.Id = loanVm.Id;
                    loan.LoanAmount = loanVm.LoanAmount;
                    loan.OrderId = loanVm.OrderId;
                    order.LoanDetails_Archive.Add(loan);
                }
            }


            if (orderModel.OrderHistory_Archive != null && orderModel.OrderHistory_Archive.Count > 0)
            {
                order.OrderHistory_Archive = new List<OrderHistory_Archive>();
                foreach (var histVm in orderModel.OrderHistory_Archive)
                {
                    var history = new OrderHistory_Archive();
                    history.Id = histVm.Id;
                    history.OrderId = histVm.OrderId;
                    history.Status = histVm.Status;
                    history.Comments = histVm.Comments;
                    history.CreatedBy = histVm.CreatedBy;
                    history.CreatedDate = histVm.CreatedDate;

                    order.OrderHistory_Archive.Add(history);
                }
            }

            if (orderModel.Party_Archive != null && orderModel.Party_Archive.Count > 0)
            {
                order.Party_Archive = new List<Party_Archive>();
                foreach (var partyVm in orderModel.Party_Archive)
                {
                    var party = new Party_Archive();
                    party.PartyID = partyVm.PartyID;
                    party.OrderId = partyVm.OrderId;
                    party.PartyName = partyVm.PartyName;
                    party.PartyType = partyVm.PartyType;
                    party.Address1 = partyVm.Address1;
                    party.Address2 = partyVm.Address2;
                    party.City = partyVm.City;
                    party.State = partyVm.State;
                    party.ZipCode = partyVm.ZipCode;
                    party.CellPhone = partyVm.CellPhone;
                    party.WorkPhone = partyVm.WorkPhone;
                    party.Email = partyVm.Email;

                    if (partyVm.PartyContactArchive != null && partyVm.PartyContactArchive.Count > 0)
                    {
                        party.PartyContact_Archive = new List<PartyContact_Archive>();
                        foreach (var contactVm in partyVm.PartyContactArchive)
                        {
                            var contact = new PartyContact_Archive();
                            contact.Id = contactVm.Id;
                            contact.PartyId = contactVm.PartyId;
                            contact.OrderId = contactVm.OrderId;
                            contact.FirstName = contactVm.FirstName;
                            contact.MiddleName = contactVm.MiddleName;
                            contact.LastName = contactVm.LastName;
                            contact.PersonAddress1 = contactVm.PersonAddress1;
                            contact.PersonAddress2 = contactVm.PersonAddress2;
                            contact.PersonCity = contactVm.PersonCity;
                            contact.PersonState = contactVm.PersonState;
                            contact.PersonZipCode = contactVm.PersonZipCode;
                            contact.PersonWorkPhone = contactVm.PersonWorkPhone;
                            contact.PersonEmail = contactVm.PersonEmail;

                            party.PartyContact_Archive.Add(contact);
                        }
                    }

                    order.Party_Archive.Add(party);
                }

                if (orderModel.PartyContact_Archive != null && orderModel.PartyContact_Archive.Count > 0)
                {
                    order.PartyContact_Archive = new List<PartyContact_Archive>();
                    foreach (var contactVm in orderModel.PartyContact_Archive)
                    {
                        var contact = new PartyContact_Archive();
                        contact.Id = contactVm.Id;
                        contact.PartyId = contactVm.PartyId;
                        contact.OrderId = contactVm.OrderId;
                        contact.FirstName = contactVm.FirstName;
                        contact.MiddleName = contactVm.MiddleName;
                        contact.LastName = contactVm.LastName;
                        contact.PersonAddress1 = contactVm.PersonAddress1;
                        contact.PersonAddress2 = contactVm.PersonAddress2;
                        contact.PersonCity = contactVm.PersonCity;
                        contact.PersonState = contactVm.PersonState;
                        contact.PersonZipCode = contactVm.PersonZipCode;
                        contact.PersonWorkPhone = contactVm.PersonWorkPhone;
                        contact.PersonEmail = contactVm.PersonEmail;

                        order.PartyContact_Archive.Add(contact);
                    }
                }

                if (orderModel.PropertyMaster_Archive != null && orderModel.PropertyMaster_Archive.Count > 0)
                {
                    order.PropertyMaster_Archive = new List<PropertyMaster_Archive>();
                    foreach (var propertyVm in orderModel.PropertyMaster_Archive)
                    {
                        var property = new PropertyMaster_Archive();
                        property.Id = propertyVm.Id;
                        property.OrderID = propertyVm.OrderID;
                        property.SequenceNumber = propertyVm.SequenceNumber;
                        property.Address1 = propertyVm.Address1;
                        property.Address2 = propertyVm.Address2;
                        property.City = propertyVm.City;
                        property.State = propertyVm.State;
                        property.ZipCode = propertyVm.ZipCode;
                        order.PropertyMaster_Archive.Add(property);
                    }
                }

                if (orderModel.SalesRep_Archive != null && orderModel.SalesRep_Archive.Count > 0)
                {
                    order.SalesRep_Archive = new List<SalesRep_Archive>();
                    foreach (var rep in orderModel.SalesRep_Archive)
                    {
                        var salesUser = new SalesRep_Archive();
                        salesUser.Id = rep.Id;
                        salesUser.OrderId = rep.OrderId;
                        salesUser.SalesRepName = rep.SalesRepName;
                        salesUser.EmailAddress = rep.EmailAddress;
                        order.SalesRep_Archive.Add(salesUser);
                    }
                }
            }

            return order;

        }
    }
}

﻿using FNF.IPX.DataEntities;
using FNF.IPX.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading.Tasks;
using FNF.IPX.Common;
using FNF.IPX.DataAccessLayer;
using System.Linq.Expressions;

namespace FNF.IPX.BusinessLogicLayer.Translators
{
    /// <summary>
    /// 
    /// </summary>
    public static class TemplateTranslator
    {
        public static TemplateModel EntityToModel(Template entity)
        {
            TemplateModel model = new TemplateModel();

            if (entity == null)
                return null;

            model.Id = entity.Id;
            model.Name = entity.Name;
            model.IsActive = entity.IsActive;
            model.CreatedBy = entity.CreatedBy;
            model.CreatedDate = entity.CreatedDate;
            model.ModifiedBy = entity.ModifiedBy;
            model.ModifiedDate = entity.ModifiedDate;

            // model.DefaultHeaders = entity.HeaderMaster.Select(x => new HeaderModel() { Id=x.Id,Name=x.Name  }).ToList();

            model.DefaultHeaders = entity.HeaderTemplateAssociation.Select(x => new HeaderModel() { Id = x.HeaderMaster.Id, Name = x.HeaderMaster.Name, Sorder = x.SortOrder }).ToList();

            return model;

        }

        public static Template ModelToEntity(TemplateModel model)
        {
            Template entity = new Template();

            if (model == null)
                return null;

            entity.Id = model.Id;
            entity.Name = HttpUtility.HtmlEncode(model.Name);
            entity.IsActive = model.IsActive;
            entity.CreatedBy = model.CreatedBy;
            entity.CreatedDate = model.CreatedDate;
            entity.ModifiedBy = model.ModifiedBy;
            entity.ModifiedDate = model.ModifiedDate;

            var loop = 1;
            foreach (var headerAssociation in model.DefaultHeaders)
            {
                entity.HeaderTemplateAssociation.Add(new HeaderTemplateAssociation() { TemplateId = model.Id, HeaderMasterId = headerAssociation.Id, SortOrder = loop++ });

            }
            //entity.HeaderTemplateAssociation = model.DefaultHeaders.Select(x => new HeaderTemplateAssociation() { TemplateId= model.Id,HeaderMasterId=x.Id,SortOrder=x.Sorder   }).ToList();

            return entity;

        }
    }

    public class TemplateFilterTranslator
    {
        public Expression<Func<Template, bool>> Filters { get; private set; }



        public TemplateFilterTranslator(IDictionary<string, string> FilterColumnNameValue, IDictionary<string, string> SortColumns)
        {
            if (FilterColumnNameValue != null)
                AddFilters(FilterColumnNameValue);

            

        }

        private void AddFilters(IDictionary<string, string> FilterColumnNameValue)
        {
            Expression<Func<Template, bool>> filter = null;//=   y => y.CreatedBy==""  ;

            object value = FilterColumnNameValue.Where(x => x.Key == "IsActive").FirstOrDefault().Value;

            if (value != null)
            {
                var v = Convert.ToBoolean(value);
                filter =(y => y.IsActive==v);
            }

            value = FilterColumnNameValue.Where(x => x.Key == "Name").FirstOrDefault().Value;
            if (value != null)
            {
                var v = value.ToString();
                filter =(y => y.Name.Contains(v));
            }

            value = FilterColumnNameValue.Where(x => x.Key == "CreatedBy").FirstOrDefault().Value;
            if (value != null)
            {
                var v = value.ToString();
                filter = (y => y.CreatedBy.Contains(v));
            }

            value = FilterColumnNameValue.Where(x => x.Key == "CreatedDate").FirstOrDefault().Value;
            if (value != null)
            {
                var v = Convert.ToDateTime(value);
                filter =(y => y.CreatedDate == v);
            }

            value = FilterColumnNameValue.Where(x => x.Key == "ModifiedBy").FirstOrDefault().Value;
            if (value != null)
            {
                var v = value.ToString();
                filter = (y => y.ModifiedBy.Contains(v));
            }

            value = FilterColumnNameValue.Where(x => x.Key == "ModifiedDate").FirstOrDefault().Value;
            if (value != null)
            {
                var v = Convert.ToDateTime(value);
                filter =(y => y.ModifiedDate == v);
            }

            Filters = filter;
        }
     

    }
}

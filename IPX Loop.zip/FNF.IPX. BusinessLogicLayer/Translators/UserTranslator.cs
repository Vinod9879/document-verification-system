﻿using FNF.IPX.DataEntities;
using FNF.IPX.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using FNF.IPX.Common;
using FNF.IPX.DataAccessLayer;
//using System.Linq.Expressions;

namespace FNF.IPX.BusinessLogicLayer.Translators
{
    /// <summary>
    /// 
    /// </summary>
    public static  class UserTranslator
    {

        public static UserModel UserEntityToModel(UserDetails entity)
        {
            UserModel model = new UserModel();

            if (entity == null)
                return null ;

            model.HasValue = true;
            model.UserID = entity.Id;
            model.FirstName = entity.Firstname;
            model.UserName = entity.UserName;
            model.LastName = entity.LastName;
            model.EMailID = entity.EmailId;
            model.Password = entity.Password;

            model.IsActive = entity.IsActive;
            model.CreatedBy = entity.CreatedBy;
            model.CreatedDate = entity.CreatedDate;
            model.ModifiedBy = entity.ModifiedBy;
            model.ModifiedDate = entity.ModifiedDate;


            model.SelectedGroups = entity.GroupMaster.Select(x => x.Id).ToList();
            model.SelectedStates = entity.StateMaster.Select(x => x.Id).ToList();
            model.SelectedFlashCodes = entity.FlashCode.Select(x => x.Id).ToList();

            //::Uncomment below lines after getting Permission table
            var permissionsListUderGroup = entity.GroupMaster.Select(x => x.PermissionMaster.Select(y => y.Name)).ToList();
            //User.Group.Select(x => x.PermissionMaster.Select(y => y.Name).ToList()).ToList();

            if (permissionsListUderGroup != null && permissionsListUderGroup.Count > 0)
            {
                model.Permission = new List<string>();
                foreach (var pg in permissionsListUderGroup)
                {
                    foreach (var p in pg)
                    {
                        model.Permission.Add(p);
                    }
                }
            }

            if (entity.GroupMaster != null && entity.GroupMaster.Count > 0)
            {
                model.GroupDefaults = new List<GroupModel>();
                foreach (var group in entity.GroupMaster)
                {
                    var groupModel = new GroupModel();
                    groupModel.Id = group.Id;
                    groupModel.Name = group.Name;

                    if (group.Template != null && group.Template.Count > 0)
                    {
                        groupModel.DeafiltTemplates = new List<TemplateModel>();
                        foreach (var template in group.Template)
                        {
                            var templateModel = new TemplateModel();
                            templateModel.Id = template.Id;
                            templateModel.Name = template.Name;

                            groupModel.DeafiltTemplates.Add(templateModel);
                        }
                    }

                    model.GroupDefaults.Add(groupModel);
                }
            }

            if (entity.StateMaster != null && entity.StateMaster.Count > 0)
            {
                model.StateDefaults = new List<StateModel>();
                foreach (var state in entity.StateMaster)
                {
                    var stateModel = new StateModel();
                    stateModel.Id = state.Id;
                    stateModel.Code = state.Code;
                    stateModel.Name = state.Name;

                    model.StateDefaults.Add(stateModel);
                }
            }

            if (entity.FlashCode != null && entity.FlashCode.Count > 0)
            {
                model.FlashCodeDefaults = new List<FlashCodeModel>();
                foreach (var flash in entity.FlashCode)
                {
                    var flashModel = new FlashCodeModel();
                    flashModel.Id = flash.Id;
                    flashModel.Code = flash.FlashCode1;

                    model.FlashCodeDefaults.Add(flashModel);
                }
            }

            return model;

        }

        public static UserDetails UserModelToEntity(UserModel model)
        {
            UserDetails entity = new UserDetails();

            if (model == null)
                return null;

            entity.Id = model.UserID;
            entity.Firstname = model.FirstName;
            entity.UserName = model.UserName;
            entity.LastName = model.LastName;
            entity.EmailId = model.EMailID;
            //user.IsAdmin = userModel.IsAdmin;
            entity.Password = model.Password;

            entity.IsActive = model.IsActive;
            entity.CreatedBy = model.CreatedBy;
            entity.CreatedDate = model.CreatedDate;
            entity.ModifiedBy = model.ModifiedBy;
            entity.ModifiedDate = model.ModifiedDate;


            if (model.GroupDefaults != null && model.GroupDefaults.Count > 0)
            {
                entity.GroupMaster = new List<GroupMaster>();
                foreach (var groupModel in model.GroupDefaults)
                {
                    var group = new GroupMaster();
                    group.Id = groupModel.Id;
                    group.Name = groupModel.Name;

                    if (groupModel.DeafiltTemplates != null && groupModel.DeafiltTemplates.Count > 0)
                    {
                        group.Template = new List<Template>();
                        foreach (var templateModel in groupModel.DeafiltTemplates)
                        {
                            var template = new Template();
                            template.Id = templateModel.Id;
                            template.Name = templateModel.Name;

                            group.Template.Add(template);
                        }
                    }

                    entity.GroupMaster.Add(group);
                }
            }

            if (model.StateDefaults != null && model.StateDefaults.Count > 0)
            {
                entity.StateMaster = new List<StateMaster>();
                foreach (var statesModel in model.StateDefaults)
                {
                    var state = new StateMaster();
                    state.Id = statesModel.Id;
                    state.Code = statesModel.Code;
                    state.Name = statesModel.Name;

                    entity.StateMaster.Add(state);
                }
            }

            if (model.FlashCodeDefaults != null && model.FlashCodeDefaults.Count > 0)
            {
                entity.FlashCode = new List<FlashCode>();
                foreach (var flashModel in model.FlashCodeDefaults)
                {
                    var flash = new FlashCode();
                    flash.Id = flashModel.Id;
                    flash.FlashCode1 = flashModel.Code;

                    entity.FlashCode.Add(flash);
                }
            }

            return entity;

        }
    }




    public class UserFilterTranslator
    {
        public Expression<Func<UserDetails, bool>> Filters { get; private set; }

       
        public UserFilterTranslator(IDictionary<string, string> FilterColumnNameValue, IDictionary<string, string> SortColumns)
        {
            if (FilterColumnNameValue != null)
                AddFilters(FilterColumnNameValue);

        }

        private void AddFilters(IDictionary<string, string > FilterColumnNameValue)
        {
            Expression<Func<UserDetails, bool>> filter = null;//=   y => y.CreatedBy==""  ;


            object value = FilterColumnNameValue.Where(x => x.Key == "IsActive").FirstOrDefault().Value;
            if (value != null)
            {
                var v = Convert.ToBoolean(value);
                filter = (y => y.IsActive == v);
            }

            value = FilterColumnNameValue.Where(x => x.Key == "UserName").FirstOrDefault().Value;
            if (value != null)
            {
                var v = value.ToString();
                filter = (y => y.UserName.Contains(v));
            }

            value = FilterColumnNameValue.Where(x => x.Key == "Firstname").FirstOrDefault().Value;
            if (value != null)
            {
                var v = value.ToString();
                filter = (y => y.Firstname.Contains(v));
            }
            value = FilterColumnNameValue.Where(x => x.Key == "LastName").FirstOrDefault().Value;
            if (value != null)
            {
                var v = value.ToString();
                filter = (y => y.LastName.Contains(v));
            }

            value = FilterColumnNameValue.Where(x => x.Key == "EmailId").FirstOrDefault().Value;
            if (value != null)
            {
                var v = value.ToString();
                filter = (y => y.EmailId.Contains(v));
            }

            value = FilterColumnNameValue.Where(x => x.Key == "CreatedBy").FirstOrDefault().Value;
            if (value != null)
            {
                var v = value.ToString();
                filter = (y => y.CreatedBy.Contains(v));
            }

            value = FilterColumnNameValue.Where(x => x.Key == "CreatedDate").FirstOrDefault().Value;
            if (value != null)
            {
                var v = Convert.ToDateTime(value);
                filter = (y => y.CreatedDate == v);
            }

            value = FilterColumnNameValue.Where(x => x.Key == "ModifiedBy").FirstOrDefault().Value;
            if (value != null)
            {
                var v = value.ToString();
                filter = (y => y.ModifiedBy.Contains(v));
            }

            value = FilterColumnNameValue.Where(x => x.Key == "ModifiedDate").FirstOrDefault().Value;
            if (value != null)
            {
                var v = Convert.ToDateTime(value);
                filter = (y => y.ModifiedDate == v);
            }

            Filters = filter;
        }
   

    }
}

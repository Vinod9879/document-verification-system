﻿using FNF.IPX.DataEntities;
using FNF.IPX.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FNF.IPX.Common;
using FNF.IPX.DataAccessLayer;
using System.Linq.Expressions;

namespace FNF.IPX.BusinessLogicLayer.Translators
{
    /// <summary>
    /// 
    /// </summary>
    public static class UserLoginDetailsTranslator
    {
        public static UserLoginDetailsModel UserLoginDetailsEntityToModel(UserLoginDetails userLoginDetails)
        {
            UserLoginDetailsModel userLoginDetailsModel = new UserLoginDetailsModel();

            if (userLoginDetails == null)
                return null ;

            userLoginDetailsModel.Id = userLoginDetails.Id;
            userLoginDetailsModel.Username = userLoginDetails.Username;
            userLoginDetailsModel.FullName = userLoginDetails.FullName;
            userLoginDetailsModel.LoginTime = userLoginDetails.LoginTime;
            userLoginDetailsModel.LogoutTime = userLoginDetails.LogoutTime;
            userLoginDetailsModel.Duration = userLoginDetails.Duration;
            
            return userLoginDetailsModel;

        }

        public static UserLoginDetails UserLoginDetailsModelToEntity(UserLoginDetailsModel userLoginDetailsModel)
        {
            UserLoginDetails userLoginDetails = new UserLoginDetails();

            if (userLoginDetailsModel == null)
                return null;

            userLoginDetails.Id = userLoginDetailsModel.Id;
            userLoginDetails.Username = userLoginDetailsModel.Username;
            userLoginDetails.FullName = userLoginDetailsModel.FullName;
            userLoginDetails.LoginTime = userLoginDetailsModel.LoginTime;
            userLoginDetails.LogoutTime = userLoginDetailsModel.LogoutTime;
            userLoginDetails.Duration = userLoginDetailsModel.Duration;

            return userLoginDetails;
        }
    }

    public class UserLoginDetailsFilterTranslator
    {
        public Expression<Func<UserLoginDetails, bool>> Filters { get; private set; }



        public UserLoginDetailsFilterTranslator(IDictionary<string, string> FilterColumnNameValue, IDictionary<string, string> SortColumns)
        {
            if (FilterColumnNameValue != null)
                AddFilters(FilterColumnNameValue);
        }

        private void AddFilters(IDictionary<string, string> FilterColumnNameValue)
        {
            Expression<Func<UserLoginDetails, bool>> filter = null;//=   y => y.CreatedBy==""  ;

            object value = FilterColumnNameValue.Where(x => x.Key == "Username").FirstOrDefault().Value;

            if (value != null)
            {
                var v = Convert.ToString(value);
                filter = (y => y.Username == v);
            }

            value = FilterColumnNameValue.Where(x => x.Key == "FullName").FirstOrDefault().Value;
            if (value != null)
            {
                var v = value.ToString();
                filter = (y => y.FullName.Contains(v));
            }

            value = FilterColumnNameValue.Where(x => x.Key == "Duration").FirstOrDefault().Value;
            if (value != null)
            {
                var v = value.ToString();
                filter = (y => y.Duration.Contains(v));
            }

            value = FilterColumnNameValue.Where(x => x.Key == "LoginTime").FirstOrDefault().Value;
            if (value != null)
            {
                var v = Convert.ToDateTime(value);
                var v2 = v.AddDays(1);
                filter = (y => y.LoginTime.Value >= v && y.LoginTime < v2);
            }
            Filters = filter;
        }


    }
}

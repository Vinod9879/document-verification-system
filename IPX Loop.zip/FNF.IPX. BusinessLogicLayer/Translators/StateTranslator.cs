﻿using FNF.IPX.DataEntities;
using FNF.IPX.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FNF.IPX.Common;
using FNF.IPX.DataAccessLayer;

namespace FNF.IPX.BusinessLogicLayer.Translators
{
    /// <summary>
    /// 
    /// </summary>
    public static class StateTranslator
    {
        public static StateModel StateEntityToModel(StateMaster state)
        {
            StateModel stateModel = new StateModel();

            if (state == null)
                return null ;

            stateModel.Id = state.Id;
            stateModel.Code = state.Code;
            stateModel.Name = state.Name;
            
            return stateModel;

        }

        public static StateMaster StateModelToEntity(StateModel stateModel)
        {
            StateMaster state = new StateMaster();

            if (stateModel == null)
                return null;

            state.Id = stateModel.Id;
            state.Code = stateModel.Code;
            state.Name = stateModel.Name;

            return state;
        }
    }
}

﻿using FNF.IPX.DataEntities;
using FNF.IPX.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FNF.IPX.Common;
using FNF.IPX.DataAccessLayer;

namespace FNF.IPX.BusinessLogicLayer.Translators
{
    /// <summary>
    /// 
    /// </summary>
    public static class PermissionTranslator
    {
        public static PermissionModel  EntityToModel(PermissionMaster  entity)
        {
            PermissionModel model = new PermissionModel();

            if (entity == null)
                return null ;

            model.Id = entity.Id;
            model.Name = entity.Name;
            model.Description = entity.Description;

           
            return model;

        }

        public static PermissionMaster ModelToEntity(PermissionModel model)
        {
            PermissionMaster entity = new PermissionMaster();

            if (model == null)
                return null;

            entity.Id = model.Id;
            entity.Name = model.Name;
            entity.Description = model.Description;

            return entity;

        }
    }
}

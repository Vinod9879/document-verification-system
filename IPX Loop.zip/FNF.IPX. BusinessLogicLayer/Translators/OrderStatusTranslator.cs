﻿using FNF.IPX.DataEntities;
using FNF.IPX.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FNF.IPX.Common;
using FNF.IPX.DataAccessLayer;

namespace FNF.IPX.BusinessLogicLayer.Translators
{
    /// <summary>
    /// 
    /// </summary>
    public static class OrderStatusTranslator
    {
        public static OrderStatusModel OrderStatusEntityToModel(OrderStatus orderStatus)
        {
            OrderStatusModel orderStatusModel = new OrderStatusModel();

            if (orderStatus == null)
                return null ;

            orderStatusModel.Id = orderStatus.Id;
            orderStatusModel.Status = orderStatus.Status;
            orderStatusModel.Priority = orderStatus.Priority;
            orderStatusModel.IsOpenStatus = orderStatus.IsOpenStatus;
            
            return orderStatusModel;

        }

        public static OrderStatus OrderStatusModelToEntity(OrderStatusModel orderStatusModel)
        {
            OrderStatus orderStatus = new OrderStatus();

            if (orderStatusModel == null)
                return null;

            orderStatus.Id = orderStatusModel.Id;
            orderStatus.Status = orderStatusModel.Status;
            orderStatus.Priority = orderStatusModel.Priority;
            orderStatus.IsOpenStatus = orderStatusModel.IsOpenStatus;

            return orderStatus;
        }
    }
}

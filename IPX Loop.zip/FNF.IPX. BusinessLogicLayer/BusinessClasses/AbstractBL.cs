﻿using FNF.IPX.DataAccessLayer;
using FNF.IPX.DataEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace FNF.IPX.BusinessLogicLayer.BusinessClasses
{
    public class AbstractBL
    {
        private UnitofWork unitofWork;
        protected UnitofWork UnitofWork
        {
            get
            {
                if (unitofWork == null)
                {
                    unitofWork = new UnitofWork(new IPXEntities());
                }
                return unitofWork;
            }
        }

      
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using FNF.IPX.BusinessLogicLayer.Translators;
using System.Linq.Expressions;
using RefactorThis.GraphDiff;
using FNF.IPX.DataEntities;
using FNF.IPX.Common;
using FNF.IPX.Models;
using FNF.IPX.DataAccessLayer;
using PagedList;


namespace FNF.IPX.BusinessLogicLayer.BusinessClasses
{
                                                                 
    public class GroupBussinessLogic : AbstractBL, IDisposable
    {


        public GroupBussinessLogic()
        { }


        public IEnumerable<GroupModel> GetAllPagedItems(IDictionary<string, string> FilterColumnNameValue, IDictionary<string, string> SortColumns, int PageNumber, int PageSize)
        {

            LogErrors.WriteLog("GroupBussinessLogic/GetAllPagedItems executing");


            GroupFilterTranslator filterTranslator = new GroupFilterTranslator(FilterColumnNameValue, SortColumns);



            var entities = base.UnitofWork
                        .GroupRepository
                        .GetAllPagedItems(filterTranslator.Filters, SortColumns, PageNumber, PageSize);

            var models = new List<GroupModel>();

          

            foreach (var entity in entities)
            {
                var model = GroupTranslator.EntityToModel(entity);
                model.PageNumber = entities.PageNumber;
                model.PageCount = entities.PageCount;
                model.TotalItemCount = entities.TotalItemCount;
                model.PageSize = entities.PageSize;

                models.Add(model);
            }

            LogErrors.WriteLog("GroupBussinessLogic/GetAllPagedItems Executed");
            return models.ToList();


        }

        public IEnumerable<GroupModel> GetAll()
        {
            LogErrors.WriteLog("GroupBussinessLogic/GetAll executing");

            var entities = base.UnitofWork
                        .GroupRepository
                        .Get(orderBy: null);

            var models = new List<GroupModel>();


            foreach (var entity in entities)
            {
                var model = GroupTranslator.EntityToModel(entity);
                models.Add(model);
            }

            LogErrors.WriteLog("GroupBussinessLogic/GetAll Executed");
            return models;


        }




        public GroupModel GetByName(string  Name)
        {

            LogErrors.WriteLog("GroupBussinessLogic/GetByName executing");

            var entity = base.UnitofWork
                        .GroupRepository
                        .Get(x => x.Name == Name).FirstOrDefault();
            var model = GroupTranslator.EntityToModel(entity);

            LogErrors.WriteLog("GroupBussinessLogic/GetByName Executed");
            return model;

        }


        public GroupModel GetById(int id)
        {

            LogErrors.WriteLog("GroupBussinessLogic/GetById executing");

            var entity = base.UnitofWork
                        .GroupRepository
                        .GetById(id);
            var model = GroupTranslator.EntityToModel(entity);

            LogErrors.WriteLog("GroupBussinessLogic/GetById Executed");
            return model;

        }

        public void Save(GroupModel model)
        {

            LogErrors.WriteLog("GroupBussinessLogic/Save executing");

            var entity = GroupTranslator.ModelToEntity(model);

            base.UnitofWork.Context.UpdateGraph<GroupMaster>(
              entity, m => m.AssociatedCollection(u => u.PermissionMaster)
              .AssociatedCollection(u => u.Template)
              );
            //base.UnitofWork
            //            .GroupRepository
            //            .Insert(entity);


            base.UnitofWork.Save();

            LogErrors.WriteLog("GroupBussinessLogic/Save Executed");

        }

        public void Update(GroupModel model)
        {

            LogErrors.WriteLog("GroupBussinessLogic/Update executing");

            var entity = GroupTranslator.ModelToEntity(model);

            base.UnitofWork.Context.UpdateGraph<GroupMaster>(
                entity, m => m.AssociatedCollection(u => u.PermissionMaster)
                .AssociatedCollection(u => u.Template)
                );


            //base.UnitofWork
            //            .GroupRepository
            //            .Update(entity);
            base.UnitofWork.Save();

            LogErrors.WriteLog("GroupBussinessLogic/Update  Executed");

        }

        public void Delete(int Id)
        {

            LogErrors.WriteLog("GroupBussinessLogic/Delete  executing");

            var entity = base.UnitofWork
                        .GroupRepository
                        .GetById(Id);

            //Clear group associations
            entity.PermissionMaster.Clear();
            entity.Template.Clear();
            //Finally, remove user
            base.UnitofWork
                        .GroupRepository
                        .Delete(Id);
            base.UnitofWork.Save();

            LogErrors.WriteLog("GroupBussinessLogic/Delete Executed");

        }

        public void ToUI(GroupModel model)
        {

            LogErrors.WriteLog("GroupBussinessLogic/ToUI Executing");
            if (model == null) return;
            model.SelectedPermission = model.DefaultPermission.ToList().ConvertAll(t => t.Id);
            model.SelectedTemplates = model.DeafiltTemplates.ToList().ConvertAll(t => t.Id);
            LogErrors.WriteLog("GroupBussinessLogic/ToUI Executed");
        }

        public void FromUI(GroupModel model, Func<int, TemplateModel> delegatedMethode)
        {
            LogErrors.WriteLog("GroupBussinessLogic/FromUI Executing");
            model.DeafiltTemplates = model.SelectedTemplates.ConvertAll(g => delegatedMethode(g));
            LogErrors.WriteLog("GroupBussinessLogic/FromUI Executed");
        }

        public void FromUI(GroupModel model, Func<int, PermissionModel> delegatedMethode)
        {
            LogErrors.WriteLog("GroupBussinessLogic/FromUI Executing");
            model.DefaultPermission = model.SelectedPermission.ConvertAll(g => delegatedMethode(g));
            LogErrors.WriteLog("GroupBussinessLogic/FromUI Executed");
        }


        public void Dispose()
        {
            base.UnitofWork.Dispose();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using FNF.IPX.BusinessLogicLayer.Translators;
using System.Linq.Expressions;
using RefactorThis.GraphDiff;
using FNF.IPX.DataEntities;
using FNF.IPX.Common;
using FNF.IPX.Models;
using FNF.IPX.DataAccessLayer;



namespace FNF.IPX.BusinessLogicLayer.BusinessClasses
{
    //public class TemplateBussinessLogic<enity,model> : AbstractBL, IDisposable where enity : Template 
    //                                                               where model :  GroupModel
    public class IPXSalesRepBussinessLogic : AbstractBL, IDisposable
    {


        public IPXSalesRepBussinessLogic()
        { }


        public IEnumerable<IPXSalesRepModel> GetAll()
        {
            try
            {
                LogErrors.WriteLog("IPXSalesRepBL/GetSalesRep executing");

                var entities = base.UnitofWork
                            .IPXSalesRepRepository
                            .Get(orderBy: null);

                var models = new List<IPXSalesRepModel>();


                foreach (var entity in entities)
                {
                    var model = IPXSalesRepTranslator.EntityToModel(entity);
                    models.Add(model);
                }

                LogErrors.WriteLog("IPXSalesRepBL/GetSalesRep Executed");
                return models;
            }
            catch (Exception ex)
            {
                LogErrors.WriteLog("IPXSalesRepBL/GetSalesRep error");

                LogErrors.WriteLog(ex);
                throw;
            }

        }






        public IPXSalesRepModel GetById(int id)
        {
            try
            {
                LogErrors.WriteLog("IPXSalesRepBL/SalesRepId executing");

                var entity = base.UnitofWork
                            .IPXSalesRepRepository
                            .GetById(id);
                var model = IPXSalesRepTranslator.EntityToModel(entity);

                LogErrors.WriteLog("IPXSalesRepBL/SalesRepId Executed");
                return model;
            }
            catch (Exception ex)
            {
                LogErrors.WriteLog("IPXSalesRepBL/SalesRepId error");
                LogErrors.WriteLog(ex);
                throw;
            }
        }

        public void Save(IPXSalesRepModel model)
        {
            try
            {
                LogErrors.WriteLog("IPXSalesRepBL/SaveSalesRep executing");

                var entity = IPXSalesRepTranslator.ModelToEntity(model);

                base.UnitofWork.Context.UpdateGraph<IPXSalesRep>(entity);
                //base.UnitofWork
                //            .GroupRepository
                //            .Insert(entity);


                base.UnitofWork.Save();

                LogErrors.WriteLog("IPXSalesRepBL/SaveSalesRep Executed");
            }
            catch (Exception ex)
            {
                LogErrors.WriteLog("UserBL/SaveUser error");
                LogErrors.WriteLog(ex);
                throw;
            }
        }

        public void Dispose()
        {
            base.UnitofWork.Dispose();
        }

    }
}

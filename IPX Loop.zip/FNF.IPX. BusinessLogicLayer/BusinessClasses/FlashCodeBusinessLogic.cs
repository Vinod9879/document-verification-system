﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FNF.IPX.Models;
using FNF.IPX.Common;

namespace FNF.IPX.BusinessLogicLayer.BusinessClasses
{
    public class FlashCodeBusinessLogic : AbstractBL, IDisposable
    {
        public FlashCodeBusinessLogic()
        { }

        public IEnumerable<FlashCodeModel> GetFlashDetails()
        {
            LogErrors.WriteLog("FlashCodeBL/GetFlashDetails executing");

            var flashDetails = base.UnitofWork
                             .FlashCodeRepository
                             .Get(orderBy: null);

            var flashColl = new List<FlashCodeModel>();
            foreach(var flash in flashDetails)
            {
                var flashVM = new FlashCodeModel();
                flashVM.Id = flash.Id;
                flashVM.Code = flash.FlashCode1;
                flashColl.Add(flashVM);
            }

            LogErrors.WriteLog("FlashCodeBL/GetFlashDetails Executed");
            return flashColl;
        }

        public FlashCodeModel GetFlashDetailById(int id)
        {
            LogErrors.WriteLog("FlashCodeBL/GetFlashDetailById executing");

            var flash = base.UnitofWork
                        .FlashCodeRepository
                        .GetById(id);
            
            var flashVM = new FlashCodeModel();
            flashVM.Id = flash.Id;
            flashVM.Code = flash.FlashCode1;

            LogErrors.WriteLog("FlashCodeBL/GetFlashDetailById Executed");
            return flashVM;
        }

        public void Dispose()
        {
            base.UnitofWork.Dispose();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using FNF.IPX.BusinessLogicLayer.Translators;
using System.Linq.Expressions;
using RefactorThis.GraphDiff;
using FNF.IPX.DataEntities;
using FNF.IPX.Common;
using FNF.IPX.Models;
using FNF.IPX.DataAccessLayer;



namespace FNF.IPX.BusinessLogicLayer.BusinessClasses
{
    //public class TemplateBussinessLogic<enity,model> : AbstractBL, IDisposable where enity : Template 
    //                                                               where model :  PermissionMaster
    public class PermissionBussinessLogic : AbstractBL, IDisposable
    {


        public PermissionBussinessLogic()
        { }


        public IEnumerable<PermissionModel> GetAll()
        {

            LogErrors.WriteLog("PermissionBussinessLogic/GetAll executing");

            var entities = base.UnitofWork
                        .PermissionMasterRepository
                        .Get(orderBy: null);

            var models = new List<PermissionModel>();


            foreach (var entity in entities)
            {
                var model = PermissionTranslator.EntityToModel(entity);
                models.Add(model);
            }

            LogErrors.WriteLog("PermissionBussinessLogic/GetAll Executed");
            return models;


        }






        public PermissionModel GetById(int id)
        {

            LogErrors.WriteLog("PermissionBussinessLogic/GetById executing");

            var entity = base.UnitofWork
                        .PermissionMasterRepository
                        .GetById(id);
            var model = PermissionTranslator.EntityToModel(entity);

            LogErrors.WriteLog("PermissionBussinessLogic/GetById Executed");
            return model;

        }

        public void Save(PermissionModel model)
        {

            LogErrors.WriteLog("PermissionBussinessLogic/Save executing");

            var entity = PermissionTranslator.ModelToEntity(model);
            // base.UnitofWork.Context.UpdateGraph<Template>(entity, m => m.AssociatedCollection(u => u.HeaderMaster));


            base.UnitofWork
                        .PermissionMasterRepository
                        .Insert(entity);


            base.UnitofWork.Save();

            LogErrors.WriteLog("PermissionBussinessLogic/Save Executed");

        }

        public void Update(PermissionModel model)
        {

            LogErrors.WriteLog("PermissionBussinessLogic/Update Executed");

            var entity = PermissionTranslator.ModelToEntity(model);

            // base.UnitofWork.Context.UpdateGraph<Template>(entity, m => m.AssociatedCollection(u => u.HeaderMaster));


            base.UnitofWork
                        .PermissionMasterRepository
                        .Update(entity);

            base.UnitofWork.Save();

            LogErrors.WriteLog("PermissionBussinessLogic/Update Executed");

        }

        public void Delete(int Id)
        {

            LogErrors.WriteLog("PermissionBussinessLogic/Delete Executed");

            var entity = base.UnitofWork
                        .PermissionMasterRepository
                        .GetById(Id);



            //Finally, remove user
            base.UnitofWork
                        .PermissionMasterRepository
                        .Delete(Id);
            base.UnitofWork.Save();

            LogErrors.WriteLog("PermissionBussinessLogic/Delete Executed");

        }

        public void ToUI(PermissionMaster model)
        {

            if (model == null) return;
            // model.SelectedHeaders = model.DefaultHeaders.ToList().ConvertAll(t => t.Id);


        }

        public void FromUI(PermissionMaster model, Func<int, HeaderModel> delegatedMethode)
        {
            // model.DefaultHeaders = model.SelectedHeaders.ConvertAll(g => delegatedMethode(g));
        }


        public void Dispose()
        {
            base.UnitofWork.Dispose();
        }

    }
}

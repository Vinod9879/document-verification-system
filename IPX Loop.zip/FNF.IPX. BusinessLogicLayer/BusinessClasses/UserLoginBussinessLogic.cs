﻿using FNF.IPX.DataAccessLayer;
using FNF.IPX.DataEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using FNF.IPX.Common;
using FNF.IPX.Models;

using FNF.IPX.BusinessLogicLayer.Translators;

namespace FNF.IPX.BusinessLogicLayer.BusinessClasses
{
    public class UserLoginBussinessLogic : AbstractBL, IDisposable
    {
        public UserLoginBussinessLogic()
        {

        }
        public UserModel GetUserDetails(String UserName, String Password)
        {
            try
            {
                LogErrors.WriteLog("UserLoginBL/GetUserDetails executing");

                UserModel userVm = new UserModel();
                var user = base.UnitofWork
                               .UserRepository
                               .Get(t => t.UserName == UserName && t.Password == Password, orderBy: null)
                               .FirstOrDefault();

                userVm = UserTranslator.UserEntityToModel(user);
                LogErrors.WriteLog("UserLoginBL/GetUserDetails Executed");
                return userVm;
            }
            catch (Exception ex)
            {
                LogErrors.WriteLog("UserLoginBL/GetUserDetails error");

                LogErrors.WriteLog(ex);
                throw;
            }

        }

        public UserModel ValidateUserByEmailIDPassword(String EmailId, String Password)
        {
            try
            {
                LogErrors.WriteLog("UserLoginBL/ValidateUserByEmailIDPassword executing");

                UserModel userVm = new UserModel();
                var user = base.UnitofWork
                               .UserRepository
                               .Get(t => t.EmailId == EmailId && t.Password == Password, orderBy: null)
                               .FirstOrDefault();

                userVm = UserTranslator.UserEntityToModel(user);
                LogErrors.WriteLog("UserLoginBL/ValidateUserByEmailIDPassword Executed");
                return userVm;
            }
            catch (Exception ex)
            {
                LogErrors.WriteLog("UserLoginBL/ValidateUserByEmailIDPassword error");

                LogErrors.WriteLog(ex);
                throw;
            }

        }

        public void Dispose()
        {
            base.UnitofWork.Dispose();
        }
    }
}

﻿using FNF.IPX.DataAccessLayer;
using FNF.IPX.DataEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using FNF.IPX.Common;
using FNF.IPX.Models;
using FNF.IPX.Common.LambdaExtensions;

using FNF.IPX.BusinessLogicLayer.Translators;
using System.Linq.Expressions;
using RefactorThis.GraphDiff;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Reflection;

namespace FNF.IPX.BusinessLogicLayer.BusinessClasses
{
    public class OrderArchiveBussinessLogic : AbstractBL, IDisposable
    {
        private UserBussinessLogic userBLInstance;

        public UserBussinessLogic UserBLInstance
        {
            get
            {
                if (userBLInstance == null)
                {
                    userBLInstance = new UserBussinessLogic();
                }
                return userBLInstance;
            }
        }

        public OrderArchiveBussinessLogic()
        {

        }

        public OrderDetailsArchiveModel GetOrderById(int id)
        {
            LogErrors.WriteLog("OrderArchiveBussinessLogic/GetOrderById executing");

            var order = base.UnitofWork
                        .OrdersArchiveRepository
                        .GetById(id);

            OrderDetailsArchiveModel orderVM = OrderArchiveTranslator.OrderEntityToModel(order);

            LogErrors.WriteLog("OrderArchiveBussinessLogic/GetOrderById Executed");
            return orderVM;
        }

        public List<OrderHistoryArchiveModel> GetOrderHistoryByOrderId(int orderId)
        {
            LogErrors.WriteLog("OrderArchiveBussinessLogic/GetOrderHistoryByOrderId executing");

            var orders = base.UnitofWork
                        .OrderHistoryArchiveRepository
                        .Get(t => t.OrderId == orderId, orderBy: null);

            var orderHistoryVMColl = OrderHistoryArchiveTranslator.OrderEntityListToModelList(orders);

            LogErrors.WriteLog("OrderArchiveBussinessLogic/GetOrderHistoryByOrderId Executed");
            return orderHistoryVMColl;
        }

        public OrderMetaArchiveModel GetOrdersVMForUser(int userId, OrderMetaArchiveModel orderModel)
        {
            LogErrors.WriteLog("OrderArchiveBussinessLogic/GetOrdersVMForUser executing");

            orderModel.Templates = GetTemplatesForUser(userId);

            var templateIds = string.Join(",", orderModel.Templates.ConvertAll(t => t.Id));
            //Todo: sort the headers
            orderModel.Headers = GetHeaders(orderModel.Templates);

            //orderModel.AllStatuses = GetStatuses();
            //orderModel.Flags = GetFollowupFlags();
            //orderModel.Users = UserBLInstance.GetUsers();
            orderModel.TrackingFlags = GetTrackingFlags();

            string userFilter = "";
            if (!HttpContext.Current.User.IsInRole(PERMISSION.CanSeeAllOrders))
            {
                //userFilter = string.Format(" [Sales Rep Email] Like '%{0}%'", HttpContext.Current.User.Identity.GetInfo().Email);
                userFilter = string.Format(" [{0}] Like '%{1}%'", OrderMetaModel.Str_IPXSalesRepEmail, HttpContext.Current.User.Identity.GetInfo().Email);
            }
            if (!string.IsNullOrEmpty(userFilter))
            {
                if (string.IsNullOrEmpty(orderModel.Search) || !orderModel.Search.ToLower().Contains(userFilter.ToLower()))
                {
                    orderModel.Search += string.Format((string.IsNullOrEmpty(orderModel.Search) ||
                                                        (string.IsNullOrEmpty(orderModel.Search.Trim()))) ? (" " + userFilter) : (" {0} " + userFilter), " AND ");
                }
            }

            string isDeletedFilter = "([IsDeleted] = 0 OR [IsDeleted] IS NULL)";
            if (string.IsNullOrEmpty(orderModel.Search) || !orderModel.Search.ToLower().Contains(isDeletedFilter.ToLower()))
            {
                orderModel.Search += string.Format((string.IsNullOrEmpty(orderModel.Search) ||
                                                        (string.IsNullOrEmpty(orderModel.Search.Trim()))) ? (" " + isDeletedFilter + " ") : (" {0} " + isDeletedFilter), " AND ");
            }
            orderModel.Search = HttpUtility.HtmlDecode(orderModel.Search);
            FetchOrdersFromSP(orderModel, templateIds);
            orderModel.CheckIndex();

            LogErrors.WriteLog("OrderArchiveBussinessLogic/GetOrdersVMForUser Executed");
            return orderModel;
        }

        private void FetchOrdersFromSP(OrderMetaArchiveModel orderModel, string templateIds)
        {
            List<SqlParameter> lparam = new List<SqlParameter>() { new SqlParameter("TemplateIDs", templateIds) };
            lparam.AddRange(new List<SqlParameter>() 
            { 
                new SqlParameter("Sort", orderModel.Sort), 
                new SqlParameter("Order", orderModel.Order), 
                new SqlParameter("Search", string.IsNullOrEmpty(orderModel.Search)? DBNull.Value: (dynamic) orderModel.Search
                                                                                                            .Replace(GeneralConstants.AND_Placeholder, "AND")) ,
                new SqlParameter("Pageindex", orderModel.PageIndex),
                new SqlParameter("Pagesize", orderModel.Pagesize)
            });

            orderModel.Results = base.UnitofWork.Context.GetResults(DBConstants.SP_GetOrders_Archive, CommandType.StoredProcedure, lparam);
        }

        public List<IDictionary<string, dynamic>> GetOrdersFromSPForDownload(string templateIds, string searchCriteria)
        {
            LogErrors.WriteLog("OrderArchiveBussinessLogic/GetOrdersFromSPForDownload executing");

            //var templates = GetTemplatesForUser(userID);
            //var templateIds = string.Join(",", templates.ConvertAll(t => t.Id));

            string userFilter = "";
            if (!HttpContext.Current.User.IsInRole(PERMISSION.CanSeeAllOrders))
            {
                //userFilter = string.Format(" [Sales Rep Email] Like '%{0}%'", HttpContext.Current.User.Identity.GetInfo().Email);
                userFilter = string.Format(" [{0}] Like '%{1}%'", OrderMetaModel.Str_IPXSalesRepEmail, HttpContext.Current.User.Identity.GetInfo().Email);
            }
            if (!string.IsNullOrEmpty(userFilter))
            {
                if (string.IsNullOrEmpty(searchCriteria) || !searchCriteria.ToLower().Contains(userFilter.ToLower()))
                {
                    searchCriteria += string.Format((string.IsNullOrEmpty(searchCriteria) ||
                                                        (string.IsNullOrEmpty(searchCriteria.Trim()))) ? (" " + userFilter) : (" {0} " + userFilter), " AND ");
                }
            }

            string isDeletedFilter = "([IsDeleted] = 0 OR [IsDeleted] IS NULL)";
            if (string.IsNullOrEmpty(searchCriteria) || !searchCriteria.ToLower().Contains(isDeletedFilter.ToLower()))
            {
                searchCriteria += string.Format((string.IsNullOrEmpty(searchCriteria) ||
                                                        (string.IsNullOrEmpty(searchCriteria.Trim()))) ? (" " + isDeletedFilter + " ") : (" {0} " + isDeletedFilter), " AND ");
            }

            List<SqlParameter> lparam = new List<SqlParameter>() { new SqlParameter("TemplateIDs", templateIds) };
            lparam.AddRange(new List<SqlParameter>() 
            {
                new SqlParameter("Search", string.IsNullOrEmpty(searchCriteria)? DBNull.Value: (dynamic) searchCriteria)
            });

            var results = base.UnitofWork.Context.GetResults(DBConstants.SP_GetOrderDetailsForDownload_Archive, CommandType.StoredProcedure, lparam);
            LogErrors.WriteLog("OrderArchiveBussinessLogic/GetOrdersFromSPForDownload Executed");

            return results;
        }

        private List<TrackFlagsMasterModel> GetTrackingFlags()
        {
            LogErrors.WriteLog("OrderArchiveBussinessLogic/GetTrackingFlags executing");

            var entities = base.UnitofWork
                                .TrackFlagsMasterRepository
                                .Get(orderBy: t => t.OrderBy(s => s.Priority));

            var modelColl = new List<TrackFlagsMasterModel>();
            foreach (var entity in entities)
            {
                var model = new TrackFlagsMasterModel();
                model.Id = entity.Id;
                model.Name = entity.Name;
                model.Priority = entity.Priority;
                modelColl.Add(model);
            }

            LogErrors.WriteLog("OrderArchiveBussinessLogic/GetTrackingFlags Executed");

            return modelColl;
        }


        public List<TemplateModel> GetTemplatesForUser(int userId)
        {
            //try
            //{
            LogErrors.WriteLog("OrderArchiveBussinessLogic/GetTemplatesForUser executing");

            var user = base.UnitofWork
                        .UserRepository
                        .GetById(userId);

            var entities = from grp in user.GroupMaster
                           from tmp in grp.Template
                           select tmp;

            var models = new List<TemplateModel>();
            foreach (var entity in entities)
            {
                var model = TemplateTranslator.EntityToModel(entity);
                models.Add(model);
            }

            LogErrors.WriteLog("OrderArchiveBussinessLogic/GetTemplatesForUser Executed");
            return models;
            //}
            //catch (Exception ex)
            //{
            //    LogErrors.WriteLog("OrderArchiveBussinessLogic/GetTemplatesForUser error");

            //    LogErrors.WriteLog(ex);
            //    throw;
            //}

        }

        public void UpdateTrackingFlag(int orderId, string status)
        {
            LogErrors.WriteLog("OrderArchiveBussinessLogic/UpdateTrackingFlag executing");

            var order = UnitofWork.OrdersArchiveRepository.DbSet.AsNoTracking().FirstOrDefault(t => t.OrderID == orderId);

            order.TrackFlag = status;
            order.UpdatedDate = DateTime.Now;
            order.ModifiedBy = HttpContext.Current.User.Identity.GetInfo().FullName;

            UnitofWork.OrdersArchiveRepository.Update(order);
            base.UnitofWork.Save();

            LogErrors.WriteLog("OrderArchiveBussinessLogic/UpdateTrackingFlag Executed");
        }

        public List<string> GetHeaders(List<TemplateModel> templates)
        {
            LogErrors.WriteLog("OrderArchiveBussinessLogic/GetHeaders executing");

            var templateIds = templates.ConvertAll(t => t.Id);
            var dbTemplates = base.UnitofWork
                                .TemplateRepository
                                .Get(t => templateIds.Any(s => s == t.Id), orderBy: null);

            var entities = from tmp in dbTemplates
                           from head in tmp.HeaderTemplateAssociation
                           orderby head.SortOrder //todo: need to test this
                           select head.HeaderMaster.Name;

            LogErrors.WriteLog("OrderArchiveBussinessLogic/GetHeaders Executed");

            return entities.ToList();
        }

        public void Dispose()
        {
            base.UnitofWork.Dispose();
        }
    }
}

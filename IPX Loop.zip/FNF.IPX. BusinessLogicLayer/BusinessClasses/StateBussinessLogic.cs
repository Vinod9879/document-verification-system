﻿using FNF.IPX.DataAccessLayer;
using FNF.IPX.DataEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using FNF.IPX.Common;
using FNF.IPX.Models;
using FNF.IPX.Common.LambdaExtensions;

using FNF.IPX.BusinessLogicLayer.Translators;
using System.Linq.Expressions;


namespace FNF.IPX.BusinessLogicLayer.BusinessClasses
{
    public class StateBussinessLogic : AbstractBL, IDisposable
    {
        public StateBussinessLogic()
        {

        }

        public IEnumerable<StateModel> GetStates()
        {
            //try
            //{
                LogErrors.WriteLog("StateBL/GetStates executing");

                var states = base.UnitofWork
                            .StateRepository
                            .Get(orderBy: null);

                var stateColl = new List<StateModel>();
                foreach (var stateE in states)
                {
                    var stateVm = StateTranslator.StateEntityToModel(stateE);
                    stateColl.Add(stateVm);
                }

                LogErrors.WriteLog("StateBL/GetStates Executed");
                return stateColl;
            //}
            //catch (Exception ex)
            //{
            //    LogErrors.WriteLog("StateBL/GetStates error");

            //    LogErrors.WriteLog(ex);
            //    throw;
            //}

        }

        public StateModel GetStateById(int id)
        {
            //try
            //{
                LogErrors.WriteLog("StateBL/GetStateById executing");

                var state = base.UnitofWork
                            .StateRepository
                            .GetById(id);
                var stateVm = StateTranslator.StateEntityToModel(state);

                LogErrors.WriteLog("StateBL/GetStateById Executed");
                return stateVm;
            //}
            //catch (Exception ex)
            //{
            //    LogErrors.WriteLog("StateBL/GetStateById error");
            //    LogErrors.WriteLog(ex);
            //    throw;
            //}
        }

        public void Dispose()
        {
            base.UnitofWork.Dispose();
        }
    }
}

﻿using FNF.IPX.DataAccessLayer;
using FNF.IPX.DataEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using FNF.IPX.Common;
using FNF.IPX.Models;
using FNF.IPX.Common.LambdaExtensions;

using FNF.IPX.BusinessLogicLayer.Translators;
using System.Linq.Expressions;
using RefactorThis.GraphDiff;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Reflection;

using System.Text.RegularExpressions;

namespace FNF.IPX.BusinessLogicLayer.BusinessClasses
{
    public class OrderBussinessLogic : AbstractBL, IDisposable
    {
        private UserBussinessLogic userBLInstance;

        public UserBussinessLogic UserBLInstance
        {
            get
            {
                if (userBLInstance == null)
                {
                    userBLInstance = new UserBussinessLogic();
                }
                return userBLInstance;
            }
        }

        public OrderBussinessLogic()
        {

        }

        public IEnumerable<OrderDetailsModel> GetOrders()
        {
            //try
            //{
            LogErrors.WriteLog("OrderBussinessLogic/GetOrders executing");

            var orders = base.UnitofWork
                        .OrdersRepository
                        .Get(orderBy: null);

            var orderColl = new List<OrderDetailsModel>();
            foreach (var userE in orders)
            {
                var userVm = OrderTranslator.OrderEntityToModel(userE);
                orderColl.Add(userVm);
            }

            LogErrors.WriteLog("OrderBussinessLogic/GetOrders Executed");
            return orderColl;
            //}
            //catch (Exception ex)
            //{
            //    LogErrors.WriteLog("OrderBussinessLogic/GetOrders error");

            //    LogErrors.WriteLog(ex);
            //    throw;
            //}
        }

        public List<string> GetSearchColumns(int userId)
        {
            LogErrors.WriteLog("OrderBussinessLogic/GetSearchColumns executing");

            var templates = GetTemplatesForUser(userId);
            var columns = GetHeaders(templates);

            LogErrors.WriteLog("OrderBussinessLogic/GetSearchColumns Executed");
            return columns;
        }

        public List<HeaderModel> GetHeadersForSearch(List<int> templateIds)
        {
            LogErrors.WriteLog("OrderBussinessLogic/GetHeadersForSearch executing");


            var entities = from header in base.UnitofWork.Context.HeaderMaster
                           from tmp in header.HeaderTemplateAssociation
                           where templateIds.Any(t => t == tmp.TemplateId)
                           select header;

            List<HeaderModel> results = null;
            if (entities != null)
            {
                results = new List<HeaderModel>();
                foreach (var entity in entities)
                {
                    var result = HeaderTranslator.EntityToModel(entity);
                    results.Add(result);
                }
            }
            LogErrors.WriteLog("OrderBussinessLogic/GetHeadersForSearch Executed");
            return results;
        }

        public OrderDetailsModel GetOrderById(int id)
        {
            //try
            //{
            LogErrors.WriteLog("OrderBussinessLogic/GetOrderById executing");

            var order = base.UnitofWork
                        .OrdersRepository
                        .GetById(id);

            OrderDetailsModel orderVM = OrderTranslator.OrderEntityToModel(order);

            LogErrors.WriteLog("OrderBussinessLogic/GetOrderById Executed");
            return orderVM;
            //}
            //catch (Exception ex)
            //{
            //    LogErrors.WriteLog("OrderBussinessLogic/GetOrderById error");

            //    LogErrors.WriteLog(ex);
            //    throw;
            //}
        }

        public List<OrderHistoryModel> GetOrderHistoryByOrderId(int orderId)
        {
            LogErrors.WriteLog("OrderBussinessLogic/GetOrderHistoryByOrderId executing");

            var orders = base.UnitofWork
                        .OrderHistoryRepository
                        .Get(t => t.OrderId == orderId, orderBy: null);

            var orderHistoryVMColl = OrderHistoryTranslator.OrderEntityListToModelList(orders);

            LogErrors.WriteLog("OrderBussinessLogic/GetOrderHistoryByOrderId Executed");
            return orderHistoryVMColl;
        }

        public OrderMetaModel GetOrdersVMForUser(int userId, OrderMetaModel orderModel)
        {
            LogErrors.WriteLog("OrderBussinessLogic/GetOrdersVMForUser executing");

            orderModel.Templates = GetTemplatesForUser(userId);

            var templateIds = string.Join(",", orderModel.Templates.ConvertAll(t => t.Id));
            //Todo: sort the headers
            orderModel.Headers = GetHeaders(orderModel.Templates);

            orderModel.AllStatuses = GetStatuses();
            orderModel.Flags = GetFollowupFlags();
            orderModel.TrackingFlags = GetTrackingFlags();
            orderModel.Users = UserBLInstance.GetUsers();

            string userFilter = "";
            if (!HttpContext.Current.User.IsInRole(PERMISSION.CanSeeAllOrders ))
            {
                userFilter = string.Format(" [{0}] Like '%{1}%'", OrderMetaModel.Str_IPXSalesRepEmail, HttpContext.Current.User.Identity.GetInfo().Email);
            }
            if (!string.IsNullOrEmpty(userFilter))
            {
                if (string.IsNullOrEmpty(orderModel.Search) || !orderModel.Search.ToLower().Contains(userFilter.ToLower()))
                {
                    orderModel.Search += string.Format((string.IsNullOrEmpty(orderModel.Search) ||
                                                        (string.IsNullOrEmpty(orderModel.Search.Trim()))) ? (" " + userFilter) : (" {0} " + userFilter), " AND ");
                }
            }

            string isDeletedFilter = "([IsDeleted] = 0 OR [IsDeleted] IS NULL)";
            if (string.IsNullOrEmpty(orderModel.Search) || !orderModel.Search.ToLower().Contains(isDeletedFilter.ToLower()))
            {
                orderModel.Search += string.Format((string.IsNullOrEmpty(orderModel.Search) ||
                                                        (string.IsNullOrEmpty(orderModel.Search.Trim()))) ? (" " + isDeletedFilter + " ") : (" {0} " + isDeletedFilter), " AND ");
            }
            orderModel.Search = HttpUtility.HtmlDecode(orderModel.Search);

            // validate where clause

            if (!SqlWhereClauseValidator.ValidateWhereClause(orderModel.Search))
            {
                orderModel.Search = userFilter;
                LogErrors.WriteLog("OrderBussinessLogic/GetOrders Invalid Where Clause from Browser");
                //throw new ArgumentException($"Failed wc validation: --{orderModel.Search}");
            }

            //if (true || orderModel.Search.Contains("[Sales Price]") )
            //{ 
            //    throw new ArgumentException($"Post wc validation: --{orderModel.Search}");
            //}

            FetchOrdersFromSP(orderModel, templateIds);
            orderModel.CheckIndex();

            LogErrors.WriteLog("OrderBussinessLogic/GetOrdersVMForUser Executed");
            return orderModel;
        }

        private void FetchOrdersFromSP(OrderMetaModel orderModel, string templateIds)
        {
            // Validate OrderModel
            if (orderModel.Order.ToLower() != "desc" && orderModel.Order.ToLower() != "asc")
            {
                orderModel.Order = "DESC";
            }

            List<SqlParameter> lparam = new List<SqlParameter>() { new SqlParameter("TemplateIDs", templateIds) };
            lparam.AddRange(new List<SqlParameter>()
            {
                new SqlParameter("Sort", orderModel.Sort),
                new SqlParameter("Order", orderModel.Order),
                new SqlParameter("Search", string.IsNullOrEmpty(orderModel.Search)? DBNull.Value: (dynamic) orderModel.Search
                                                                                                            .Replace(GeneralConstants.AND_Placeholder, "AND")) ,
                new SqlParameter("Pageindex", orderModel.PageIndex),
                new SqlParameter("Pagesize", orderModel.Pagesize)
            });

            orderModel.Results = base.UnitofWork.Context.GetResults(DBConstants.SP_GetOrders, CommandType.StoredProcedure, lparam);
        }

        public List<IDictionary<string, dynamic>> GetOrdersFromSPForDownload(string templateIds, string searchCriteria)
        {
            LogErrors.WriteLog("OrderBussinessLogic/GetOrdersFromSPForDownload executing");

            //var templates = GetTemplatesForUser(userID);
            //var templateIds = string.Join(",", templates.ConvertAll(t => t.Id));

            string userFilter = "";
            if (!HttpContext.Current.User.IsInRole(PERMISSION.CanSeeAllOrders))
            {
                //userFilter = string.Format(" [Sales Rep Email] Like '%{0}%'", HttpContext.Current.User.Identity.GetInfo().Email);
                userFilter = string.Format(" [{0}] Like '%{1}%'", OrderMetaModel.Str_IPXSalesRepEmail, HttpContext.Current.User.Identity.GetInfo().Email);
            }
            if (!string.IsNullOrEmpty(userFilter))
            {
                if (string.IsNullOrEmpty(searchCriteria) || !searchCriteria.ToLower().Contains(userFilter.ToLower()))
                {
                    searchCriteria += string.Format((string.IsNullOrEmpty(searchCriteria) ||
                                                        (string.IsNullOrEmpty(searchCriteria.Trim()))) ? (" " + userFilter) : (" {0} " + userFilter), " AND ");
                }
            }

            string isDeletedFilter = "([IsDeleted] = 0 OR [IsDeleted] IS NULL)";
            if (string.IsNullOrEmpty(searchCriteria) || !searchCriteria.ToLower().Contains(isDeletedFilter.ToLower()))
            {
                searchCriteria += string.Format((string.IsNullOrEmpty(searchCriteria) ||
                                                        (string.IsNullOrEmpty(searchCriteria.Trim()))) ? (" " + isDeletedFilter + " ") : (" {0} " + isDeletedFilter), " AND ");
            }

            List<SqlParameter> lparam = new List<SqlParameter>() { new SqlParameter("TemplateIDs", templateIds) };
            lparam.AddRange(new List<SqlParameter>()
            {
                new SqlParameter("Search", string.IsNullOrEmpty(searchCriteria)? DBNull.Value: (dynamic) searchCriteria)
            });

            var results = base.UnitofWork.Context.GetResults(DBConstants.SP_GetOrderDetailsForDownload, CommandType.StoredProcedure, lparam);
            LogErrors.WriteLog("OrderBussinessLogic/GetOrdersFromSPForDownload Executed");

            return results;
        }

        public List<TemplateModel> GetTemplatesForUser(int userId)
        {
            //try
            //{
            LogErrors.WriteLog("OrderBussinessLogic/GetTemplatesForUser executing");

            var user = base.UnitofWork
                        .UserRepository
                        .GetById(userId);

            var entities = from grp in user.GroupMaster
                           from tmp in grp.Template
                           select tmp;

            var models = new List<TemplateModel>();
            foreach (var entity in entities)
            {
                var model = TemplateTranslator.EntityToModel(entity);
                models.Add(model);
            }

            LogErrors.WriteLog("OrderBussinessLogic/GetTemplatesForUser Executed");
            return models;
            //}
            //catch (Exception ex)
            //{
            //    LogErrors.WriteLog("OrderBussinessLogic/GetTemplatesForUser error");

            //    LogErrors.WriteLog(ex);
            //    throw;
            //}

        }

        public List<string> GetHeaders(List<TemplateModel> templates)
        {
            LogErrors.WriteLog("OrderBussinessLogic/GetHeaders executing");

            var templateIds = templates.ConvertAll(t => t.Id);
            var dbTemplates = base.UnitofWork
                                .TemplateRepository
                                .Get(t => templateIds.Any(s => s == t.Id), orderBy: null);

            var entities = from tmp in dbTemplates
                           from head in tmp.HeaderTemplateAssociation
                           orderby head.SortOrder //todo: need to test this
                           select head.HeaderMaster.Name;

            LogErrors.WriteLog("OrderBussinessLogic/GetHeaders Executed");

            return entities.ToList();
        }

        private List<OrderStatusModel> GetStatuses()
        {
            LogErrors.WriteLog("OrderBussinessLogic/GetStatuses executing");

            //var entities = base.UnitofWork.Context
            //                    .OrderDetails
            //                    .Select(t => t.OrderStatus)
            //                    .Distinct();

            var entities = base.UnitofWork
                                .OrderStatusRepository
                                .Get(orderBy: t => t.OrderBy(s => s.Priority));

            var modelColl = new List<OrderStatusModel>();
            foreach (var status in entities)
            {
                var model = OrderStatusTranslator.OrderStatusEntityToModel(status);
                modelColl.Add(model);
            }

            LogErrors.WriteLog("OrderBussinessLogic/GetStatuses Executed");

            return modelColl;
        }

        private List<FollowUpFlagsModel> GetFollowupFlags()
        {
            LogErrors.WriteLog("OrderBussinessLogic/GetFollowupFlags executing");

            //var entities = base.UnitofWork.Context
            //                    .OrderDetails
            //                    .Select(t => t.OrderStatus)
            //                    .Distinct();

            var entities = base.UnitofWork
                                .FollowUpFlagsMasterRepository
                                .Get(orderBy: t => t.OrderBy(s => s.Priority));

            var modelColl = new List<FollowUpFlagsModel>();
            foreach (var status in entities)
            {
                var model = FollowupFlagsTranslator.OrderFollowupFlagsEntityToModel(status);
                modelColl.Add(model);
            }

            LogErrors.WriteLog("OrderBussinessLogic/GetFollowupFlags Executed");

            return modelColl;
        }

        private List<TrackFlagsMasterModel> GetTrackingFlags()
        {
            LogErrors.WriteLog("OrderBussinessLogic/GetTrackingFlags executing");

            var entities = base.UnitofWork
                                .TrackFlagsMasterRepository
                                .Get(orderBy: t => t.OrderBy(s => s.Priority));

            var modelColl = new List<TrackFlagsMasterModel>();
            foreach (var entity in entities)
            {
                var model = new TrackFlagsMasterModel();
                model.Id = entity.Id;
                model.Name = entity.Name;
                model.Priority = entity.Priority;
                modelColl.Add(model);
            }

            LogErrors.WriteLog("OrderBussinessLogic/GetTrackingFlags Executed");

            return modelColl;
        }

        public void UpdateTrackingFlag(int orderId, string status)
        {
            LogErrors.WriteLog("OrderBussinessLogic/UpdateTrackingFlag executing");

            var order = UnitofWork.OrdersRepository.DbSet.AsNoTracking().FirstOrDefault(t => t.OrderID == orderId);

            order.TrackFlag = status;
            order.UpdatedDate = DateTime.Now;
            order.ModifiedBy = HttpContext.Current.User.Identity.GetInfo().FullName;

            UnitofWork.OrdersRepository.Update(order);
            base.UnitofWork.Save();

            LogErrors.WriteLog("OrderBussinessLogic/UpdateTrackingFlag Executed");
        }

        public void SaveOrder(OrderMetaModel orderVM)
        {
            //try
            //{
            LogErrors.WriteLog("OrderBussinessLogic/SaveOrder executing");

            bool insert = (orderVM.OrderDetails.OrderID == 0);
            var dbOrder = (insert) ?
                            OrderTranslator.OrderModelToEntity(orderVM.OrderDetails)
                            : UnitofWork.OrdersRepository.GetById(orderVM.OrderDetails.OrderID);
            if (!insert)
            {
                Type type = typeof(OrderDetails);
                foreach (PropertyInfo pi in type.GetProperties())
                {
                    dynamic val = pi.GetValue(orderVM);
                    if (val != null)
                        pi.SetValue(dbOrder, val);
                }
            }

            if (insert)
            {
                UnitofWork.OrdersRepository.Insert(dbOrder);
            }
            else
            {
                UnitofWork.OrdersRepository.Update(dbOrder);
            }

            LogErrors.WriteLog("OrderBussinessLogic/SaveOrder Executed");
            //}
            //catch (Exception ex)
            //{
            //    LogErrors.WriteLog("OrderBussinessLogic/SaveOrder error");

            //    LogErrors.WriteLog(ex);
            //    throw;
            //}

        }

        public void UpdateOrderAssignment(List<int> orderIds, string emailID, string name, int userId)
        {
            //try
            //{
            LogErrors.WriteLog("OrderBussinessLogic/UpdateOrderAssignment executing");

            //var user = UnitofWork.UserRepository.Get(filter: t => t.EmailId == emailID, orderBy: null).SingleOrDefault();
            //var userVM = UserTranslator.UserEntityToModel(user);

            //UnitofWork.OrdersRepository.DbSet.AsNoTracking();
            var orders = UnitofWork.OrdersRepository
                        .Get(filter: t => orderIds.Contains(t.OrderID),
                             orderBy: null)
                        .ToList();

            foreach (var order in orders)
            {
                //Delete old sales reps and then add the selected user
                var salesReps = order.IPXSalesRep.ToList();
                foreach (var salesRep in salesReps)
                {
                    UnitofWork.IPXSalesRepRepository
                                .Delete(salesRep.Id);
                }
                order.IPXSalesRep.Add(new IPXSalesRep
                {
                    OrderId = order.OrderID,
                    EmailAddress = emailID,
                    SalesRepName = name,
                    UserId = userId
                });
                order.UpdatedDate = DateTime.Now;

                UnitofWork.OrdersRepository.Update(order);
            }
            UnitofWork.Save();

            LogErrors.WriteLog("OrderBussinessLogic/UpdateOrderAssignment Executed");
            //}
            //catch (Exception ex)
            //{
            //    LogErrors.WriteLog("OrderBussinessLogic/UpdateOrderAssignment error");

            //    LogErrors.WriteLog(ex);
            //    throw;
            //}

        }

        public void UpdateStatusOrFollowUp(int orderId, string status, string comments, bool isFollowUpUpdate = false)
        {
            //try
            //{
            LogErrors.WriteLog("OrderBussinessLogic/UpdateStatusOrFollowUp executing");

            var order = UnitofWork.OrdersRepository.DbSet.AsNoTracking().FirstOrDefault(t => t.OrderID == orderId);

            //Update comments only if entered by user, else ignore
            if (comments != null && !string.IsNullOrEmpty(comments.Trim()))
            {
                order.Comments = HttpUtility.HtmlEncode(comments);
            }
            order.UpdatedDate = DateTime.Now;
            order.ModifiedBy = HttpContext.Current.User.Identity.GetInfo().FullName;
            if (isFollowUpUpdate)
            {
                order.FollowupFlag = status;
                UnitofWork.OrdersRepository.Update(order);
            }
            else
            {
                order.OrderStatus = status;

                var OrderHistory = new OrderHistory();
                OrderHistory.OrderId = orderId;
                OrderHistory.Status = status;
                OrderHistory.Comments = HttpUtility.HtmlEncode(comments);
                OrderHistory.CreatedBy = HttpContext.Current.User.Identity.GetInfo().FullName;
                OrderHistory.CreatedDate = DateTime.Now;
                order.OrderHistory.Add(OrderHistory);
                UnitofWork.Context.UpdateGraph<OrderDetails>(order, t => t.AssociatedCollection(s => s.OrderHistory));
            }
            base.UnitofWork.Save();

            LogErrors.WriteLog("OrderBussinessLogic/UpdateStatusOrFollowUp Executed");
            //}
            //catch (Exception ex)
            //{
            //    LogErrors.WriteLog("OrderBussinessLogic/UpdateStatusOrFollowUp error");

            //    LogErrors.WriteLog(ex);
            //    throw;
            //}
        }

        public void UpdateDeleteFlag(int orderId, string comments)
        {
            //try
            //{
            LogErrors.WriteLog("OrderBussinessLogic/UpdateDeleteFlag executing");

            var order = UnitofWork.OrdersRepository.DbSet.AsNoTracking().FirstOrDefault(t => t.OrderID == orderId);

            order.IsDeleted = true;
            order.Comments = HttpUtility.HtmlEncode(comments);
            order.UpdatedDate = DateTime.Now;
            order.ModifiedBy = HttpContext.Current.User.Identity.GetInfo().FullName;

            var OrderHistory = new OrderHistory();
            OrderHistory.OrderId = orderId;
            OrderHistory.Status = "Deleted";
            OrderHistory.Comments = HttpUtility.HtmlEncode(comments);
            OrderHistory.CreatedBy = HttpContext.Current.User.Identity.GetInfo().FullName;
            OrderHistory.CreatedDate = DateTime.Now;
            order.OrderHistory.Add(OrderHistory);
            base.UnitofWork.Context.UpdateGraph<OrderDetails>(order, t => t.AssociatedCollection(s => s.OrderHistory));
            base.UnitofWork.Save();
            LogErrors.WriteLog("OrderBussinessLogic/UpdateDeleteFlag Executed");
            //}
            //catch (Exception ex)
            //{
            //    LogErrors.WriteLog("OrderBussinessLogic/UpdateDeleteFlag error");

            //    LogErrors.WriteLog(ex);
            //    throw;
            //}

        }

        public void Dispose()
        {
            base.UnitofWork.Dispose();
        }
    }

    public class SqlWhereClauseValidator
    {
        // Allowed SQL keywords and operators
        private static readonly HashSet<string> AllowedKeywords = new HashSet<string>
    {
        "AND", "OR", "NOT", "=", "<", ">", "<=", ">=", "LIKE", "IN", "BETWEEN", "IS NULL", "IS NOT NULL"
    };

        // Whitelisted column names (case-sensitive)
        private static readonly HashSet<string> AllowedColumns = new HashSet<string>
    {
        "Name", "Age", "Email", "[User Name]", "[Order Status]", "[Date of Birth]", "[IsDeleted]"
    };

        // Regex patterns for valid values
        private static readonly Regex NumberRegex = new Regex(@"^\d+(\.\d+)?$");   // Matches integers and floats
        private static readonly Regex StringRegex = new Regex(@"^'.*'$");          // Matches strings in single quotes
        private static readonly Regex BracketedColumnRegex = new Regex(@"^\[.*\]$"); // Matches columns like [Column Name]

        public static bool ValidateWhereClause(string whereClause)
        {

            if (string.IsNullOrWhiteSpace(whereClause))
                throw new ArgumentException("WHERE clause cannot be null or empty.");

            whereClause = whereClause.Trim();
            while (whereClause.Contains("  ")) whereClause = whereClause.Replace("  ", " ");

            // Basic length check
            if (whereClause.Length > 500)
                throw new ArgumentException("WHERE clause is too long.");

            // Check for balanced parentheses and square brackets
            if (!AreParenthesesBalanced(whereClause))
                throw new ArgumentException("Unbalanced parentheses in WHERE clause.");
            if (!AreSquareBracketsBalanced(whereClause))
                throw new ArgumentException("Unbalanced square brackets in WHERE clause.");

            string TempClause = whereClause;

            TempClause = TempClause.Replace("([Order Status] like '%Open%')", "");
            TempClause = TempClause.Replace("([IsDeleted] = 0 OR [IsDeleted] IS NULL)", "");
            TempClause = TempClause.Replace("[Sales Price] > 300000", "");

            TempClause = TempClause.Replace(" AND ", "");
            TempClause = TempClause.Trim();

            if (TempClause.Contains("[IPXSalesRepEmail] Like '") && TempClause.Substring(TempClause.Length - 1) == "'")
            {
                TempClause = TempClause.Replace("[IPXSalesRepEmail] Like '", "");
                TempClause = TempClause.Substring(0, TempClause.Length - 1);

                // Validate the remaining TempClause for only alpha + @
                TempClause = TempClause.Replace("@", "");
                TempClause = TempClause.Replace(".", "");
                TempClause = TempClause.Replace("_", "");
                TempClause = TempClause.Replace("-", "");
                TempClause = TempClause.Replace("%", "");
                if (TempClause.All( c => char.IsLetterOrDigit(c) ))
                {
                    TempClause = "";
                }
            }

            //TempClause = TempClause.Replace("[Flash Code] = '123'", "");

            TempClause = TempClause.Trim();

            if (TempClause != "")
            { 
                throw new ArgumentException($"Invalid WHERE clause: --{whereClause}--{TempClause}--");
            }

            return true;
        }

        private static bool AreParenthesesBalanced(string input)
        {
            int balance = 0;
            foreach (char c in input)
            {
                if (c == '(') balance++;
                if (c == ')') balance--;
                if (balance < 0) return false;
            }
            return balance == 0;
        }

        private static bool AreSquareBracketsBalanced(string input)
        {
            int balance = 0;
            foreach (char c in input)
            {
                if (c == '[') balance++;
                if (c == ']') balance--;
                if (balance < 0) return false;
            }
            return balance == 0;
        }
    }




}

﻿using FNF.IPX.Common;
using FNF.IPX.DataAccessLayer;
using FNF.IPX.DataEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FNF.IPX.BusinessLogicLayer.BusinessClasses
{
    public static class CommonStaticClass
    {
        private static Dictionary<string, string> _headerDetails = null;
        private static object syncRoot = new Object();

        private static string _openOrdersFilter_prefix = "[Order Status] like ";
        //private static string _openOrdersFilter_AND_prefix = "AND [Order Status] like ";

        private static string showOpenOrdersFilter = null;
        private static string showOpenOrdersFilter_AND = null;

        public static Dictionary<string, string> HeaderDetails
        {
            get
            {
                if (_headerDetails == null)
                {
                    lock (syncRoot)
                    {
                        using (HeaderBussinessLogic oBL = new HeaderBussinessLogic())
                        {
                            var results = oBL.GetAll();
                            if (results != null && results.Count > 0)
                            {
                                _headerDetails = new Dictionary<string, string>();
                                foreach (var item in results)
                                {
                                    _headerDetails.Add(item.Name, item.Datatype);
                                }
                            }
                        }
                    }
                }
                return _headerDetails;
            }
        }

        public static dynamic GetFormattedData(string key, dynamic info)
        {
            if (key != null && !string.IsNullOrEmpty(key.Trim()) && info != null)
            {
                if (HeaderDetails.ContainsKey(key))
                {
                    if (HeaderDetails[key] == DBConstants.HeaderDataType_Currency)
                    {
                        string sInfo = Convert.ToString(info);
                        if (sInfo != null && !string.IsNullOrEmpty(sInfo.Trim()))
                        {
                            double finfo;
                            if (double.TryParse(sInfo, out finfo))
                            {
                                return finfo.ToString("c");
                            }
                        }
                        else
                        {
                            return (0).ToString("c");
                        }
                    }
                    else if (HeaderDetails[key] == DBConstants.HeaderDataType_DateTime)
                    {
                        string sInfo = Convert.ToString(info);
                        if (sInfo != null && !string.IsNullOrEmpty(sInfo.Trim()))
                        {
                            DateTime dinfo;
                            if (DateTime.TryParse(sInfo, out dinfo))
                            {
                                return dinfo.ToString(GeneralConstants.DateFormat_Longer);
                            }
                        }
                    }
                    //Truncate trailing comma in certain columns like Sales Rep
                    else if(DBConstants.HeaderFieldWithCommas.Contains(key))
                    {
                        string sInfo = Convert.ToString(info);
                        if (sInfo != null && !string.IsNullOrEmpty(sInfo.Trim()))
                        {
                            return sInfo.TrimEnd(',');
                        }
                    }
                }
            }
            return info;
        }

        public static string ShowOpenOrdersFilter
        {
            get
            {
                if (showOpenOrdersFilter == null || string.IsNullOrEmpty(showOpenOrdersFilter.Trim()))
                {
                    using (UnitofWork unit = new UnitofWork(new IPXEntities()))
                    {
                        var statuses = unit
                                        .OrderStatusRepository
                                        .Get(orderBy: t => t.OrderBy(s => s.Priority));

                        if (statuses != null && statuses.Count > 0)
                        {
                            var openOrdersString = GetOpenOrdersString(_openOrdersFilter_prefix, statuses);
                            showOpenOrdersFilter = openOrdersString;
                        }
                    }
                }

                return showOpenOrdersFilter;
            }
        }

        public static string ShowOpenOrdersFilter_AND
        {
            get
            {
                if (showOpenOrdersFilter_AND == null || string.IsNullOrEmpty(showOpenOrdersFilter_AND.Trim()))
                {
                    using (UnitofWork unit = new UnitofWork(new IPXEntities()))
                    {
                        var statuses = unit
                                        .OrderStatusRepository
                                        .Get(orderBy: t => t.OrderBy(s => s.Priority));

                        if (statuses != null && statuses.Count > 0)
                        {
                            var openOrdersString = GetOpenOrdersString(_openOrdersFilter_prefix, statuses);
                            showOpenOrdersFilter_AND = "AND " + openOrdersString;
                        }
                    }
                }

                return showOpenOrdersFilter_AND;
            }
        }

        private static string GetOpenOrdersString(string filterPrefix, List<OrderStatus> statuses)
        {
            string result = "("; ;
            var filteredStatuses = statuses.Where(t => t.IsOpenStatus.Value).ToList();
            if (filteredStatuses != null)
            {
                for (int i = 0; i < filteredStatuses.Count; i++)
                {
                    if(i != 0)
                    {
                        result += " OR ";
                    }
                    result += filterPrefix + "'%" + filteredStatuses[i].Status + "%'";
                }
            }
            result += ")";

            return result;
        }
    }
}

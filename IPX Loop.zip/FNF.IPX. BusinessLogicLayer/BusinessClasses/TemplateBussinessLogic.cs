﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using FNF.IPX.BusinessLogicLayer.Translators;
using System.Linq.Expressions;
using RefactorThis.GraphDiff;
using FNF.IPX.DataEntities;
using FNF.IPX.Common;
using FNF.IPX.Models;
using FNF.IPX.DataAccessLayer;



namespace FNF.IPX.BusinessLogicLayer.BusinessClasses
{
    //public class TemplateBussinessLogic<enity,model> : AbstractBL, IDisposable where enity : Template 
    //                                                               where model :  TemplateModel
    public class TemplateBussinessLogic : AbstractBL, IDisposable
    {


        public TemplateBussinessLogic()
        { }




        public IEnumerable<TemplateModel> GetAllPagedItems(IDictionary<string, string> FilterColumnNameValue, IDictionary<string, string> SortColumns, int PageNumber, int PageSize)
        {

            LogErrors.WriteLog("TemplateBussinessLogic/GetAllPagedItems executing");


           TemplateFilterTranslator filterTranslator = new TemplateFilterTranslator(FilterColumnNameValue, SortColumns);



            var entities = base.UnitofWork
                        .TemplateRepository
                        .GetAllPagedItems(filterTranslator.Filters, SortColumns, PageNumber, PageSize);

            var models = new List<TemplateModel>();



            foreach (var entity in entities)
            {
                var model = TemplateTranslator.EntityToModel(entity);
                model.PageNumber = entities.PageNumber;
                model.PageCount = entities.PageCount;
                model.TotalItemCount = entities.TotalItemCount;
                model.PageSize = entities.PageSize;

                models.Add(model);
            }


            LogErrors.WriteLog("TemplateBussinessLogic/GetAllPagedItems Executed");
            return models.ToList();


        }

        public IEnumerable<TemplateModel> GetAll()
        {


            LogErrors.WriteLog("TemplateBussinessLogic/GetAll executing");

            var entities = base.UnitofWork
                        .TemplateRepository
                        .Get(orderBy: null);

            var models = new List<TemplateModel>();


            foreach (var entity in entities)
            {
                var model = TemplateTranslator.EntityToModel(entity);
                models.Add(model);
            }

            LogErrors.WriteLog("TemplateBussinessLogic/GetAll Executed");
            return models;


        }


        public TemplateModel GetByName(string  Name)
        {

            LogErrors.WriteLog("TemplateBussinessLogic/GetByName executing");

            var entity = base.UnitofWork
                        .TemplateRepository
                        .Get(x=>x.Name==Name).FirstOrDefault();

            var model = TemplateTranslator.EntityToModel(entity);

            LogErrors.WriteLog("TemplateBussinessLogic/GetByName Executed");
            return model;

        }



        public TemplateModel GetById(int id)
        {

            LogErrors.WriteLog("TemplateBussinessLogic/GetById executing");

            var entity = base.UnitofWork
                        .TemplateRepository
                        .GetById(id);
            var model = TemplateTranslator.EntityToModel(entity);

            LogErrors.WriteLog("TemplateBussinessLogic/GetById Executed");
            return model;

        }

        public void Save(TemplateModel model)
        {

            LogErrors.WriteLog("TemplateBussinessLogic/Save executing");

            var entity = TemplateTranslator.ModelToEntity(model);
            // base.UnitofWork.Context.UpdateGraph<Template>(entity, m => m.AssociatedCollection(u => u.HeaderTemplateAssociation));




            base.UnitofWork
                        .TemplateRepository
                        .Insert(entity);

            base.UnitofWork.Save();

            //entity.HeaderTemplateAssociation
            //base.UnitofWork
            //       .HeaderTemplateAssociationRepository
            //       .Insert(entity.HeaderTemplateAssociation);


            //base.UnitofWork.Save();


            LogErrors.WriteLog("TemplateBussinessLogic/Save Executed");

        }

        public void Update(TemplateModel model)
        {
            LogErrors.WriteLog("TemplateBussinessLogic/Update executing");

            var entity = TemplateTranslator.ModelToEntity(model);


            // base.UnitofWork.Context.UpdateGraph<Template>(entity, m => m.AssociatedCollection(u => u.HeaderTemplateAssociation));

            var headerTemplateAssociationEntity = Helpers.Clone(entity.HeaderTemplateAssociation);


            entity.HeaderTemplateAssociation.Clear();
            //update Template Infomration
            base.UnitofWork
                        .TemplateRepository
                        .Update(entity);


            //truncate Exisitng associations assocatd 



            var currentHeaderTemplateAssociation = base.UnitofWork.HeaderTemplateAssociationRepository.Get(x => x.TemplateId == entity.Id);

            base.UnitofWork
                   .HeaderTemplateAssociationRepository
                   .Delete(currentHeaderTemplateAssociation);

            //Insert New set of associatoins
            base.UnitofWork
                  .HeaderTemplateAssociationRepository
                  .Insert(headerTemplateAssociationEntity);


            base.UnitofWork.Save();

            LogErrors.WriteLog("TemplateBussinessLogic/Update Executed");

        }

        public void Delete(int Id)
        {
            LogErrors.WriteLog("TemplateBussinessLogic/Delete executing");

            var entity = base.UnitofWork
                        .TemplateRepository
                        .GetById(Id);

            //Clear group associations
            entity.HeaderTemplateAssociation.Clear();

            var currentHeaderTemplateAssociation = base.UnitofWork.HeaderTemplateAssociationRepository.Get(x => x.TemplateId == entity.Id);

            base.UnitofWork
                   .HeaderTemplateAssociationRepository
                   .Delete(currentHeaderTemplateAssociation);

            //Finally, remove user
            base.UnitofWork
                        .TemplateRepository
                        .Delete(Id);
            base.UnitofWork.Save();

            LogErrors.WriteLog("TemplateBussinessLogic/Delete Executed");

        }

        public void ToUI(TemplateModel model)
        {
            LogErrors.WriteLog("TemplateBussinessLogic/ToUI Executing");
            if (model == null) return;
            model.SelectedHeaders = model.DefaultHeaders.OrderBy(x=>x.Sorder).ToList().ConvertAll(t => t.Id);

            LogErrors.WriteLog("TemplateBussinessLogic/ToUI Executed");
        }

        public void FromUI(TemplateModel model, Func<int, HeaderModel> delegatedMethode)
        {
            LogErrors.WriteLog("TemplateBussinessLogic/FromUI Executing");
            model.DefaultHeaders = model.SelectedHeaders.ConvertAll(g => delegatedMethode(g));
            LogErrors.WriteLog("TemplateBussinessLogic/FromUI Executed");
        }


        public void Dispose()
        {
            base.UnitofWork.Dispose();
        }

    }
}

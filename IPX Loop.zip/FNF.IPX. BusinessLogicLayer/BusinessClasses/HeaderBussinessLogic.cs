﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using FNF.IPX.BusinessLogicLayer.Translators;
using System.Linq.Expressions;
using RefactorThis.GraphDiff;
using FNF.IPX.DataEntities;
using FNF.IPX.Common;
using FNF.IPX.Models;
using FNF.IPX.DataAccessLayer;



namespace FNF.IPX.BusinessLogicLayer.BusinessClasses
{
    //public class TemplateBussinessLogic<enity,model> : AbstractBL, IDisposable where enity : Template 
    //                                                               where model :  TemplateModel
    public class HeaderBussinessLogic : AbstractBL, IDisposable
    {


        public HeaderBussinessLogic()
        { }


        public List<HeaderModel> GetAll()
        {

            LogErrors.WriteLog("HeaderBussinessLogic/GetAll executing");

            var entities = base.UnitofWork
                        .HeaderRepository
                        .Get(orderBy: null);

            var models = new List<HeaderModel>();


            foreach (var entity in entities)
            {
                var model = HeaderTranslator.EntityToModel(entity);
                models.Add(model);
            }

            LogErrors.WriteLog("HeaderBussinessLogic/GetAll Executed");
            return models;


        }






        public HeaderModel GetById(int id)
        {

            LogErrors.WriteLog("HeaderBussinessLogic/GetById executing");

            var entity = base.UnitofWork
                        .HeaderRepository
                        .GetById(id);
            var model = HeaderTranslator.EntityToModel(entity);

            LogErrors.WriteLog("HeaderBussinessLogic/GetById Executed");
            return model;

        }



        public void Dispose()
        {
            base.UnitofWork.Dispose();
        }

    }
}

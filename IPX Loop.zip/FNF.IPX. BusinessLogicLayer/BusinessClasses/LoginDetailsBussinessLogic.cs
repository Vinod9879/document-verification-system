﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using FNF.IPX.BusinessLogicLayer.Translators;
using System.Linq.Expressions;
using RefactorThis.GraphDiff;
using FNF.IPX.DataEntities;
using FNF.IPX.Common;
using FNF.IPX.Models;
using FNF.IPX.DataAccessLayer;
using PagedList;


namespace FNF.IPX.BusinessLogicLayer.BusinessClasses
{
    public class LoginDetailsBussinessLogic : AbstractBL, IDisposable
    {
        public LoginDetailsBussinessLogic()
        { }

        public IEnumerable<UserLoginDetailsModel> GetAllPagedItems(IDictionary<string, string> FilterColumnNameValue, IDictionary<string, string> SortColumns, int PageNumber, int PageSize)
        {

            LogErrors.WriteLog("LoginDetailsBussinessLogic/GetAllPagedItems executing");

            UserLoginDetailsFilterTranslator filterTranslator = new UserLoginDetailsFilterTranslator(FilterColumnNameValue, SortColumns);

            var entities = base.UnitofWork
                        .UserLoginDetailsRepository
                        .GetAllPagedItems(filterTranslator.Filters, SortColumns, PageNumber, PageSize);

            var models = new List<UserLoginDetailsModel>();

            foreach (var entity in entities)
            {
                var model = UserLoginDetailsTranslator.UserLoginDetailsEntityToModel(entity);
                model.PageNumber = entities.PageNumber;
                model.PageCount = entities.PageCount;
                model.TotalItemCount = entities.TotalItemCount;
                model.PageSize = entities.PageSize;

                models.Add(model);
            }

            LogErrors.WriteLog("LoginDetailsBussinessLogic/GetAllPagedItems Executed");
            return models.ToList();
        }

        public IEnumerable<UserLoginDetailsModel> GetAll()
        {
            LogErrors.WriteLog("LoginDetailsBussinessLogic/GetAll executing");

            var entities = base.UnitofWork
                        .UserLoginDetailsRepository
                        .Get(orderBy: null);

            var models = new List<UserLoginDetailsModel>();

            foreach (var entity in entities)
            {
                var model = UserLoginDetailsTranslator.UserLoginDetailsEntityToModel(entity);
                models.Add(model);
            }

            LogErrors.WriteLog("LoginDetailsBussinessLogic/GetAll Executed");
            return models;
        }

        public UserLoginDetailsModel GetByUserName(string userName)
        {
            LogErrors.WriteLog("LoginDetailsBussinessLogic/GetByName executing");

            var entity = base.UnitofWork
                        .UserLoginDetailsRepository
                        .Get(x => x.Username == userName).FirstOrDefault();
            var model = UserLoginDetailsTranslator.UserLoginDetailsEntityToModel(entity);

            LogErrors.WriteLog("LoginDetailsBussinessLogic/GetByName Executed");
            return model;
        }

        public int Save(UserLoginDetailsModel model)
        {
            LogErrors.WriteLog("LoginDetailsBussinessLogic/Save executing");

            var entity = UserLoginDetailsTranslator.UserLoginDetailsModelToEntity(model);

            entity = base.UnitofWork
                        .UserLoginDetailsRepository
                        .Insert(entity);

            base.UnitofWork.Save();

            LogErrors.WriteLog("LoginDetailsBussinessLogic/Save Executed");
            return entity.Id;
        }

        public void Update(UserLoginDetailsModel model)
        {
            LogErrors.WriteLog("LoginDetailsBussinessLogic/Update executing");

            var entity = UserLoginDetailsTranslator.UserLoginDetailsModelToEntity(model);

            base.UnitofWork
                        .UserLoginDetailsRepository
                        .Update(entity);
            base.UnitofWork.Save();

            LogErrors.WriteLog("LoginDetailsBussinessLogic/Update  Executed");
        }

        public void Update(UserLoginDetails entity)
        {
            LogErrors.WriteLog("LoginDetailsBussinessLogic/Update (entity) executing");

            base.UnitofWork
                        .UserLoginDetailsRepository
                        .Update(entity);
            base.UnitofWork.Save();

            LogErrors.WriteLog("LoginDetailsBussinessLogic/Update (entity) Executed");
        }

        public void UpdateByLoginId(int loginId)
        {
            LogErrors.WriteLog("LoginDetailsBussinessLogic/UpdateByLoginId executing");

            var entity = base.UnitofWork
                        .UserLoginDetailsRepository
                        .Get(x => x.Id == loginId).FirstOrDefault();
            entity.LogoutTime = DateTime.Now;
            entity.Duration = Convert.ToInt32(((TimeSpan)(entity.LogoutTime - entity.LoginTime)).TotalMinutes) + " Minute(s)";
            Update(entity);

            LogErrors.WriteLog("LoginDetailsBussinessLogic/UpdateByLoginId  Executed");
        }

        public void Dispose()
        {
            base.UnitofWork.Dispose();
        }
    }
}

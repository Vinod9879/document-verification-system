﻿using FNF.IPX.DataAccessLayer;
using FNF.IPX.DataEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using FNF.IPX.Common;
using FNF.IPX.Models;
using FNF.IPX.Common.LambdaExtensions;

using FNF.IPX.BusinessLogicLayer.Translators;
using System.Linq.Expressions;
using RefactorThis.GraphDiff;

namespace FNF.IPX.BusinessLogicLayer.BusinessClasses
{
    public class UserBussinessLogic : AbstractBL, IDisposable
    {
        public UserBussinessLogic()
        {

        }

        //public IEnumerable<UserModel> Get(Expression<Func<IUser, bool>> filter = null,
        //                                        Func<IQueryable<IUser>, IOrderedQueryable<IUser>> orderBy = null,
        //                                        string includeProperties = null)
        //{
        //    try
        //    {
        //        LogErrors.WriteLog("UserBL/Get executing");

        //        var users = UnitofWork.UserRepository
        //                             .Get(filter, orderBy, includeProperties);

        //        var userColl = new List<UserModel>();
        //        foreach (var userE in users)
        //        {
        //            var userVm = UserTranslator.UserEntityToModel((User)userE);
        //            userColl.Add(userVm);
        //        }

        //        LogErrors.WriteLog("UserBL/GetUserDetails Executed");
        //        return userColl;
        //    }
        //    catch (Exception ex)
        //    {
        //        LogErrors.WriteLog("UserBL/Get error");

        //        LogErrors.WriteLog(ex);
        //        throw;
        //    }

        //}


        public IEnumerable<UserModel> GetAllPagedItems(IDictionary<string, string> FilterColumnNameValue, IDictionary<string, string> SortColumns, int PageNumber, int PageSize)
        {

            LogErrors.WriteLog("UserBussinessLogic/GetAllPagedItems executing");


            var filterTranslator = new UserFilterTranslator(FilterColumnNameValue, SortColumns);



            var entities = base.UnitofWork
                        .UserRepository
                        .GetAllPagedItems(filterTranslator.Filters, SortColumns, PageNumber, PageSize);

            var models = new List<UserModel>();



            foreach (var entity in entities)
            {
                var model = UserTranslator.UserEntityToModel(entity);
                model.PageNumber = entities.PageNumber;
                model.PageCount = entities.PageCount;
                model.TotalItemCount = entities.TotalItemCount;
                model.PageSize = entities.PageSize;

                models.Add(model);
            }

            LogErrors.WriteLog("UserBussinessLogic/GetAllPagedItems Executed");
            return models.ToList();


        }

        public IEnumerable<UserModel> GetUsers()
        {

            LogErrors.WriteLog("UserBussinessLogic/GetUsers executing");

            var users = base.UnitofWork
                        .UserRepository
                        .Get(orderBy: null);

            var userColl = new List<UserModel>();
            foreach (var userE in users)
            {
                var userVm = UserTranslator.UserEntityToModel(userE);
                userColl.Add(userVm);
            }

            LogErrors.WriteLog("UserBussinessLogic/GetUsers Executed");
            return userColl;


        }

        public UserModel GetUserByUserName(string UserName)
        {

            LogErrors.WriteLog("UserBussinessLogic/GetUserByEmailId executing");


            // UnitofWork.UserRepository.DbSet.AsNoTracking().FirstOrDefault

            var user = base.UnitofWork
                        .UserRepository
                        .Get(x => x.UserName == UserName);

            UserModel userVm = null;
            if (user != null)
                userVm = UserTranslator.UserEntityToModel(user.FirstOrDefault());

            LogErrors.WriteLog("UserBussinessLogic/GetUserByEmailId Executed");
            return userVm;

        }


        public UserModel GetUserByEmailId(string emailId)
        {

            LogErrors.WriteLog("UserBussinessLogic/GetUserByEmailId executing");


            // UnitofWork.UserRepository.DbSet.AsNoTracking().FirstOrDefault

            var user = base.UnitofWork
                        .UserRepository
                        .Get(x => x.EmailId.Contains( emailId));

            UserModel userVm = null;
            if (user != null)
                userVm = UserTranslator.UserEntityToModel(user.FirstOrDefault());

            LogErrors.WriteLog("UserBussinessLogic/GetUserByEmailId Executed");
            return userVm;

        }

        public UserModel GetUserById(int id)
        {

            LogErrors.WriteLog("UserBussinessLogic/GetUserById executing");


            // UnitofWork.UserRepository.DbSet.AsNoTracking().FirstOrDefault

            var user = base.UnitofWork
                        .UserRepository
                        .GetById(id);
            var userVm = UserTranslator.UserEntityToModel(user);

            LogErrors.WriteLog("UserBussinessLogic/GetUserById Executed");
            return userVm;

        }


   


        public void ChangePassword(int id, string NewPassword)
        {

            LogErrors.WriteLog("UserBussinessLogic/ChangePassword executing");


            // UnitofWork.UserRepository.DbSet.AsNoTracking().FirstOrDefault

            var user = base.UnitofWork
                        .UserRepository
                        .GetById(id);
            user.Password = NewPassword;

            base.UnitofWork
                        .UserRepository
                        .Update(user);

            base.UnitofWork.Save();


            LogErrors.WriteLog("UserBussinessLogic/ChangePassword Executed");


        }




        public void SaveUser(UserModel userVm)
        {

            LogErrors.WriteLog("UserBussinessLogic/SaveUser executing");

            var user = UserTranslator.UserModelToEntity(userVm);
            base.UnitofWork.Context.UpdateGraph<UserDetails>(user, m => m.AssociatedCollection(u => u.GroupMaster)
                                                                  .AssociatedCollection(u => u.StateMaster)
                                                                  .AssociatedCollection(u => u.FlashCode));
            //base.UnitofWork
            //            .UserRepository
            //            .Insert(user);


            base.UnitofWork.Save();

            LogErrors.WriteLog("UserBussinessLogic/SaveUser Executed");


        }

        public void UpdateUser(UserModel userVm)
        {

            LogErrors.WriteLog("UserBussinessLogic/UpdateUser executing");

            var user = UserTranslator.UserModelToEntity(userVm);
            base.UnitofWork
                        .UserRepository
                        .Update(user);
            base.UnitofWork.Save();

            LogErrors.WriteLog("UserBussinessLogic/UpdateUser Executed");

        }

        public void DeleteUser(int userId)
        {

            LogErrors.WriteLog("UserBussinessLogic/DeleteUser executing");

            var user = base.UnitofWork
                        .UserRepository
                        .GetById(userId);

            //Clear group associations
            user.GroupMaster.Clear();

            //Next line need to be updated
            //await base.UnitofWork.Context.Orders.Where(x => x.Sales_Rep == userId).ForEachAsync(x => x.Sales_Rep = null);

            //Clear UpdatedBy field in OrderHistory table
            //Below code not needed as there's no foreign key relation here now
            //await base.UnitofWork.Context.OrderHistory.Where(t => t.CreatedBy == userId).ForEachAsync(s => s.UpdatedBy = null);

            //Clear state associations
            user.StateMaster.Clear();

            //Clear flash associations
            user.FlashCode.Clear();

            //Finally, remove user
            base.UnitofWork
                        .UserRepository
                        .Delete(userId);
            base.UnitofWork.Save();

            LogErrors.WriteLog("UserBussinessLogic/DeleteUser Executed");

        }

        public void ToUI(UserModel user)
        {
            LogErrors.WriteLog("UserBussinessLogic/ToUI Executed");
            if (user == null) return;
            user.SelectedGroups = user.GroupDefaults.ToList().ConvertAll(t => t.Id);

            user.SelectedStates = user.StateDefaults.ToList().ConvertAll(t => t.Id);

            user.SelectedFlashCodes = user.FlashCodeDefaults.ToList().ConvertAll(t => t.Id);
            LogErrors.WriteLog("UserBussinessLogic/ToUI Executed");
        }

        public void FromUI(UserModel user, Func<int, GroupModel> getg)
        {
            LogErrors.WriteLog("UserBussinessLogic/FromUI Executed");
            if (user.SelectedGroups != null && user.SelectedGroups.Count > 0)
            {
                user.GroupDefaults = user.SelectedGroups.ConvertAll(g => getg(g));
            }
            LogErrors.WriteLog("UserBussinessLogic/FromUI Executed");
        }

        public void Dispose()
        {
            base.UnitofWork.Dispose();
        }
    }
}

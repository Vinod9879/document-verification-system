
using Microsoft.ML;
using Microsoft.ML.Data;

namespace AspVectorSearch.Services {
    public class EmbeddingService {

        private class Input { public string Text { get; set; } }
        private class Output { [VectorType(50)] public float[] Embedding { get; set; } }

        public float[] GetEmbedding(string text)
        {
            if (string.IsNullOrWhiteSpace(text))
                text = "";

            var ml = new MLContext();
            var data = ml.Data.LoadFromEnumerable(new[] { new Input { Text = text } });

            var pipeline = ml.Transforms.Text.NormalizeText("Clean", nameof(Input.Text))
                .Append(ml.Transforms.Text.TokenizeIntoWords("Tokens", "Clean"))
                .Append(ml.Transforms.Text.ProduceWordEmbeddings(
                    "Embedding", "Tokens",
                    modelKind: Microsoft.ML.Transforms.Text.WordEmbeddingsExtractingEstimator.PretrainedModelKind.GloVe50D));

            var model = pipeline.Fit(data);
            var engine = ml.Model.CreatePredictionEngine<Input, Output>(model);

            var result = engine.Predict(new Input { Text = text });
            return result.Embedding;
        }
    }
}

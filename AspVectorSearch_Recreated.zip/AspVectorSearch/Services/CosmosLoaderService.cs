
using Microsoft.Azure.Cosmos;

namespace AspVectorSearch.Services {
    public class CosmosLoaderService {

        public async Task LoadAsync(
            EmbeddingService emb,
            VectorIndexService index,
            string conn,
            string db,
            string cont)
        {
            Console.WriteLine("➡ Loading data from Cosmos DB...");

            var client = new CosmosClient(conn);
            var container = client.GetContainer(db, cont);

            var iterator = container.GetItemQueryIterator<dynamic>("SELECT c.id, c.name FROM c");

            int count = 0;
            while (iterator.HasMoreResults)
            {
                foreach (var item in await iterator.ReadNextAsync())
                {
                    string id = item.id;
                    string name = item.name;

                    float[] vec = emb.GetEmbedding(name);
                    index.Index.AddItem(vec, id);
                    count++;
                }
            }

            Console.WriteLine($"✔ Indexed {count} items. Building ANN index...");
            index.Index.BuildIndex();

            Console.WriteLine("✔ Finished building index.");
        }
    }
}

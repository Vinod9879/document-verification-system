
using HNSW.Net;

namespace AspVectorSearch.Services {
    public class VectorIndexService {
        public SmallWorld<float[], string> Index = new SmallWorld<float[], string>(
            50, DistanceMetric.CosineDistance);
    }
}

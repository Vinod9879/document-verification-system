
namespace AspVectorSearch.Services {
    public class SearchService {
        private readonly EmbeddingService _emb;
        private readonly VectorIndexService _index;

        public SearchService(EmbeddingService e, VectorIndexService i)
        {
            _emb = e;
            _index = i;
        }

        public List<string> Search(string query, int k)
        {
            float[] vec = _emb.GetEmbedding(query);
            var results = _index.Index.KNNSearch(vec, k);

            return results.Select(r => r.Item2).ToList();
        }
    }
}

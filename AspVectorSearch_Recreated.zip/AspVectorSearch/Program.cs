
using AspVectorSearch.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<EmbeddingService>();
builder.Services.AddSingleton<VectorIndexService>();
builder.Services.AddSingleton<CosmosLoaderService>();
builder.Services.AddSingleton<SearchService>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

var loader = app.Services.GetRequiredService<CosmosLoaderService>();
var cfg = builder.Configuration;
await loader.LoadAsync(
    app.Services.GetRequiredService<EmbeddingService>(),
    app.Services.GetRequiredService<VectorIndexService>(),
    cfg["Cosmos:ConnectionString"],
    cfg["Cosmos:Database"],
    cfg["Cosmos:Container"]
);

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapControllers();
app.Run();

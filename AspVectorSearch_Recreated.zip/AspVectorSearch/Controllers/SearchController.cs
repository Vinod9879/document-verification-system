
using Microsoft.AspNetCore.Mvc;
using AspVectorSearch.Services;

namespace AspVectorSearch.Controllers
{
    [ApiController]
    [Route("api/search")]
    public class SearchController : ControllerBase
    {
        private readonly SearchService _service;

        public SearchController(SearchService service)
        {
            _service = service;
        }

        [HttpPost]
        public IActionResult Search([FromBody] dynamic body)
        {
            string query = body.query;
            int k = body.k;

            var result = _service.Search(query, k);
            return Ok(result);
        }
    }
}

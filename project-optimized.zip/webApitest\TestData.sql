-- Test Data for Document Verification System
-- This script populates the tables with sample data for testing

-- Clear existing data (optional - uncomment if needed)
-- DELETE FROM ExtractedDataDocuments;
-- DELETE FROM OriginalSurveyNo;
-- DELETE FROM OriginalPan;
-- DELETE FROM OriginalAdhar;

-- Insert sample data into OriginalAdhar table
INSERT INTO OriginalAdhar (Name, Dob, AdhaarNo, CreatedAt, UpdatedAt) VALUES
('John Doe', '1990-05-15', '123456789012', GETUTCDATE(), NULL),
('Jane Smith', '1985-08-22', '987654321098', GETUTCDATE(), NULL),
('Mike Johnson', '1992-12-10', '456789123456', GETUTCDATE(), NULL),
('Sarah Wilson', '1988-03-25', '789123456789', GETUTCDATE(), NULL),
('David Brown', '1995-07-18', '321654987321', GETUTCDATE(), NULL);

-- Insert sample data into OriginalPan table
INSERT INTO OriginalPan (Name, Dob, PanNo, CreatedAt, UpdatedAt) VALUES
('John Doe', '1990-05-15', 'ABCDE1234F', GETUTCDATE(), NULL),
('Jane Smith', '1985-08-22', 'FGHIJ5678K', GETUTCDATE(), NULL),
('Mike Johnson', '1992-12-10', 'LMNOP9012Q', GETUTCDATE(), NULL),
('Sarah Wilson', '1988-03-25', 'RSTUV3456W', GETUTCDATE(), NULL),
('David Brown', '1995-07-18', 'XYZAB7890C', GETUTCDATE(), NULL);

-- Insert sample data into OriginalSurveyNo table
INSERT INTO OriginalSurveyNo (SurveyNo, MeasuringArea, Village, Hobli, Taluk, District, Latitude, Longitude, CreatedAt, UpdatedAt) VALUES
('123/45', '2.5 acres', 'Village A', 'Hobli 1', 'Taluk 1', 'District 1', 12.9716, 77.5946, GETUTCDATE(), NULL),
('456/78', '3.2 acres', 'Village B', 'Hobli 2', 'Taluk 2', 'District 2', 13.0827, 80.2707, GETUTCDATE(), NULL),
('789/12', '1.8 acres', 'Village C', 'Hobli 3', 'Taluk 3', 'District 3', 15.3173, 75.7139, GETUTCDATE(), NULL),
('321/65', '4.1 acres', 'Village D', 'Hobli 4', 'Taluk 4', 'District 4', 17.3850, 78.4867, GETUTCDATE(), NULL),
('654/98', '2.9 acres', 'Village E', 'Hobli 5', 'Taluk 5', 'District 5', 19.0760, 72.8777, GETUTCDATE(), NULL);

-- Insert sample data into ExtractedDataDocuments table
INSERT INTO ExtractedDataDocuments (ApplicationNumber, Name, Address, SurveyNumber, MeasuringArea, Village, Hobli, Taluk, District, AadhaarNumber, PANNumber, DOB, CreatedAt, UpdatedAt) VALUES
('APP001', 'John Doe', '123 Main Street, City A', '123/45', '2.5 acres', 'Village A', 'Hobli 1', 'Taluk 1', 'District 1', '123456789012', 'ABCDE1234F', '1990-05-15', GETUTCDATE(), NULL),
('APP002', 'Jane Smith', '456 Oak Avenue, City B', '456/78', '3.2 acres', 'Village B', 'Hobli 2', 'Taluk 2', 'District 2', '987654321098', 'FGHIJ5678K', '1985-08-22', GETUTCDATE(), NULL),
('APP003', 'Mike Johnson', '789 Pine Road, City C', '789/12', '1.8 acres', 'Village C', 'Hobli 3', 'Taluk 3', 'District 3', '456789123456', 'LMNOP9012Q', '1992-12-10', GETUTCDATE(), NULL),
('APP004', 'Sarah Wilson', '321 Elm Street, City D', '321/65', '4.1 acres', 'Village D', 'Hobli 4', 'Taluk 4', 'District 4', '789123456789', 'RSTUV3456W', '1988-03-25', GETUTCDATE(), NULL),
('APP005', 'David Brown', '654 Maple Lane, City E', '654/98', '2.9 acres', 'Village E', 'Hobli 5', 'Taluk 5', 'District 5', '321654987321', 'XYZAB7890C', '1995-07-18', GETUTCDATE(), NULL);

-- Insert some mismatched data for testing verification failures
INSERT INTO ExtractedDataDocuments (ApplicationNumber, Name, Address, SurveyNumber, MeasuringArea, Village, Hobli, Taluk, District, AadhaarNumber, PANNumber, DOB, CreatedAt, UpdatedAt) VALUES
('APP006', 'Test User', '999 Test Street, Test City', '999/99', '5.0 acres', 'Test Village', 'Test Hobli', 'Test Taluk', 'Test District', '999999999999', 'TEST1234T', '1990-01-01', GETUTCDATE(), NULL);

-- Display the inserted data
SELECT 'OriginalAdhar Data:' as TableName;
SELECT * FROM OriginalAdhar;

SELECT 'OriginalPan Data:' as TableName;
SELECT * FROM OriginalPan;

SELECT 'OriginalSurveyNo Data:' as TableName;
SELECT * FROM OriginalSurveyNo;

SELECT 'ExtractedDataDocuments Data:' as TableName;
SELECT * FROM ExtractedDataDocuments;

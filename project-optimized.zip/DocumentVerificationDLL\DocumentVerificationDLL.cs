using System;
using System.IO;
using System.Threading.Tasks;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Linq;
using Microsoft.Extensions.Logging;
using UglyToad.PdfPig;
using UglyToad.PdfPig.Content;
using Tesseract;

namespace DocumentVerificationDLL
{
    public class DocumentVerificationDLL : IDocumentVerificationDLL
    {
        private readonly ILogger<DocumentVerificationDLL> _logger;

        public DocumentVerificationDLL(ILogger<DocumentVerificationDLL> logger)
        {
            _logger = logger;
        }

        public async Task<ExtractedData> ExtractECAsync(string filePath)
        {
            try
            {
                _logger.LogInformation($"Extracting EC document: {filePath}");

                if (string.IsNullOrEmpty(filePath))
                {
                    throw new ArgumentException("File path cannot be null or empty");
                }

                if (!File.Exists(filePath))
                {
                    throw new FileNotFoundException($"EC document not found: {filePath}");
                }

                // Validate file extension
                if (!Path.GetExtension(filePath).Equals(".pdf", StringComparison.OrdinalIgnoreCase))
                {
                    throw new ArgumentException("EC document must be a PDF file");
                }

                var extractedData = new ExtractedData();
                var extractedText = await ExtractTextFromPdfAsync(filePath);
                
                // Clean text
                extractedText = Regex.Replace(extractedText, @"\r\n|\n", " ");
                extractedText = Regex.Replace(extractedText, @"\s{2,}", " ");

                // Extract EC-specific fields using improved regex patterns
                extractedData.ApplicationNumber = RegexMatch(extractedText, @"Application Number[:\s]*([A-Z0-9\-]+)");
                extractedData.Name = RegexMatch(extractedText, @"Name of the Applicant[:\s]*([A-Z\s]+)");
                extractedData.Address = RegexMatch(extractedText, @"Address of the Applicant[:\s]*([^\.]+-\s*\d{6})");
                extractedData.SurveyNumber = RegexMatch(extractedText, @"Survey No[:\s]*([\d/]+)");
                extractedData.MeasuringArea = RegexMatch(extractedText, @"Measuring[:\s]*([\d]+\s*Sqft)");
                extractedData.Village = RegexMatch(extractedText, @"Village Name[:\s]*([A-Za-z\s]+)") 
                    ?? RegexMatch(extractedText, @"([A-Za-z\s]+)\s+Village");
                extractedData.Hobli = RegexMatch(extractedText, @"Hobli Name[:\s]*([A-Za-z\s]+)") 
                    ?? RegexMatch(extractedText, @"([A-Za-z\s]+)\s+Hobli");
                extractedData.Taluk = RegexMatch(extractedText, @"([A-Za-z\s]+)\s+Taluk");
                extractedData.District = RegexMatch(extractedText, @"District Name[:\s]*([A-Za-z\s]+)") 
                    ?? RegexMatch(extractedText, @"([A-Za-z\s]+)\s+District");
                
                // Calculate confidence score based on extracted fields
                extractedData.ConfidenceScore = CalculateConfidenceScore(extractedData);
                extractedData.ExtractionNotes = $"EC document processed successfully. Extracted {CountExtractedFields(extractedData)} fields.";

                _logger.LogInformation($"EC extraction completed. Confidence: {extractedData.ConfidenceScore}%");
                return extractedData;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error extracting EC document: {filePath}");
                throw;
            }
        }

        public async Task<ExtractedData> ExtractAadhaarAsync(string filePath)
        {
            try
            {
                _logger.LogInformation($"Extracting Aadhaar document: {filePath}");

                if (string.IsNullOrEmpty(filePath))
                {
                    throw new ArgumentException("File path cannot be null or empty");
                }

                if (!File.Exists(filePath))
                {
                    throw new FileNotFoundException($"Aadhaar document not found: {filePath}");
                }

                // Validate file extension
                if (!Path.GetExtension(filePath).Equals(".png", StringComparison.OrdinalIgnoreCase))
                {
                    throw new ArgumentException("Aadhaar document must be a PNG file");
                }

                var extractedData = new ExtractedData();
                var extractedText = await ExtractTextFromImageAsync(filePath);
                
                // Log the raw extracted text for debugging
                _logger.LogInformation($"Raw OCR text for Aadhaar: {extractedText}");
                
                // Clean and process the text - don't filter out lines with SAMPLE/PROJECT as they contain the actual data
                var lines = extractedText.Split('\n', StringSplitOptions.RemoveEmptyEntries)
                    .Select(l => l.Trim())
                    .Where(l => !l.Equals("Male", StringComparison.OrdinalIgnoreCase) && 
                                !l.Contains("Income tax") && !l.Contains("INCOME TAX"))
                    .ToList();
                
                _logger.LogInformation($"Processed lines for Aadhaar: {string.Join(" | ", lines)}");

                // Extract Aadhaar number (12 digits in groups of 4)
                string aadhaarNo = lines.FirstOrDefault(l => Regex.IsMatch(l, @"\b\d{4}\s\d{4}\s\d{4}\b")) ?? "";
    
                // Extract name - look for lines that contain name patterns
                string name = lines.FirstOrDefault(l => 
                    Regex.IsMatch(l, @"^[A-Z\s]+$") && 
                    l.Length > 5 && l.Length < 30 && 
                    !l.Contains("SAMPLE") && !l.Contains("PROJECT") &&
                    !l.Contains("Sample country") && !l.Contains("Income tax")) ?? "";

                extractedData.Name = name;
                extractedData.AadhaarNumber = aadhaarNo;
                
                // Calculate confidence score based on extracted fields
                extractedData.ConfidenceScore = CalculateConfidenceScore(extractedData);
                extractedData.ExtractionNotes = $"Aadhaar document processed successfully. Extracted {CountExtractedFields(extractedData)} fields.";

                _logger.LogInformation($"Aadhaar extraction completed. Confidence: {extractedData.ConfidenceScore}%");
                return extractedData;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error extracting Aadhaar document: {filePath}");
                throw;
            }
        }

        public async Task<ExtractedData> ExtractPANAsync(string filePath)
        {
            try
            {
                _logger.LogInformation($"Extracting PAN document: {filePath}");

                if (string.IsNullOrEmpty(filePath))
                {
                    throw new ArgumentException("File path cannot be null or empty");
                }

                if (!File.Exists(filePath))
                {
                    throw new FileNotFoundException($"PAN document not found: {filePath}");
                }

                // Validate file extension
                if (!Path.GetExtension(filePath).Equals(".png", StringComparison.OrdinalIgnoreCase))
                {
                    throw new ArgumentException("PAN document must be a PNG file");
                }

                var extractedData = new ExtractedData();
                var extractedText = await ExtractTextFromImageAsync(filePath);
                
                // Log the raw extracted text for debugging
                _logger.LogInformation($"Raw OCR text for PAN: {extractedText}");
                
                // Clean and process the text - keep all lines for better extraction
                var lines = extractedText.Split('\n', StringSplitOptions.RemoveEmptyEntries)
                    .Select(l => l.Trim())
                    .Where(l => !l.Contains("INCOME TAX") && !l.Contains("Income tax"))
                    .ToList();
                
                _logger.LogInformation($"Processed lines for PAN: {string.Join(" | ", lines)}");

                string panNo = "";
                string dob = "";
                string name = "";

                // Find PAN number (format: ABCPD1234E)
                panNo = lines.FirstOrDefault(l => Regex.IsMatch(l, @"[A-Z]{5}[0-9]{4}[A-Z]")) ?? "";

                // Find DOB - look for "Date of Birth: DD/MM/YYYY" or just "DD/MM/YYYY"
                string dobLine = lines.FirstOrDefault(l => Regex.IsMatch(l, @"(?:Date of Birth:\s*|\b)\d{2}/\d{2}/\d{4}\b"));
                if (!string.IsNullOrEmpty(dobLine))
                {
                    var dobMatch = Regex.Match(dobLine, @"\d{2}/\d{2}/\d{4}");
                    if (dobMatch.Success)
                    {
                        dob = dobMatch.Value;
                    }
                }

                // Extract name - look for "SURESH SHARMA" pattern
                name = lines.FirstOrDefault(l => 
                    Regex.IsMatch(l, @"^[A-Z\s]+$") && 
                    l.Length > 5 && l.Length < 30 && 
                    !l.Contains("SAMPLE") && !l.Contains("PROJECT") &&
                    !l.Contains("Sample country") && !l.Contains("Date of Birth")) ?? "";

                extractedData.Name = name.Trim();
                extractedData.DOB = dob.Trim();
                extractedData.PANNumber = panNo.Trim();
                
                // Calculate confidence score based on extracted fields
                extractedData.ConfidenceScore = CalculateConfidenceScore(extractedData);
                extractedData.ExtractionNotes = $"PAN document processed successfully. Extracted {CountExtractedFields(extractedData)} fields.";

                _logger.LogInformation($"PAN extraction completed. Confidence: {extractedData.ConfidenceScore}%");
                return extractedData;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error extracting PAN document: {filePath}");
                throw;
            }
        }

        // Verification method removed - DLL now focuses only on extraction
        // Verification logic has been moved to DocumentProcessingService in the backend

        #region Helper Methods

        /// <summary>
        /// Extracts text from PDF using PDFPig
        /// </summary>
        private Task<string> ExtractTextFromPdfAsync(string filePath)
        {
            try
            {
                using var document = PdfDocument.Open(filePath);
                var text = new System.Text.StringBuilder();

                foreach (var page in document.GetPages())
                {
                    text.AppendLine(page.Text);
                }

                _logger.LogInformation($"Extracted {text.Length} characters from PDF: {filePath}");
                return Task.FromResult(text.ToString());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error extracting text from PDF: {filePath}");
                throw;
            }
        }

        /// <summary>
        /// Extracts text from image using Tesseract OCR
        /// </summary>
        private Task<string> ExtractTextFromImageAsync(string filePath)
        {
            try
            {
                // Use the tessdata folder in the DLL's output directory
                var tessDataPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "tessdata");
                
                // Fallback to current directory if tessdata not found in BaseDirectory
                if (!Directory.Exists(tessDataPath))
                {
                    tessDataPath = Path.Combine(Directory.GetCurrentDirectory(), "tessdata");
                }
                
                // Final fallback - use a relative path
                if (!Directory.Exists(tessDataPath))
                {
                    tessDataPath = "tessdata";
                }
                
                _logger.LogInformation($"Using Tesseract data path: {tessDataPath}");
                
                using var ocr = new TesseractEngine(tessDataPath, "eng", EngineMode.Default);
                using var img = Pix.LoadFromFile(filePath);
                using var page = ocr.Process(img);
                string text = page.GetText();

                _logger.LogInformation($"Extracted {text.Length} characters from image: {filePath}");
                return Task.FromResult(text);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error extracting text from image: {filePath}");
                throw;
            }
        }

        /// <summary>
        /// Helper method for regex matching with group extraction
        /// </summary>
        private string RegexMatch(string text, string pattern)
        {
            var match = Regex.Match(text, pattern, RegexOptions.IgnoreCase);
            if (match.Success)
            {
                return match.Groups.Count > 1 ? match.Groups[1].Value.Trim() : match.Value.Trim();
            }
            return null;
        }

        // Validation method removed - DLL now focuses only on extraction

        /// <summary>
        /// Extracts a specific field using regex pattern
        /// </summary>
        private string ExtractField(string text, string pattern, string fieldName)
        {
            try
            {
                var match = Regex.Match(text, pattern, RegexOptions.IgnoreCase | RegexOptions.Multiline);
                if (match.Success && match.Groups.Count > 1)
                {
                    var value = match.Groups[1].Value.Trim();
                    _logger.LogDebug($"Extracted {fieldName}: {value}");
                    return value;
                }
                else
                {
                    _logger.LogWarning($"Could not extract {fieldName} from document");
                    return string.Empty;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error extracting {fieldName}");
                return string.Empty;
            }
        }

        /// <summary>
        /// Calculates confidence score based on extracted fields
        /// </summary>
        private decimal CalculateConfidenceScore(ExtractedData data)
        {
            var score = 0m;
            var totalFields = 0;

            // Check each field and add to score
            if (!string.IsNullOrEmpty(data.Name)) { score += 20; totalFields++; }
            if (!string.IsNullOrEmpty(data.DOB)) { score += 20; totalFields++; }
            if (!string.IsNullOrEmpty(data.AadhaarNumber)) { score += 20; totalFields++; }
            if (!string.IsNullOrEmpty(data.PANNumber)) { score += 20; totalFields++; }
            if (!string.IsNullOrEmpty(data.ECNumber)) { score += 20; totalFields++; }
            if (!string.IsNullOrEmpty(data.SurveyNumber)) { score += 15; totalFields++; }
            if (!string.IsNullOrEmpty(data.Address)) { score += 15; totalFields++; }
            if (!string.IsNullOrEmpty(data.FatherName)) { score += 10; totalFields++; }
            if (!string.IsNullOrEmpty(data.MotherName)) { score += 10; totalFields++; }
            if (!string.IsNullOrEmpty(data.PropertyDetails)) { score += 10; totalFields++; }
            
            // EC Document specific fields
            if (!string.IsNullOrEmpty(data.ApplicationNumber)) { score += 15; totalFields++; }
            if (!string.IsNullOrEmpty(data.MeasuringArea)) { score += 10; totalFields++; }
            if (!string.IsNullOrEmpty(data.Village)) { score += 10; totalFields++; }
            if (!string.IsNullOrEmpty(data.Hobli)) { score += 10; totalFields++; }
            if (!string.IsNullOrEmpty(data.Taluk)) { score += 10; totalFields++; }
            if (!string.IsNullOrEmpty(data.District)) { score += 10; totalFields++; }

            // Calculate percentage
            var confidence = totalFields > 0 ? (score / totalFields) * 100 : 0;
            return Math.Min(confidence, 100); // Cap at 100%
        }

        /// <summary>
        /// Counts the number of extracted fields
        /// </summary>
        private int CountExtractedFields(ExtractedData data)
        {
            var count = 0;
            if (!string.IsNullOrEmpty(data.Name)) count++;
            if (!string.IsNullOrEmpty(data.DOB)) count++;
            if (!string.IsNullOrEmpty(data.AadhaarNumber)) count++;
            if (!string.IsNullOrEmpty(data.PANNumber)) count++;
            if (!string.IsNullOrEmpty(data.ECNumber)) count++;
            if (!string.IsNullOrEmpty(data.SurveyNumber)) count++;
            if (!string.IsNullOrEmpty(data.Address)) count++;
            if (!string.IsNullOrEmpty(data.FatherName)) count++;
            if (!string.IsNullOrEmpty(data.MotherName)) count++;
            if (!string.IsNullOrEmpty(data.PropertyDetails)) count++;
            
            // EC Document specific fields
            if (!string.IsNullOrEmpty(data.ApplicationNumber)) count++;
            if (!string.IsNullOrEmpty(data.MeasuringArea)) count++;
            if (!string.IsNullOrEmpty(data.Village)) count++;
            if (!string.IsNullOrEmpty(data.Hobli)) count++;
            if (!string.IsNullOrEmpty(data.Taluk)) count++;
            if (!string.IsNullOrEmpty(data.District)) count++;
            return count;
        }

        #endregion
    }
}

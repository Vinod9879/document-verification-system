# PowerShell script to test the verification system
# Make sure the API is running before executing this script

Write-Host "🧪 Testing Document Verification System" -ForegroundColor Green
Write-Host "=======================================" -ForegroundColor Green

# API Base URL
$baseUrl = "https://localhost:50538/api"

# Test data seeding
Write-Host "`n1. Seeding test data..." -ForegroundColor Yellow
try {
    $seedResponse = Invoke-RestMethod -Uri "$baseUrl/AdminDashboard/seed-test-data" -Method POST -ContentType "application/json"
    Write-Host "✅ Test data seeded successfully!" -ForegroundColor Green
    Write-Host "   - Aadhaar records: $($seedResponse.aadhaarCount)" -ForegroundColor Cyan
    Write-Host "   - PAN records: $($seedResponse.panCount)" -ForegroundColor Cyan
    Write-Host "   - Survey records: $($seedResponse.surveyCount)" -ForegroundColor Cyan
    Write-Host "   - Extracted records: $($seedResponse.extractedCount)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Error seeding test data: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Test verification for matching data (should pass)
Write-Host "`n2. Testing verification for matching data (ID: 1)..." -ForegroundColor Yellow
try {
    $verifyResponse = Invoke-RestMethod -Uri "$baseUrl/AdminDashboard/verify-documents/1" -Method POST -ContentType "application/json"
    Write-Host "✅ Verification completed!" -ForegroundColor Green
    Write-Host "   - Is Verified: $($verifyResponse.isVerified)" -ForegroundColor Cyan
    Write-Host "   - Risk Score: $($verifyResponse.riskScore)" -ForegroundColor Cyan
    Write-Host "   - Notes: $($verifyResponse.verificationNotes)" -ForegroundColor Cyan
    if ($verifyResponse.latitude -and $verifyResponse.longitude) {
        Write-Host "   - Coordinates: $($verifyResponse.latitude), $($verifyResponse.longitude)" -ForegroundColor Cyan
    }
} catch {
    Write-Host "❌ Error during verification: $($_.Exception.Message)" -ForegroundColor Red
}

# Test verification for mismatched data (should fail)
Write-Host "`n3. Testing verification for mismatched data (ID: 6)..." -ForegroundColor Yellow
try {
    $verifyResponse = Invoke-RestMethod -Uri "$baseUrl/AdminDashboard/verify-documents/6" -Method POST -ContentType "application/json"
    Write-Host "✅ Verification completed!" -ForegroundColor Green
    Write-Host "   - Is Verified: $($verifyResponse.isVerified)" -ForegroundColor Cyan
    Write-Host "   - Risk Score: $($verifyResponse.riskScore)" -ForegroundColor Cyan
    Write-Host "   - Notes: $($verifyResponse.verificationNotes)" -ForegroundColor Cyan
    if ($verifyResponse.fieldMismatches) {
        Write-Host "   - Mismatches: $($verifyResponse.fieldMismatches)" -ForegroundColor Red
    }
} catch {
    Write-Host "❌ Error during verification: $($_.Exception.Message)" -ForegroundColor Red
}

# Test getting all extracted data
Write-Host "`n4. Testing get all extracted data..." -ForegroundColor Yellow
try {
    $extractedData = Invoke-RestMethod -Uri "$baseUrl/AdminDashboard/all-extracted-data" -Method GET
    Write-Host "✅ Retrieved $($extractedData.Count) extracted data records" -ForegroundColor Green
    foreach ($record in $extractedData) {
        Write-Host "   - ID: $($record.id), Name: $($record.name), App: $($record.applicationNumber)" -ForegroundColor Cyan
    }
} catch {
    Write-Host "❌ Error retrieving extracted data: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n🎉 Testing completed!" -ForegroundColor Green
Write-Host "You can now test the verification system in the admin dashboard." -ForegroundColor Cyan

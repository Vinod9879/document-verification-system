# 🔧 **TROUBLESHOOTING GUIDE - Document Upload & Admin View Data**

## 🚨 **Issues Identified & Solutions**

### **Issue 1: Document Upload Not Extracting Data**

#### **Possible Causes:**
1. **DLL not being called** - File lock issues
2. **Database table doesn't exist** - Migration not run
3. **File paths incorrect** - Documents not found
4. **DLL extraction failing** - OCR/Tesseract issues

#### **Solutions:**

##### **A. Check Database Table Exists:**
```bash
# Test database connection
curl http://localhost:5000/api/AdminDashboard/test-database
```

##### **B. Check Logs:**
Look for these log messages in the backend:
- `"Starting DLL extraction for upload ID: {uploadId}"`
- `"Found upload record. EC Path: {path}"`
- `"Extracting EC document: {path}"`
- `"EC extraction completed. Name: {name}"`

##### **C. Manual Database Creation:**
If migration fails, run the SQL script manually:
```sql
-- Execute CREATE_EXTRACTED_DATA_DOCUMENTS_TABLE.sql
```

---

### **Issue 2: Admin "View Data" Not Working**

#### **Possible Causes:**
1. **API endpoint mismatch** - Wrong URL being called
2. **Data not in ExtractedDataDocuments table** - Fallback to UserUploadedDocuments
3. **Frontend modal not displaying** - Data structure mismatch

#### **Solutions:**

##### **A. Check API Endpoints:**
```bash
# Test new endpoint
curl http://localhost:5000/api/AdminDashboard/extracted-data/1

# Test fallback endpoint  
curl http://localhost:5000/api/AdminDashboard/documents/1/extracted-data
```

##### **B. Check Data Flow:**
1. **User uploads documents** → DLL extracts → Data saved to both tables
2. **Admin clicks "View Data"** → API calls → Modal displays data

---

## 🔍 **Step-by-Step Debugging**

### **Step 1: Test Database Connection**
```bash
# Start backend
dotnet run

# Test database endpoint
curl http://localhost:5000/api/AdminDashboard/test-database
```

**Expected Response:**
```json
{
  "message": "Database connection successful",
  "tableExists": true,
  "recordCount": 0,
  "timestamp": "2024-01-01T00:00:00Z"
}
```

### **Step 2: Test Document Upload**
1. **Upload documents** as user
2. **Check backend logs** for extraction messages
3. **Check database** for records in `ExtractedDataDocuments`

### **Step 3: Test Admin View Data**
1. **Login as admin**
2. **Go to Document Monitoring**
3. **Click "View Data"** on any document
4. **Check browser console** for API errors

---

## 🛠️ **Quick Fixes**

### **Fix 1: Create Database Table Manually**
```sql
-- Run this in SQL Server Management Studio
CREATE TABLE ExtractedDataDocuments
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    ApplicationNumber NVARCHAR(50) NULL,
    Name NVARCHAR(200) NOT NULL,
    Address NVARCHAR(500) NULL,
    SurveyNumber NVARCHAR(50) NULL,
    MeasuringArea NVARCHAR(100) NULL,
    Village NVARCHAR(100) NULL,
    Hobli NVARCHAR(100) NULL,
    Taluk NVARCHAR(100) NULL,
    District NVARCHAR(100) NULL,
    AadhaarNumber CHAR(12) NULL,
    PANNumber CHAR(10) NULL,
    DOB DATE NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    UpdatedAt DATETIME2 NULL
);
```

### **Fix 2: Stop Running Processes**
```bash
# Stop any running backend processes
taskkill /f /im dotnet.exe
taskkill /f /im webApitest.exe

# Then restart
dotnet run
```

### **Fix 3: Check File Paths**
Ensure uploaded documents are in the correct directory:
- **EC**: `webApitest/Uploads/UserDocuments/{userId}/EC_{timestamp}.pdf`
- **Aadhaar**: `webApitest/Uploads/UserDocuments/{userId}/Aadhaar_{timestamp}.png`
- **PAN**: `webApitest/Uploads/UserDocuments/{userId}/PAN_{timestamp}.png`

---

## 📊 **Testing Checklist**

### **Backend Tests:**
- [ ] Database connection works
- [ ] ExtractedDataDocuments table exists
- [ ] DLL extraction is called
- [ ] Data is saved to database
- [ ] API endpoints return data

### **Frontend Tests:**
- [ ] Document upload works
- [ ] Admin dashboard loads
- [ ] "View Data" button works
- [ ] Modal displays data correctly

### **Integration Tests:**
- [ ] User uploads documents
- [ ] Data is extracted automatically
- [ ] Admin can view extracted data
- [ ] All fields are populated correctly

---

## 🚀 **Expected Flow**

### **Complete Working Flow:**
1. **User uploads 3 documents** (EC.pdf, Aadhaar.png, PAN.png)
2. **Backend calls DLL** automatically
3. **DLL extracts data** from all documents
4. **Data saved to** `ExtractedDataDocuments` table
5. **Admin clicks "View Data"**
6. **API returns extracted data**
7. **Modal displays** all information

### **Debug Messages to Look For:**
```
Starting DLL extraction for upload ID: 1
Found upload record. EC Path: /path/to/EC.pdf
Extracting EC document: /path/to/EC.pdf
EC extraction completed. Name: John Doe
Saving extracted data to ExtractedDataDocuments table
Successfully extracted and saved data for upload 1
```

---

## ⚠️ **Common Issues & Solutions**

### **Issue: "Table doesn't exist"**
**Solution:** Run the SQL script manually or create migration

### **Issue: "DLL not found"**
**Solution:** Check DLL path in project file and rebuild

### **Issue: "File not found"**
**Solution:** Check file paths and ensure documents are uploaded correctly

### **Issue: "Modal not showing"**
**Solution:** Check browser console for JavaScript errors

### **Issue: "No data extracted"**
**Solution:** Check DLL logs and ensure OCR is working

---

## 🎯 **Success Indicators**

### **When Everything Works:**
- ✅ User can upload documents
- ✅ Backend logs show extraction process
- ✅ Database has records in `ExtractedDataDocuments`
- ✅ Admin can view extracted data
- ✅ Modal shows all fields populated

### **Debug Commands:**
```bash
# Check if backend is running
netstat -an | findstr :5000

# Check database connection
curl http://localhost:5000/api/AdminDashboard/test-database

# Check if table has data
curl http://localhost:5000/api/AdminDashboard/all-extracted-data
```

The system should now work end-to-end! 🚀

﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace webApitest.Migrations
{
    /// <inheritdoc />
    public partial class AddExtractedDataDocumentsTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "PasswordHash" },
                values: new object[] { new DateTime(2025, 9, 25, 11, 48, 37, 394, DateTimeKind.Utc).AddTicks(9884), "$2a$11$E2oPtYtk4E//OCpTm1v4iOKCqI8Cx3CSMNo/OcK.2rPqtKfL/a6uW" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "PasswordHash" },
                values: new object[] { new DateTime(2025, 9, 25, 11, 33, 32, 48, DateTimeKind.Utc).AddTicks(7477), "$2a$11$6VZLp08MDAayVfBAZGXqS.rEi0H1/Xqqy9alEYre1V1YLukRfa8PW" });
        }
    }
}

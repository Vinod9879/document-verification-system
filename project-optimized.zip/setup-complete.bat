@echo off
echo ========================================
echo Document Verification System Setup
echo ========================================
echo.

echo [1/4] Setting up Frontend (React + Vite)...
cd react-contacts-app
echo Installing frontend dependencies...
call npm install
if %errorlevel% neq 0 (
    echo ERROR: Frontend dependency installation failed!
    pause
    exit /b 1
)

echo Building frontend...
call npm run build
if %errorlevel% neq 0 (
    echo ERROR: Frontend build failed!
    pause
    exit /b 1
)
echo ✓ Frontend setup complete!
echo.

echo [2/4] Setting up Backend (ASP.NET Core)...
cd ..\webApitest
echo Building backend...
call dotnet build
if %errorlevel% neq 0 (
    echo ERROR: Backend build failed!
    pause
    exit /b 1
)
echo ✓ Backend setup complete!
echo.

echo [3/4] Database Setup...
echo Running database migrations...
call dotnet ef database update
if %errorlevel% neq 0 (
    echo WARNING: Database migration failed. Please check your connection string.
)
echo ✓ Database setup complete!
echo.

echo [4/4] Starting Services...
echo.
echo ========================================
echo Setup Complete! 
echo ========================================
echo.
echo To start the application:
echo.
echo 1. Backend API (Terminal 1):
echo    cd webApitest
echo    dotnet run
echo.
echo 2. Frontend (Terminal 2):
echo    cd react-contacts-app
echo    npm run dev
echo.
echo 3. Access the application:
echo    Frontend: http://localhost:3000
echo    Backend API: https://localhost:50538
echo.
echo Default Admin Credentials:
echo    Username: admin@contactmanager.com
echo    Password: admin123
echo.
echo ========================================
pause

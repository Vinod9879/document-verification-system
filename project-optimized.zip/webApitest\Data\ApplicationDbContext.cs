using Microsoft.EntityFrameworkCore;
using webApitest.Models;

namespace webApitest.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<UserUploadedDocuments> UserUploadedDocuments { get; set; }
        public DbSet<OriginalAdhar> OriginalAdhar { get; set; }
        public DbSet<OriginalPan> OriginalPan { get; set; }
        public DbSet<OriginalSurveyNo> OriginalSurveyNo { get; set; }
        public DbSet<UserActivityLog> UserActivityLogs { get; set; }
        public DbSet<ExtractedDataDocuments> ExtractedDataDocuments { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure User entity
            modelBuilder.Entity<User>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.FullName).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Email).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Phone).IsRequired().HasMaxLength(15);
                entity.Property(e => e.City).IsRequired().HasMaxLength(50);
                entity.Property(e => e.State).IsRequired().HasMaxLength(50);
                entity.Property(e => e.Pincode).IsRequired().HasMaxLength(10);
                entity.Property(e => e.PasswordHash).IsRequired();
                entity.Property(e => e.Role).IsRequired().HasMaxLength(20);
                entity.Property(e => e.CreatedAt).IsRequired();
                entity.Property(e => e.UpdatedAt);

                // Create unique index on email
                entity.HasIndex(e => e.Email).IsUnique();
            });

            // Configure UserUploadedDocuments entity
            modelBuilder.Entity<UserUploadedDocuments>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.UserId).IsRequired();
                entity.Property(e => e.ExtractedData);
                entity.Property(e => e.VerificationNotes);
                entity.Property(e => e.FieldMismatches);
                entity.Property(e => e.IsSubmitted).IsRequired();
                entity.Property(e => e.IsVerified).IsRequired();
                entity.Property(e => e.RiskScore).HasColumnType("decimal(5,2)");
                entity.Property(e => e.SubmittedAt);
                entity.Property(e => e.CreatedAt).IsRequired();
                entity.Property(e => e.UpdatedAt);

                // User uploaded data fields
                entity.Property(e => e.Name).HasMaxLength(255);
                entity.Property(e => e.AdhaarFullName).HasMaxLength(255);
                entity.Property(e => e.PanFullName).HasMaxLength(255);
                entity.Property(e => e.AdhaarNo).HasMaxLength(20);
                entity.Property(e => e.Dob).HasMaxLength(20);
                entity.Property(e => e.PanNo).HasMaxLength(20);
                entity.Property(e => e.ApplicationNumber).HasMaxLength(50);
                entity.Property(e => e.ApplicantAddress).HasMaxLength(500);
                entity.Property(e => e.SurveyNo).HasMaxLength(50);
                entity.Property(e => e.MeasuringArea).HasMaxLength(50);
                entity.Property(e => e.Village).HasMaxLength(100);
                entity.Property(e => e.Hobli).HasMaxLength(100);
                entity.Property(e => e.Taluk).HasMaxLength(100);
                entity.Property(e => e.District).HasMaxLength(100);

                entity.HasOne(e => e.User)
                      .WithMany()
                      .HasForeignKey(e => e.UserId)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            // Configure OriginalAdhar entity
            modelBuilder.Entity<OriginalAdhar>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Name).HasMaxLength(255);
                entity.Property(e => e.Dob).HasMaxLength(20);
                entity.Property(e => e.AdhaarNo).HasMaxLength(20);
                entity.Property(e => e.CreatedAt).IsRequired();
                entity.Property(e => e.UpdatedAt);
            });

            // Configure OriginalPan entity
            modelBuilder.Entity<OriginalPan>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Name).HasMaxLength(255);
                entity.Property(e => e.Dob).HasMaxLength(20);
                entity.Property(e => e.PanNo).HasMaxLength(20);
                entity.Property(e => e.CreatedAt).IsRequired();
                entity.Property(e => e.UpdatedAt);
            });

            // Configure OriginalSurveyNo entity
            modelBuilder.Entity<OriginalSurveyNo>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.SurveyNo).HasMaxLength(50);
                entity.Property(e => e.MeasuringArea).HasMaxLength(50);
                entity.Property(e => e.Village).HasMaxLength(100);
                entity.Property(e => e.Hobli).HasMaxLength(100);
                entity.Property(e => e.Taluk).HasMaxLength(100);
                entity.Property(e => e.District).HasMaxLength(100);
                entity.Property(e => e.Latitude).HasColumnType("decimal(9,6)");
                entity.Property(e => e.Longitude).HasColumnType("decimal(9,6)");
                entity.Property(e => e.CreatedAt).IsRequired();
                entity.Property(e => e.UpdatedAt);
            });

            // Configure UserActivityLog entity
            modelBuilder.Entity<UserActivityLog>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.UserId).IsRequired();
                entity.Property(e => e.Activity).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Description).HasMaxLength(500);
                entity.Property(e => e.IPAddress).HasMaxLength(50);
                entity.Property(e => e.UserAgent).HasMaxLength(200);
                entity.Property(e => e.Timestamp).IsRequired();

                entity.HasOne(e => e.User)
                      .WithMany()
                      .HasForeignKey(e => e.UserId)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            // Configure ExtractedDataDocuments entity
            modelBuilder.Entity<ExtractedDataDocuments>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.ApplicationNumber).HasMaxLength(50);
                entity.Property(e => e.Name).IsRequired().HasMaxLength(200);
                entity.Property(e => e.Address).HasMaxLength(500);
                entity.Property(e => e.SurveyNumber).HasMaxLength(50);
                entity.Property(e => e.MeasuringArea).HasMaxLength(100);
                entity.Property(e => e.Village).HasMaxLength(100);
                entity.Property(e => e.Hobli).HasMaxLength(100);
                entity.Property(e => e.Taluk).HasMaxLength(100);
                entity.Property(e => e.District).HasMaxLength(100);
                entity.Property(e => e.AadhaarNumber).HasMaxLength(12);
                entity.Property(e => e.PANNumber).HasMaxLength(10);
                entity.Property(e => e.DOB);
                entity.Property(e => e.CreatedAt).IsRequired();
                entity.Property(e => e.UpdatedAt);
            });

            // Seed admin user
            modelBuilder.Entity<User>().HasData(
                new User
                {
                    Id = 1,
                    FullName = "System Administrator",
                    Email = "admin@contactmanager.com",
                    Phone = "0000000000",
                    City = "System",
                    State = "System",
                    Pincode = "000000",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("admin123"),
                    Role = "Admin",
                    CreatedAt = DateTime.UtcNow
                }
            );
        }
    }
}

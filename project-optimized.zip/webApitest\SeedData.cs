using Microsoft.EntityFrameworkCore;
using webApitest.Data;
using webApitest.Models;

namespace webApitest
{
    public static class SeedData
    {
        public static async Task SeedTestDataAsync(ApplicationDbContext context)
        {
            try
            {
                // Clear existing test data
                context.ExtractedDataDocuments.RemoveRange(context.ExtractedDataDocuments);
                context.OriginalSurveyNo.RemoveRange(context.OriginalSurveyNo);
                context.OriginalPan.RemoveRange(context.OriginalPan);
                context.OriginalAdhar.RemoveRange(context.OriginalAdhar);
                await context.SaveChangesAsync();

                // Seed OriginalAdhar data
                var aadhaarData = new List<OriginalAdhar>
                {
                    new OriginalAdhar { Name = "John Doe", Dob = "1990-05-15", AdhaarNo = "123456789012" },
                    new OriginalAdhar { Name = "Jane Smith", Dob = "1985-08-22", AdhaarNo = "987654321098" },
                    new OriginalAdhar { Name = "Mike Johnson", Dob = "1992-12-10", AdhaarNo = "456789123456" },
                    new OriginalAdhar { Name = "Sarah Wilson", Dob = "1988-03-25", AdhaarNo = "789123456789" },
                    new OriginalAdhar { Name = "David Brown", Dob = "1995-07-18", AdhaarNo = "321654987321" }
                };

                context.OriginalAdhar.AddRange(aadhaarData);

                // Seed OriginalPan data
                var panData = new List<OriginalPan>
                {
                    new OriginalPan { Name = "John Doe", Dob = "1990-05-15", PanNo = "ABCDE1234F" },
                    new OriginalPan { Name = "Jane Smith", Dob = "1985-08-22", PanNo = "FGHIJ5678K" },
                    new OriginalPan { Name = "Mike Johnson", Dob = "1992-12-10", PanNo = "LMNOP9012Q" },
                    new OriginalPan { Name = "Sarah Wilson", Dob = "1988-03-25", PanNo = "RSTUV3456W" },
                    new OriginalPan { Name = "David Brown", Dob = "1995-07-18", PanNo = "XYZAB7890C" }
                };

                context.OriginalPan.AddRange(panData);

                // Seed OriginalSurveyNo data
                var surveyData = new List<OriginalSurveyNo>
                {
                    new OriginalSurveyNo { SurveyNo = "123/45", MeasuringArea = "2.5 acres", Village = "Village A", Hobli = "Hobli 1", Taluk = "Taluk 1", District = "District 1", Latitude = 12.9716m, Longitude = 77.5946m },
                    new OriginalSurveyNo { SurveyNo = "456/78", MeasuringArea = "3.2 acres", Village = "Village B", Hobli = "Hobli 2", Taluk = "Taluk 2", District = "District 2", Latitude = 13.0827m, Longitude = 80.2707m },
                    new OriginalSurveyNo { SurveyNo = "789/12", MeasuringArea = "1.8 acres", Village = "Village C", Hobli = "Hobli 3", Taluk = "Taluk 3", District = "District 3", Latitude = 15.3173m, Longitude = 75.7139m },
                    new OriginalSurveyNo { SurveyNo = "321/65", MeasuringArea = "4.1 acres", Village = "Village D", Hobli = "Hobli 4", Taluk = "Taluk 4", District = "District 4", Latitude = 17.3850m, Longitude = 78.4867m },
                    new OriginalSurveyNo { SurveyNo = "654/98", MeasuringArea = "2.9 acres", Village = "Village E", Hobli = "Hobli 5", Taluk = "Taluk 5", District = "District 5", Latitude = 19.0760m, Longitude = 72.8777m }
                };

                context.OriginalSurveyNo.AddRange(surveyData);

                // Seed ExtractedDataDocuments data
                var extractedData = new List<ExtractedDataDocuments>
                {
                    new ExtractedDataDocuments 
                    { 
                        ApplicationNumber = "APP001", 
                        Name = "John Doe", 
                        Address = "123 Main Street, City A", 
                        SurveyNumber = "123/45", 
                        MeasuringArea = "2.5 acres", 
                        Village = "Village A", 
                        Hobli = "Hobli 1", 
                        Taluk = "Taluk 1", 
                        District = "District 1", 
                        AadhaarNumber = "123456789012", 
                        PANNumber = "ABCDE1234F", 
                        DOB = new DateTime(1990, 5, 15) 
                    },
                    new ExtractedDataDocuments 
                    { 
                        ApplicationNumber = "APP002", 
                        Name = "Jane Smith", 
                        Address = "456 Oak Avenue, City B", 
                        SurveyNumber = "456/78", 
                        MeasuringArea = "3.2 acres", 
                        Village = "Village B", 
                        Hobli = "Hobli 2", 
                        Taluk = "Taluk 2", 
                        District = "District 2", 
                        AadhaarNumber = "987654321098", 
                        PANNumber = "FGHIJ5678K", 
                        DOB = new DateTime(1985, 8, 22) 
                    },
                    new ExtractedDataDocuments 
                    { 
                        ApplicationNumber = "APP003", 
                        Name = "Mike Johnson", 
                        Address = "789 Pine Road, City C", 
                        SurveyNumber = "789/12", 
                        MeasuringArea = "1.8 acres", 
                        Village = "Village C", 
                        Hobli = "Hobli 3", 
                        Taluk = "Taluk 3", 
                        District = "District 3", 
                        AadhaarNumber = "456789123456", 
                        PANNumber = "LMNOP9012Q", 
                        DOB = new DateTime(1992, 12, 10) 
                    },
                    new ExtractedDataDocuments 
                    { 
                        ApplicationNumber = "APP004", 
                        Name = "Sarah Wilson", 
                        Address = "321 Elm Street, City D", 
                        SurveyNumber = "321/65", 
                        MeasuringArea = "4.1 acres", 
                        Village = "Village D", 
                        Hobli = "Hobli 4", 
                        Taluk = "Taluk 4", 
                        District = "District 4", 
                        AadhaarNumber = "789123456789", 
                        PANNumber = "RSTUV3456W", 
                        DOB = new DateTime(1988, 3, 25) 
                    },
                    new ExtractedDataDocuments 
                    { 
                        ApplicationNumber = "APP005", 
                        Name = "David Brown", 
                        Address = "654 Maple Lane, City E", 
                        SurveyNumber = "654/98", 
                        MeasuringArea = "2.9 acres", 
                        Village = "Village E", 
                        Hobli = "Hobli 5", 
                        Taluk = "Taluk 5", 
                        District = "District 5", 
                        AadhaarNumber = "321654987321", 
                        PANNumber = "XYZAB7890C", 
                        DOB = new DateTime(1995, 7, 18) 
                    },
                    // Add one with mismatched data for testing verification failures
                    new ExtractedDataDocuments 
                    { 
                        ApplicationNumber = "APP006", 
                        Name = "Test User", 
                        Address = "999 Test Street, Test City", 
                        SurveyNumber = "999/99", 
                        MeasuringArea = "5.0 acres", 
                        Village = "Test Village", 
                        Hobli = "Test Hobli", 
                        Taluk = "Test Taluk", 
                        District = "Test District", 
                        AadhaarNumber = "999999999999", 
                        PANNumber = "TEST1234T", 
                        DOB = new DateTime(1990, 1, 1) 
                    }
                };

                context.ExtractedDataDocuments.AddRange(extractedData);

                await context.SaveChangesAsync();
                Console.WriteLine("✅ Test data seeded successfully!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error seeding test data: {ex.Message}");
                throw;
            }
        }
    }
}

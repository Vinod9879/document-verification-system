using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using webApitest.Data;
using webApitest.Models;
using webApitest.Models.DTOs;
using webApitest.Services;
using System.Security.Claims;
using System.Text.Json;
using Microsoft.AspNetCore.RateLimiting;

namespace webApitest.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserDashboardController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<UserDashboardController> _logger;
        private readonly IDocumentExtractionService _documentExtractionService;
        private readonly IDocumentProcessingService _documentProcessingService;

        public UserDashboardController(ApplicationDbContext context, ILogger<UserDashboardController> logger, IDocumentExtractionService documentExtractionService, IDocumentProcessingService documentProcessingService)
        {
            _context = context;
            _logger = logger;
            _documentExtractionService = documentExtractionService;
            _documentProcessingService = documentProcessingService;
        }

        // Get current user ID from JWT token
        private int GetCurrentUserId()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (int.TryParse(userIdClaim, out int userId))
                return userId;
            throw new UnauthorizedAccessException("Invalid user token");
        }

        // 1. Profile Overview - Get user profile
        [HttpGet("profile")]
        public async Task<ActionResult<UserProfileDto>> GetProfile()
        {
            try
            {
                var userId = GetCurrentUserId();
                var user = await _context.Users.FindAsync(userId);
                
                if (user == null)
                    return NotFound("User not found");

                var profile = new UserProfileDto
                {
                    Id = user.Id,
                    FullName = user.FullName,
                    Email = user.Email,
                    Phone = user.Phone,
                    City = user.City,
                    State = user.State,
                    Pincode = user.Pincode,
                    Role = user.Role,
                    CreatedAt = user.CreatedAt,
                    UpdatedAt = user.UpdatedAt
                };

                return Ok(profile);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting user profile");
                return StatusCode(500, "Internal server error");
            }
        }

        // 2. Update Profile - Users can update personal details before document submission
        [HttpPut("profile")]
        public async Task<ActionResult> UpdateProfile([FromBody] UpdateUserProfileDto updateDto)
        {
            try
            {
                var userId = GetCurrentUserId();
                var user = await _context.Users.FindAsync(userId);
                
                if (user == null)
                    return NotFound("User not found");

                // Allow profile updates even after document submission
                // Users should be able to update their contact information

                // Update user details
                user.FullName = updateDto.FullName;
                user.Phone = updateDto.Phone;
                user.City = updateDto.City;
                user.State = updateDto.State;
                user.Pincode = updateDto.Pincode;
                user.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();

                // Log activity
                await LogUserActivity(userId, "Profile Updated", "User updated their profile information");

                return Ok(new { message = "Profile updated successfully" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating user profile");
                return StatusCode(500, new { message = "Internal server error", details = ex.Message });
            }
        }

        // 3. Change Password
        [HttpPut("change-password")]
        public async Task<ActionResult> ChangePassword([FromBody] ChangePasswordDto changePasswordDto)
        {
            try
            {
                var userId = GetCurrentUserId();
                var user = await _context.Users.FindAsync(userId);
                
                if (user == null)
                    return NotFound("User not found");

                // Verify current password
                if (!BCrypt.Net.BCrypt.Verify(changePasswordDto.CurrentPassword, user.PasswordHash))
                    return BadRequest("Current password is incorrect");

                // Update password
                user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(changePasswordDto.NewPassword);
                user.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();

                // Log activity
                await LogUserActivity(userId, "Password Changed", "User changed their password");

                return Ok(new { message = "Password changed successfully" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error changing password");
                return StatusCode(500, new { message = "Internal server error", details = ex.Message });
            }
        }

        // 3. Document Upload - One-time submission
        [HttpPost("upload-documents")]
        public async Task<ActionResult> UploadDocuments([FromForm] DocumentUploadDto uploadDto)
        {
            try
            {
                var userId = GetCurrentUserId();
                
                // Check if documents already submitted
                var existingUpload = await _context.UserUploadedDocuments
                    .FirstOrDefaultAsync(ud => ud.UserId == userId);

                // Allow second round submissions - just warn the user
                if (existingUpload != null && existingUpload.IsSubmitted)
                {
                    // Log that user is submitting second round
                    await LogUserActivity(userId, "Second Round Upload", "User submitted second round of documents");
                }

                // Validate files
                if (uploadDto.EC == null || uploadDto.Aadhaar == null || uploadDto.PAN == null)
                    return BadRequest("All three documents (EC, Aadhaar, PAN) are required");

                // Enhanced file validation with size and MIME type checks
                if (!IsValidFile(uploadDto.EC, ".pdf", "application/pdf"))
                    return BadRequest("EC document must be a valid PDF file (max 10MB).");
                if (!IsValidFile(uploadDto.Aadhaar, ".png", "image/png"))
                    return BadRequest("Aadhaar document must be a valid PNG file (max 10MB).");
                if (!IsValidFile(uploadDto.PAN, ".png", "image/png"))
                    return BadRequest("PAN document must be a valid PNG file (max 10MB).");

                // Create uploads directory if not exists
                var uploadsPath = Path.Combine(Directory.GetCurrentDirectory(), "Uploads", "UserDocuments", userId.ToString());
                Directory.CreateDirectory(uploadsPath);

                // Save files with correct extensions
                var ecPath = Path.Combine(uploadsPath, $"EC_{DateTime.UtcNow:yyyyMMddHHmmss}.pdf");
                var aadhaarPath = Path.Combine(uploadsPath, $"Aadhaar_{DateTime.UtcNow:yyyyMMddHHmmss}.png");
                var panPath = Path.Combine(uploadsPath, $"PAN_{DateTime.UtcNow:yyyyMMddHHmmss}.png");

                using (var stream = new FileStream(ecPath, FileMode.Create))
                    await uploadDto.EC.CopyToAsync(stream);

                using (var stream = new FileStream(aadhaarPath, FileMode.Create))
                    await uploadDto.Aadhaar.CopyToAsync(stream);

                using (var stream = new FileStream(panPath, FileMode.Create))
                    await uploadDto.PAN.CopyToAsync(stream);

                // Create or update UserUploadedDocuments record
                if (existingUpload == null)
                {
                    existingUpload = new UserUploadedDocuments
                    {
                        UserId = userId,
                        ECPath = ecPath,
                        AadhaarPath = aadhaarPath,
                        PANPath = panPath,
                        IsSubmitted = true,
                        SubmittedAt = DateTime.UtcNow
                    };
                    _context.UserUploadedDocuments.Add(existingUpload);
                }
                else
                {
                    // Second round submission - reset verification status
                    existingUpload.ECPath = ecPath;
                    existingUpload.AadhaarPath = aadhaarPath;
                    existingUpload.PANPath = panPath;
                    existingUpload.IsSubmitted = true;
                    existingUpload.SubmittedAt = DateTime.UtcNow;
                    
                    // Reset verification data for new submission
                    existingUpload.IsVerified = false;
                    existingUpload.RiskScore = 0;
                    existingUpload.VerificationNotes = null;
                    existingUpload.ExtractedData = null;
                    existingUpload.FieldMismatches = null;
                    existingUpload.UpdatedAt = DateTime.UtcNow;
                }

                await _context.SaveChangesAsync();

                // Documents uploaded successfully - extraction will be triggered by admin
                _logger.LogInformation($"Documents uploaded successfully for upload ID: {existingUpload.Id}. Files saved to: EC={existingUpload.ECPath}, Aadhaar={existingUpload.AadhaarPath}, PAN={existingUpload.PANPath}");

                // Log activity
                var isSecondRound = existingUpload != null && existingUpload.UpdatedAt.HasValue;
                var activityMessage = isSecondRound ? 
                    "User submitted second round of documents (EC, Aadhaar, PAN)" : 
                    "User uploaded EC, Aadhaar, and PAN documents";
                
                await LogUserActivity(userId, "Document Upload", activityMessage);

                var responseMessage = isSecondRound ? 
                    "Second round documents submitted successfully. Admin will process extraction." :
                    "Documents submitted successfully. Admin will process extraction.";

                return Ok(new { message = responseMessage, isSecondRound = isSecondRound });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error uploading documents");
                return StatusCode(500, "Internal server error");
            }
        }

        // 4. Get Document Status
        [HttpGet("document-status")]
        public async Task<ActionResult<DocumentStatusDto>> GetDocumentStatus()
        {
            try
            {
                var userId = GetCurrentUserId();
                var upload = await _context.UserUploadedDocuments
                    .FirstOrDefaultAsync(ud => ud.UserId == userId);

                if (upload == null)
                    return NotFound("No documents uploaded");

                var status = new DocumentStatusDto
                {
                    Id = upload.Id,
                    IsSubmitted = upload.IsSubmitted,
                    IsVerified = upload.IsVerified,
                    RiskScore = upload.RiskScore,
                    VerificationNotes = upload.VerificationNotes,
                    FieldMismatches = upload.FieldMismatches,
                    SubmittedAt = upload.SubmittedAt,
                    CreatedAt = upload.CreatedAt
                };

                return Ok(status);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting document status");
                return StatusCode(500, "Internal server error");
            }
        }

        // 5. Get Extracted Data (if available)
        [HttpGet("extracted-data")]
        public async Task<ActionResult<ExtractedDataDto>> GetExtractedData()
        {
            try
            {
                var userId = GetCurrentUserId();
                var upload = await _context.UserUploadedDocuments
                    .FirstOrDefaultAsync(ud => ud.UserId == userId);

                if (upload == null || string.IsNullOrEmpty(upload.ExtractedData))
                    return NotFound("No extracted data available");

                var extractedData = JsonSerializer.Deserialize<ExtractedDataDto>(upload.ExtractedData);
                return Ok(extractedData);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting extracted data");
                return StatusCode(500, "Internal server error");
            }
        }

        // 6. Trigger Verification
        [HttpPost("verify-documents")]
        public async Task<ActionResult> VerifyDocuments()
        {
            try
            {
                var userId = GetCurrentUserId();
                var upload = await _context.UserUploadedDocuments
                    .FirstOrDefaultAsync(ud => ud.UserId == userId);

                if (upload == null)
                    return NotFound("No documents uploaded");

                if (!upload.IsSubmitted)
                    return BadRequest("Documents not yet submitted");

                // Call DLL verification function
                await CallDLLVerification(upload.Id);

                // Log activity
                await LogUserActivity(userId, "Document Verification", "User triggered document verification");

                return Ok(new { message = "Verification process initiated" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error verifying documents");
                return StatusCode(500, "Internal server error");
            }
        }

        // 7. Get Upload History
        [HttpGet("upload-history")]
        public async Task<ActionResult> GetUploadHistory()
        {
            try
            {
                var userId = GetCurrentUserId();
                var uploads = await _context.UserUploadedDocuments
                    .Where(ud => ud.UserId == userId)
                    .OrderByDescending(ud => ud.CreatedAt)
                    .Select(ud => new
                    {
                        ud.Id,
                        ud.IsSubmitted,
                        ud.IsVerified,
                        ud.RiskScore,
                        ud.SubmittedAt,
                        ud.CreatedAt
                    })
                    .ToListAsync();

                return Ok(uploads);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting upload history");
                return StatusCode(500, "Internal server error");
            }
        }

        // Helper method to call DLL verification
        private async Task CallDLLVerification(int uploadId)
        {
            try
            {
                var result = await _documentExtractionService.VerifyDocumentsAsync(uploadId);
                
                var upload = await _context.UserUploadedDocuments.FindAsync(uploadId);
                if (upload != null)
                {
                    upload.IsVerified = result.IsVerified;
                    upload.RiskScore = result.RiskScore;
                    upload.VerificationNotes = result.VerificationNotes;
                    upload.FieldMismatches = result.FieldMismatches;
                    upload.UpdatedAt = DateTime.UtcNow;
                    
                    await _context.SaveChangesAsync();
                }

                _logger.LogInformation($"Successfully verified documents for upload {uploadId}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error verifying documents for upload {uploadId}");
            }
        }

        // Enhanced file validation method
        private bool IsValidFile(IFormFile file, string expectedExtension, string expectedMimeType)
        {
            if (file == null || file.Length == 0)
                return false;

            // Check file size (10MB limit)
            if (file.Length > 10 * 1024 * 1024)
                return false;

            // Check file extension
            var extension = Path.GetExtension(file.FileName).ToLower();
            if (extension != expectedExtension)
                return false;

            // Check MIME type
            if (file.ContentType != expectedMimeType)
                return false;

            // Additional security: Check for suspicious file names
            var fileName = Path.GetFileName(file.FileName);
            if (string.IsNullOrEmpty(fileName) || fileName.Contains("..") || fileName.Contains("/") || fileName.Contains("\\"))
                return false;

            return true;
        }

        // Test endpoint to check database connection
        [HttpGet("test-db-connection")]
        public async Task<ActionResult> TestDatabaseConnection()
        {
            try
            {
                // Test UserUploadedDocuments table
                var userUploadsCount = await _context.UserUploadedDocuments.CountAsync();
                
                // Test ExtractedDataDocuments table
                var extractedDataCount = await _context.ExtractedDataDocuments.CountAsync();
                
                return Ok(new { 
                    message = "Database connection successful",
                    userUploadsCount = userUploadsCount,
                    extractedDataCount = extractedDataCount,
                    timestamp = DateTime.UtcNow
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Database connection test failed");
                return StatusCode(500, new { 
                    message = "Database connection failed", 
                    error = ex.Message 
                });
            }
        }

        // Test endpoint to manually trigger document processing
        [HttpPost("test-document-processing/{uploadId}")]
        public async Task<ActionResult> TestDocumentProcessing(int uploadId)
        {
            try
            {
                _logger.LogInformation($"Manual test of document processing for upload ID: {uploadId}");
                
                // First check if upload exists and get file paths
                var upload = await _context.UserUploadedDocuments.FindAsync(uploadId);
                if (upload == null)
                {
                    return Ok(new { 
                        message = "Upload record not found",
                        uploadId = uploadId,
                        timestamp = DateTime.UtcNow
                    });
                }
                
                // Check file existence
                var fileChecks = new
                {
                    ECPath = upload.ECPath,
                    ECPathExists = !string.IsNullOrEmpty(upload.ECPath) && System.IO.File.Exists(upload.ECPath),
                    AadhaarPath = upload.AadhaarPath,
                    AadhaarPathExists = !string.IsNullOrEmpty(upload.AadhaarPath) && System.IO.File.Exists(upload.AadhaarPath),
                    PANPath = upload.PANPath,
                    PANPathExists = !string.IsNullOrEmpty(upload.PANPath) && System.IO.File.Exists(upload.PANPath)
                };
                
                _logger.LogInformation($"File existence check: {System.Text.Json.JsonSerializer.Serialize(fileChecks)}");
                
                // Test extraction
                var extractionSuccess = await _documentProcessingService.ProcessDocumentExtractionAsync(uploadId);
                _logger.LogInformation($"Extraction result: {extractionSuccess}");
                
                if (extractionSuccess)
                {
                    // Test verification
                    var verificationSuccess = await _documentProcessingService.ProcessDocumentVerificationAsync(uploadId);
                    _logger.LogInformation($"Verification result: {verificationSuccess}");
                }
                
                return Ok(new { 
                    message = "Document processing test completed",
                    extractionSuccess = extractionSuccess,
                    uploadId = uploadId,
                    fileChecks = fileChecks,
                    timestamp = DateTime.UtcNow
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Document processing test failed");
                return StatusCode(500, new { 
                    message = "Document processing test failed", 
                    error = ex.Message,
                    stackTrace = ex.StackTrace
                });
            }
        }

        /// <summary>
        /// Comprehensive document saving method with robust error handling
        /// </summary>
        [HttpPost("save-extracted-data/{uploadId}")]
        public async Task<ActionResult> SaveExtractedData(int uploadId, [FromBody] ExtractedDataDto extractedData)
        {
            try
            {
                _logger.LogInformation($"Saving extracted data for upload ID: {uploadId}");

                // Validate input
                if (extractedData == null)
                {
                    _logger.LogWarning("Extracted data is null");
                    return BadRequest("Extracted data cannot be null");
                }

                // Get the upload record
                var upload = await _context.UserUploadedDocuments.FindAsync(uploadId);
                if (upload == null)
                {
                    _logger.LogWarning($"Upload record not found for ID: {uploadId}");
                    return NotFound("Upload record not found");
                }

                // Ensure required fields are set
                if (upload.UserId <= 0)
                {
                    _logger.LogError($"Invalid UserId for upload {uploadId}: {upload.UserId}");
                    return BadRequest("Invalid UserId");
                }

                // Use the document processing service to save data
                var success = await _documentProcessingService.ProcessDocumentExtractionAsync(uploadId);
                
                if (success)
                {
                    _logger.LogInformation($"Successfully saved extracted data for upload {uploadId}");
                    return Ok(new { 
                        message = "Extracted data saved successfully",
                        uploadId = uploadId,
                        timestamp = DateTime.UtcNow
                    });
                }
                else
                {
                    _logger.LogError($"Failed to save extracted data for upload {uploadId}");
                    return StatusCode(500, "Failed to save extracted data");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error saving extracted data for upload {uploadId}");
                return StatusCode(500, new { 
                    message = "Internal server error", 
                    error = ex.Message 
                });
            }
        }

        // This method has been replaced by DocumentProcessingService
        // The extraction and verification logic is now handled by:
        // 1. ProcessDocumentExtractionAsync() - Extracts data using DLL
        // 2. ProcessDocumentVerificationAsync() - Verifies extracted data

        // Helper method to log user activity
        private async Task LogUserActivity(int userId, string activity, string description)
        {
            try
            {
                var activityLog = new UserActivityLog
                {
                    UserId = userId,
                    Activity = activity,
                    Description = description,
                    IPAddress = HttpContext.Connection.RemoteIpAddress?.ToString(),
                    UserAgent = HttpContext.Request.Headers["User-Agent"].ToString()
                };

                _context.UserActivityLogs.Add(activityLog);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error logging user activity");
            }
        }

        // 7. Document Processing Status - Get real-time processing status
        [HttpGet("processing-status/{documentId}")]
        public async Task<ActionResult<object>> GetProcessingStatus(int documentId)
        {
            try
            {
                var userId = GetCurrentUserId();
                var document = await _context.UserUploadedDocuments
                    .Where(u => u.Id == documentId && u.UserId == userId)
                    .Select(u => new
                    {
                        u.Id,
                        u.SubmittedAt,
                        u.IsVerified,
                        u.RiskScore,
                        u.VerificationNotes,
                        ProcessingStatus = u.IsVerified ? "Completed" : "Processing",
                            EstimatedCompletion = u.IsVerified ? (DateTime?)null : DateTime.UtcNow.AddMinutes(5)
                    })
                    .FirstOrDefaultAsync();

                if (document == null)
                    return NotFound("Document not found");

                return Ok(document);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching processing status");
                return StatusCode(500, "Internal server error");
            }
        }
    }
}

namespace webApitest.Models.DTOs
{
    public class VerificationResultDto
    {
        public bool IsVerified { get; set; }
        public int RiskScore { get; set; }
        public string VerificationNotes { get; set; } = string.Empty;
        public string FieldMismatches { get; set; } = string.Empty;
        public double? Latitude { get; set; }
        public double? Longitude { get; set; }
    }
}

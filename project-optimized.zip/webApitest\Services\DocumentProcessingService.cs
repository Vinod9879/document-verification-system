using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using webApitest.Models;
using webApitest.Models.DTOs;
using webApitest.Data;
using DocumentVerificationDLL;

namespace webApitest.Services
{
    public interface IDocumentProcessingService
    {
        Task<bool> ProcessDocumentExtractionAsync(int uploadId);
        Task<bool> ProcessDocumentVerificationAsync(int uploadId);
        Task<ExtractedDataDto> ExtractDataFromDocumentsAsync(int uploadId);
    }

    public class DocumentProcessingService : IDocumentProcessingService
    {
        private readonly ApplicationDbContext _context;
        private readonly IDocumentExtractionService _documentExtractionService;
        private readonly ILogger<DocumentProcessingService> _logger;

        public DocumentProcessingService(
            ApplicationDbContext context,
            IDocumentExtractionService documentExtractionService,
            ILogger<DocumentProcessingService> logger)
        {
            _context = context;
            _documentExtractionService = documentExtractionService;
            _logger = logger;
        }

        /// <summary>
        /// Step 1: Extract data from documents using DLL with robust error handling
        /// </summary>
        public async Task<bool> ProcessDocumentExtractionAsync(int uploadId)
        {
            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                _logger.LogInformation($"Starting document extraction for upload ID: {uploadId}");

                // Get the upload record with proper null checking
                var upload = await _context.UserUploadedDocuments.FindAsync(uploadId);
                if (upload == null)
                {
                    _logger.LogWarning($"Upload record not found for ID: {uploadId}");
                    return false;
                }

                _logger.LogInformation($"Found upload record. UserId: {upload.UserId}, EC: {upload.ECPath}, Aadhaar: {upload.AadhaarPath}, PAN: {upload.PANPath}");

                // Extract data from all documents
                var extractedData = await ExtractDataFromDocumentsAsync(uploadId);
                if (extractedData == null)
                {
                    _logger.LogError("Failed to extract data from documents");
                    return false;
                }

                _logger.LogInformation($"Extracted data: Name={extractedData.Name}, ApplicationNumber={extractedData.ApplicationNumber}, AadhaarNumber={extractedData.AadhaarNumber}, PANNumber={extractedData.PANNumber}");

                // Save extracted data to UserUploadedDocuments with proper field mappings
                await SaveExtractedDataToUserUploadedDocuments(upload, extractedData);

                // Save to ExtractedDataDocuments table for admin view
                var extractedDataDocumentId = await SaveExtractedDataToExtractedDataDocuments(uploadId, extractedData);

                // CRITICAL: Save changes to database
                await _context.SaveChangesAsync();


                // Commit transaction
                await transaction.CommitAsync();

                _logger.LogInformation($"Successfully extracted and saved data for upload {uploadId}. ExtractedDataDocuments ID: {extractedDataDocumentId}");
                return true;
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                _logger.LogError(ex, $"Error in document extraction for upload {uploadId}");
                return false;
            }
        }

        /// <summary>
        /// Save extracted data to UserUploadedDocuments table with proper field mappings
        /// </summary>
        private async Task SaveExtractedDataToUserUploadedDocuments(UserUploadedDocuments upload, ExtractedDataDto extractedData)
        {
            try
            {
                _logger.LogInformation($"Saving extracted data to UserUploadedDocuments for upload {upload.Id}");

                // Ensure required fields are set
                if (upload.UserId <= 0)
                {
                    _logger.LogError($"Invalid UserId for upload {upload.Id}: {upload.UserId}");
                    throw new InvalidOperationException($"Invalid UserId for upload {upload.Id}");
                }

                // Map EC fields
                upload.ApplicationNumber = extractedData.ApplicationNumber ?? upload.ApplicationNumber;
                upload.ApplicantAddress = extractedData.Address ?? upload.ApplicantAddress;
                upload.SurveyNo = extractedData.SurveyNumber ?? upload.SurveyNo;
                upload.MeasuringArea = extractedData.MeasuringArea ?? upload.MeasuringArea;
                upload.Village = extractedData.Village ?? upload.Village;
                upload.Hobli = extractedData.Hobli ?? upload.Hobli;
                upload.Taluk = extractedData.Taluk ?? upload.Taluk;
                upload.District = extractedData.District ?? upload.District;

                // Map Aadhaar fields (get name from Aadhaar extraction)
                if (!string.IsNullOrEmpty(upload.AadhaarPath))
                {
                    try
                    {
                        var aadhaarData = await _documentExtractionService.ExtractAadhaarAsync(upload.AadhaarPath);
                        upload.AdhaarFullName = aadhaarData?.Name ?? upload.AdhaarFullName;
                        _logger.LogInformation($"Extracted Aadhaar name: {aadhaarData?.Name}");
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, $"Failed to extract Aadhaar name for upload {upload.Id}");
                    }
                }
                upload.AdhaarNo = extractedData.AadhaarNumber ?? upload.AdhaarNo;

                // Map PAN fields (get name from PAN extraction)
                if (!string.IsNullOrEmpty(upload.PANPath))
                {
                    try
                    {
                        var panData = await _documentExtractionService.ExtractPANAsync(upload.PANPath);
                        upload.PanFullName = panData?.Name ?? upload.PanFullName;
                        _logger.LogInformation($"Extracted PAN name: {panData?.Name}");
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, $"Failed to extract PAN name for upload {upload.Id}");
                    }
                }
                upload.PanNo = extractedData.PANNumber ?? upload.PanNo;
                upload.Dob = extractedData.DOB ?? upload.Dob;

                // General name field (use from any document that has it)
                upload.Name = extractedData.Name ?? upload.Name ?? "Unknown";

                // Serialize and save ExtractedData JSON
                try
                {
                    var extractedDataJson = JsonSerializer.Serialize(extractedData, new JsonSerializerOptions
                    {
                        WriteIndented = false,
                        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                    });
                    upload.ExtractedData = extractedDataJson;
                    _logger.LogInformation($"Serialized ExtractedData JSON: {extractedDataJson.Length} characters");
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, $"Failed to serialize ExtractedData for upload {upload.Id}");
                    upload.ExtractedData = "{}"; // Fallback to empty JSON
                }

                // Update timestamps
                upload.UpdatedAt = DateTime.UtcNow;
                if (upload.CreatedAt == default)
                {
                    upload.CreatedAt = DateTime.UtcNow;
                }

                _logger.LogInformation($"Updated UserUploadedDocuments for upload {upload.Id}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error saving extracted data to UserUploadedDocuments for upload {upload.Id}");
                throw;
            }
        }

        /// <summary>
        /// Save extracted data to ExtractedDataDocuments table
        /// </summary>
        private async Task<int> SaveExtractedDataToExtractedDataDocuments(int uploadId, ExtractedDataDto extractedData)
        {
            try
            {
                _logger.LogInformation($"Saving extracted data to ExtractedDataDocuments for upload {uploadId}");

                // Check if record already exists
                var existingRecord = await _context.ExtractedDataDocuments
                    .FirstOrDefaultAsync(ed => ed.Id == uploadId);

                ExtractedDataDocuments extractedDataDocument;

                if (existingRecord != null)
                {
                    _logger.LogInformation($"Updating existing ExtractedDataDocuments record for upload {uploadId}");
                    extractedDataDocument = existingRecord;
                }
                else
                {
                    _logger.LogInformation($"Creating new ExtractedDataDocuments record for upload {uploadId}");
                    extractedDataDocument = new ExtractedDataDocuments();
                    _context.ExtractedDataDocuments.Add(extractedDataDocument);
                }

                // Map all fields with null safety
                extractedDataDocument.ApplicationNumber = extractedData.ApplicationNumber ?? extractedDataDocument.ApplicationNumber;
                extractedDataDocument.Name = extractedData.Name ?? extractedDataDocument.Name ?? "Unknown";
                extractedDataDocument.Address = extractedData.Address ?? extractedDataDocument.Address;
                extractedDataDocument.SurveyNumber = extractedData.SurveyNumber ?? extractedDataDocument.SurveyNumber;
                extractedDataDocument.MeasuringArea = extractedData.MeasuringArea ?? extractedDataDocument.MeasuringArea;
                extractedDataDocument.Village = extractedData.Village ?? extractedDataDocument.Village;
                extractedDataDocument.Hobli = extractedData.Hobli ?? extractedDataDocument.Hobli;
                extractedDataDocument.Taluk = extractedData.Taluk ?? extractedDataDocument.Taluk;
                extractedDataDocument.District = extractedData.District ?? extractedDataDocument.District;
                extractedDataDocument.AadhaarNumber = extractedData.AadhaarNumber ?? extractedDataDocument.AadhaarNumber;
                extractedDataDocument.PANNumber = extractedData.PANNumber ?? extractedDataDocument.PANNumber;

                // Parse DOB safely
                if (!string.IsNullOrEmpty(extractedData.DOB))
                {
                    if (DateTime.TryParse(extractedData.DOB, out var dob))
                    {
                        extractedDataDocument.DOB = dob;
                    }
                    else
                    {
                        _logger.LogWarning($"Invalid DOB format: {extractedData.DOB}");
                    }
                }

                // Set timestamps
                var now = DateTime.UtcNow;
                if (extractedDataDocument.CreatedAt == default)
                {
                    extractedDataDocument.CreatedAt = now;
                }
                extractedDataDocument.UpdatedAt = now;

                // Don't call SaveChangesAsync here - it will be called in the main method
                _logger.LogInformation($"Prepared ExtractedDataDocuments for saving with ID: {extractedDataDocument.Id}");
                return extractedDataDocument.Id;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error saving extracted data to ExtractedDataDocuments for upload {uploadId}");
                throw;
            }
        }

        /// <summary>
        /// Step 2: Verify extracted data for consistency and accuracy
        /// </summary>
        public async Task<bool> ProcessDocumentVerificationAsync(int uploadId)
        {
            try
            {
                _logger.LogInformation($"Starting document verification for upload ID: {uploadId}");

                var upload = await _context.UserUploadedDocuments.FindAsync(uploadId);
                if (upload == null)
                {
                    _logger.LogWarning($"Upload record not found for ID: {uploadId}");
                    return false;
                }

                // Parse extracted data
                var extractedData = System.Text.Json.JsonSerializer.Deserialize<ExtractedDataDto>(upload.ExtractedData ?? "{}");
                if (extractedData == null)
                {
                    _logger.LogWarning("No extracted data found for verification");
                    return false;
                }

                // Perform verification logic
                var verificationResult = await PerformDataVerification(extractedData);
                
                // Update verification status
                upload.IsVerified = verificationResult.Status == "Valid";
                upload.RiskScore = (int)verificationResult.RiskScore;
                upload.VerificationNotes = $"Verification completed. Status: {verificationResult.Status}";
                upload.FieldMismatches = string.Join("; ", verificationResult.Mismatches);
                upload.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();

                _logger.LogInformation($"Verification completed for upload {uploadId}. Status: {verificationResult.Status}, Risk: {verificationResult.RiskScore}");
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error in document verification for upload {uploadId}");
                return false;
            }
        }

        /// <summary>
        /// Extract data from all documents using DLL
        /// </summary>
        public async Task<ExtractedDataDto> ExtractDataFromDocumentsAsync(int uploadId)
        {
            try
            {
                var upload = await _context.UserUploadedDocuments.FindAsync(uploadId);
                if (upload == null) return null;

                var extractedData = new ExtractedDataDto();
                string? ecName = null, aadhaarName = null, panName = null;

                // Extract from EC document (PDF)
                if (!string.IsNullOrEmpty(upload.ECPath))
                {
                    _logger.LogInformation($"Checking EC document path: {upload.ECPath}");
                    _logger.LogInformation($"EC file exists: {System.IO.File.Exists(upload.ECPath)}");
                    
                    if (System.IO.File.Exists(upload.ECPath))
                    {
                        _logger.LogInformation($"Extracting EC document: {upload.ECPath}");
                        var ecData = await _documentExtractionService.ExtractECAsync(upload.ECPath);
                        
                        // Map EC-specific fields
                        extractedData.ApplicationNumber = ecData.ApplicationNumber;
                        extractedData.Address = ecData.Address;
                        extractedData.SurveyNumber = ecData.SurveyNumber;
                        extractedData.MeasuringArea = ecData.MeasuringArea;
                        extractedData.Village = ecData.Village;
                        extractedData.Hobli = ecData.Hobli;
                        extractedData.Taluk = ecData.Taluk;
                        extractedData.District = ecData.District;
                        ecName = ecData.Name;
                        
                        _logger.LogInformation($"EC extraction completed. ApplicationNumber: {ecData.ApplicationNumber}");
                    }
                    else
                    {
                        _logger.LogError($"EC file not found at path: {upload.ECPath}");
                    }
                }

                // Extract from Aadhaar document (PNG)
                if (!string.IsNullOrEmpty(upload.AadhaarPath))
                {
                    _logger.LogInformation($"Checking Aadhaar document path: {upload.AadhaarPath}");
                    _logger.LogInformation($"Aadhaar file exists: {System.IO.File.Exists(upload.AadhaarPath)}");
                    
                    if (System.IO.File.Exists(upload.AadhaarPath))
                    {
                        _logger.LogInformation($"Extracting Aadhaar document: {upload.AadhaarPath}");
                        var aadhaarData = await _documentExtractionService.ExtractAadhaarAsync(upload.AadhaarPath);
                        
                        // Map Aadhaar-specific fields
                        extractedData.AadhaarNumber = aadhaarData.AadhaarNumber;
                        aadhaarName = aadhaarData.Name;
                        
                        _logger.LogInformation($"Aadhaar extraction completed. AadhaarNumber: {aadhaarData.AadhaarNumber}");
                    }
                    else
                    {
                        _logger.LogError($"Aadhaar file not found at path: {upload.AadhaarPath}");
                    }
                }

                // Extract from PAN document (PNG)
                if (!string.IsNullOrEmpty(upload.PANPath))
                {
                    _logger.LogInformation($"Checking PAN document path: {upload.PANPath}");
                    _logger.LogInformation($"PAN file exists: {System.IO.File.Exists(upload.PANPath)}");
                    
                    if (System.IO.File.Exists(upload.PANPath))
                    {
                        _logger.LogInformation($"Extracting PAN document: {upload.PANPath}");
                        var panData = await _documentExtractionService.ExtractPANAsync(upload.PANPath);
                        
                        // Map PAN-specific fields
                        extractedData.PANNumber = panData.PANNumber;
                        extractedData.DOB = panData.DOB;
                        panName = panData.Name;
                        
                        _logger.LogInformation($"PAN extraction completed. PANNumber: {panData.PANNumber}");
                    }
                    else
                    {
                        _logger.LogError($"PAN file not found at path: {upload.PANPath}");
                    }
                }

                // Use the first available name (priority: EC > Aadhaar > PAN)
                extractedData.Name = ecName ?? aadhaarName ?? panName ?? "Unknown";

                return extractedData;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error extracting data from documents for upload {uploadId}");
                return null;
            }
        }

        /// <summary>
        /// Perform data verification and validation
        /// </summary>
        private async Task<VerificationResult> PerformDataVerification(ExtractedDataDto extractedData)
        {
            var result = new VerificationResult();
            var mismatches = new List<string>();

            // Verify name consistency across documents
            if (!string.IsNullOrEmpty(extractedData.Name))
            {
                result.Status = "Valid";
            }
            else
            {
                mismatches.Add("Name not found in any document");
                result.Status = "Invalid";
            }

            // Verify Aadhaar number format
            if (!string.IsNullOrEmpty(extractedData.AadhaarNumber))
            {
                if (extractedData.AadhaarNumber.Length != 12 || !extractedData.AadhaarNumber.All(char.IsDigit))
                {
                    mismatches.Add("Invalid Aadhaar number format");
                    result.Status = "Invalid";
                }
            }

            // Verify PAN number format
            if (!string.IsNullOrEmpty(extractedData.PANNumber))
            {
                if (extractedData.PANNumber.Length != 10)
                {
                    mismatches.Add("Invalid PAN number format");
                    result.Status = "Invalid";
                }
            }

            // Calculate risk score based on data quality
            result.RiskScore = CalculateRiskScore(extractedData, mismatches);
            result.Mismatches = mismatches;

            return result;
        }

        /// <summary>
        /// Calculate risk score based on data quality
        /// </summary>
        private decimal CalculateRiskScore(ExtractedDataDto extractedData, List<string> mismatches)
        {
            decimal riskScore = 0;

            // Base risk for missing data
            if (string.IsNullOrEmpty(extractedData.Name)) riskScore += 30;
            if (string.IsNullOrEmpty(extractedData.AadhaarNumber)) riskScore += 25;
            if (string.IsNullOrEmpty(extractedData.PANNumber)) riskScore += 25;
            if (string.IsNullOrEmpty(extractedData.ApplicationNumber)) riskScore += 20;

            // Additional risk for mismatches
            riskScore += mismatches.Count * 5;

            return Math.Min(riskScore, 100);
        }
    }

    /// <summary>
    /// Result of document verification (using existing VerificationResult from DocumentExtractionService)
    /// </summary>
}

using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using webApitest.Data;
using webApitest.Models;
using webApitest.Models.DTOs;
using webApitest.DTOs;
using webApitest.Services;
using System.Security.Claims;
using System.Text.Json;

namespace webApitest.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AdminDashboardController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<AdminDashboardController> _logger;
        private readonly IDocumentExtractionService _documentExtractionService;
        private readonly IDocumentProcessingService _documentProcessingService;
        private readonly IDocumentVerificationService _documentVerificationService;
        

        public AdminDashboardController(ApplicationDbContext context, ILogger<AdminDashboardController> logger, IDocumentExtractionService documentExtractionService, IDocumentProcessingService documentProcessingService, IDocumentVerificationService documentVerificationService)
        {
            _context = context;
            _logger = logger;
            _documentExtractionService = documentExtractionService;
            _documentProcessingService = documentProcessingService;
            _documentVerificationService = documentVerificationService;
        }

        // Get current user ID from JWT token
        private int GetCurrentUserId()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (int.TryParse(userIdClaim, out int userId))
                return userId;
            throw new UnauthorizedAccessException("Invalid user token");
        }

        // Check if current user is admin
        private async Task<bool> IsAdminUser()
        {
            var userId = GetCurrentUserId();
            var user = await _context.Users.FindAsync(userId);
            return user?.Role == "Admin";
        }

        // 1. User Management - Get all users
        [HttpGet("users")]
        public async Task<ActionResult> GetAllUsers([FromQuery] int page = 1, [FromQuery] int pageSize = 10)
        {
            try
            {
                if (!await IsAdminUser())
                    return Forbid("Admin access required");

                var users = await _context.Users
                    .OrderByDescending(u => u.CreatedAt)
                    .Skip((page - 1) * pageSize)
                    .Take(pageSize)
                    .Select(u => new
                    {
                        u.Id,
                        u.FullName,
                        u.Email,
                        u.Phone,
                        u.City,
                        u.State,
                        u.Pincode,
                        u.Role,
                        u.CreatedAt,
                        u.UpdatedAt,
                        HasUploadedDocuments = _context.UserUploadedDocuments.Any(ud => ud.UserId == u.Id)
                    })
                    .ToListAsync();

                var totalUsers = await _context.Users.CountAsync();

                return Ok(new
                {
                    users,
                    totalUsers,
                    page,
                    pageSize,
                    totalPages = (int)Math.Ceiling((double)totalUsers / pageSize)
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting all users");
                return StatusCode(500, "Internal server error");
            }
        }

        // 2. Get specific user details
        [HttpGet("users/{userId}")]
        public async Task<ActionResult> GetUserDetails(int userId)
        {
            try
            {
                if (!await IsAdminUser())
                    return Forbid("Admin access required");

                var user = await _context.Users
                    .Where(u => u.Id == userId)
                    .Select(u => new
                    {
                        u.Id,
                        u.FullName,
                        u.Email,
                        u.Phone,
                        u.City,
                        u.State,
                        u.Pincode,
                        u.Role,
                        u.CreatedAt,
                        u.UpdatedAt
                    })
                    .FirstOrDefaultAsync();

                if (user == null)
                    return NotFound("User not found");

                // Get user's uploaded documents
                var uploadedDocs = await _context.UserUploadedDocuments
                    .Where(ud => ud.UserId == userId)
                    .Select(ud => new
                    {
                        ud.Id,
                        ud.IsSubmitted,
                        ud.IsVerified,
                        ud.RiskScore,
                        ud.VerificationNotes,
                        ud.FieldMismatches,
                        ud.SubmittedAt,
                        ud.CreatedAt
                    })
                    .ToListAsync();

                // Get user activity logs
                var activityLogs = await _context.UserActivityLogs
                    .Where(al => al.UserId == userId)
                    .OrderByDescending(al => al.Timestamp)
                    .Take(10)
                    .Select(al => new
                    {
                        al.Id,
                        al.Activity,
                        al.Description,
                        al.Timestamp
                    })
                    .ToListAsync();

                return Ok(new
                {
                    user,
                    uploadedDocuments = uploadedDocs,
                    recentActivity = activityLogs
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting user details");
                return StatusCode(500, "Internal server error");
            }
        }

        // 3. Update user role
        [HttpPut("users/{userId}/role")]
        public async Task<ActionResult> UpdateUserRole(int userId, [FromBody] UpdateUserRoleDto roleDto)
        {
            try
            {
                if (!await IsAdminUser())
                    return Forbid("Admin access required");

                var user = await _context.Users.FindAsync(userId);
                if (user == null)
                    return NotFound("User not found");

                user.Role = roleDto.Role;
                user.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();

                // Log activity
                await LogAdminActivity($"Updated user {user.Email} role to {roleDto.Role}");

                return Ok(new { message = "User role updated successfully" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating user role");
                return StatusCode(500, "Internal server error");
            }
        }

        // 4. Update user details
        [HttpPut("users/{userId}")]
        public async Task<ActionResult> UpdateUser(int userId, [FromBody] UpdateUserDto updateDto)
        {
            try
            {
                if (!await IsAdminUser())
                    return Forbid("Admin access required");

                var user = await _context.Users.FindAsync(userId);
                if (user == null)
                    return NotFound("User not found");

                // Update user details
                user.FullName = updateDto.FullName;
                user.Email = updateDto.Email;
                user.Phone = updateDto.Phone;
                user.City = updateDto.City;
                user.State = updateDto.State;
                user.Pincode = updateDto.Pincode;
                user.Role = updateDto.Role;
                user.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();

                // Log activity
                await LogAdminActivity($"Updated user {user.Email} details");

                return Ok(new { message = "User updated successfully" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating user");
                return StatusCode(500, "Internal server error");
            }
        }

        // 5. Delete user
        [HttpDelete("users/{userId}")]
        public async Task<ActionResult> DeleteUser(int userId)
        {
            try
            {
                _logger.LogInformation($"Delete user request received for user ID: {userId}");
                
                if (!await IsAdminUser())
                {
                    _logger.LogWarning("Delete user request denied - not admin user");
                    return Forbid("Admin access required");
                }

                var user = await _context.Users.FindAsync(userId);
                if (user == null)
                {
                    _logger.LogWarning($"User not found with ID: {userId}");
                    return NotFound("User not found");
                }

                // Prevent admin from deleting themselves
                var currentUserId = GetCurrentUserId();
                if (userId == currentUserId)
                {
                    _logger.LogWarning($"Admin attempted to delete themselves: {userId}");
                    return BadRequest("Cannot delete your own account");
                }

                _logger.LogInformation($"Proceeding with deletion of user: {user.Email}");

                // Delete user's uploaded documents first (cascade delete)
                var userDocuments = await _context.UserUploadedDocuments
                    .Where(ud => ud.UserId == userId)
                    .ToListAsync();
                _context.UserUploadedDocuments.RemoveRange(userDocuments);

                // Delete user's activity logs
                var userActivityLogs = await _context.UserActivityLogs
                    .Where(al => al.UserId == userId)
                    .ToListAsync();
                _context.UserActivityLogs.RemoveRange(userActivityLogs);

                // Delete the user
                _context.Users.Remove(user);
                await _context.SaveChangesAsync();

                // Log activity
                await LogAdminActivity($"Deleted user {user.Email}");

                _logger.LogInformation($"User {user.Email} deleted successfully");
                return Ok(new { message = "User deleted successfully" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting user");
                return StatusCode(500, "Internal server error");
            }
        }

            // 6. Document Monitoring - Get all uploaded documents
        [HttpGet("documents")]
        public async Task<ActionResult> GetAllUploadedDocuments([FromQuery] int page = 1, [FromQuery] int pageSize = 10)
        {
            try
            {
                if (!await IsAdminUser())
                    return Forbid("Admin access required");

                var documents = await _context.UserUploadedDocuments
                    .Include(ud => ud.User)
                    .OrderByDescending(ud => ud.CreatedAt)
                    .Skip((page - 1) * pageSize)
                    .Take(pageSize)
                    .Select(ud => new
                    {
                        ud.Id,
                        UserId = ud.UserId,
                        UserName = ud.User.FullName,
                        UserEmail = ud.User.Email,
                        ud.IsSubmitted,
                        ud.IsVerified,
                        ud.RiskScore,
                        ud.VerificationNotes,
                        ud.SubmittedAt,
                        ud.CreatedAt,
                        HasEC = !string.IsNullOrEmpty(ud.ECPath),
                        HasAadhaar = !string.IsNullOrEmpty(ud.AadhaarPath),
                        HasPAN = !string.IsNullOrEmpty(ud.PANPath)
                    })
                    .ToListAsync();

                var totalDocuments = await _context.UserUploadedDocuments.CountAsync();

                return Ok(new
                {
                    documents,
                    totalDocuments,
                    page,
                    pageSize,
                    totalPages = (int)Math.Ceiling((double)totalDocuments / pageSize)
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting all uploaded documents");
                return StatusCode(500, "Internal server error");
            }
        }

            // 7. Get specific document details with extracted data
        [HttpGet("documents/{documentId}")]
        public async Task<ActionResult> GetDocumentDetails(int documentId)
        {
            try
            {
                if (!await IsAdminUser())
                    return Forbid("Admin access required");

                var document = await _context.UserUploadedDocuments
                    .Include(ud => ud.User)
                    .Where(ud => ud.Id == documentId)
                    .Select(ud => new
                    {
                        ud.Id,
                        UserId = ud.UserId,
                        UserName = ud.User.FullName,
                        UserEmail = ud.User.Email,
                        ud.ECPath,
                        ud.AadhaarPath,
                        ud.PANPath,
                        ud.ExtractedData,
                        ud.IsSubmitted,
                        ud.IsVerified,
                        ud.RiskScore,
                        ud.VerificationNotes,
                        ud.FieldMismatches,
                        ud.SubmittedAt,
                        ud.CreatedAt
                    })
                    .FirstOrDefaultAsync();

                if (document == null)
                    return NotFound("Document not found");

                return Ok(document);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting document details");
                return StatusCode(500, "Internal server error");
            }
        }

        // 8. Trigger verification for specific user
        [HttpPost("documents/{documentId}/verify")]
        public async Task<ActionResult> TriggerVerification(int documentId)
        {
            try
            {
                if (!await IsAdminUser())
                    return Forbid("Admin access required");

                var document = await _context.UserUploadedDocuments.FindAsync(documentId);
                if (document == null)
                    return NotFound("Document not found");

                if (!document.IsSubmitted)
                    return BadRequest("Documents not yet submitted");

                // Call DLL verification function
                await CallDLLVerification(document.Id);

                // Log activity
                await LogAdminActivity($"Admin triggered verification for document {documentId}");

                return Ok(new { 
                    message = "Admin verification process initiated successfully",
                    documentId = documentId,
                    userId = document.UserId,
                    verifiedAt = DateTime.UtcNow
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error triggering verification");
                return StatusCode(500, "Internal server error");
            }
        }

        // Removed AdminManualVerification endpoint - now using single verification method

        // 8.1. Test Extract Documents (Simple test first)
        [HttpPost("test-extract/{uploadId}")]
        public async Task<ActionResult> TestExtractDocuments(int uploadId)
        {
            try
            {
                if (!await IsAdminUser())
                    return Forbid("Admin access required");

                _logger.LogInformation($"Test extract for upload ID: {uploadId}");

                // Get the upload record
                var upload = await _context.UserUploadedDocuments.FindAsync(uploadId);
                if (upload == null)
                {
                    return NotFound("Upload record not found");
                }

                return Ok(new { 
                    message = "Test extract successful",
                    uploadId = uploadId,
                    upload = new {
                        id = upload.Id,
                        userId = upload.UserId,
                        isSubmitted = upload.IsSubmitted,
                        ecPath = upload.ECPath,
                        aadhaarPath = upload.AadhaarPath,
                        panPath = upload.PANPath
                    }
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error in test extract for upload {uploadId}");
                return StatusCode(500, new { 
                    message = "Internal server error", 
                    error = ex.Message,
                    stackTrace = ex.StackTrace
                });
            }
        }

        // 8.2. Extract Documents (Admin-triggered extraction)
        [HttpPost("extract-documents/{uploadId}")]
        public async Task<ActionResult> ExtractDocuments(int uploadId)
        {
            try
            {
                if (!await IsAdminUser())
                    return Forbid("Admin access required");

                _logger.LogInformation($"Admin triggered document extraction for upload ID: {uploadId}");

                // Get the upload record
                var upload = await _context.UserUploadedDocuments.FindAsync(uploadId);
                if (upload == null)
                {
                    _logger.LogWarning($"Upload record not found for ID: {uploadId}");
                    return NotFound("Upload record not found");
                }

                if (!upload.IsSubmitted)
                {
                    _logger.LogWarning($"Documents not submitted for upload ID: {uploadId}");
                    return BadRequest("Documents not yet submitted");
                }

                // Check if files exist
                var fileChecks = new
                {
                    ECPath = upload.ECPath,
                    ECPathExists = !string.IsNullOrEmpty(upload.ECPath) && System.IO.File.Exists(upload.ECPath),
                    AadhaarPath = upload.AadhaarPath,
                    AadhaarPathExists = !string.IsNullOrEmpty(upload.AadhaarPath) && System.IO.File.Exists(upload.AadhaarPath),
                    PANPath = upload.PANPath,
                    PANPathExists = !string.IsNullOrEmpty(upload.PANPath) && System.IO.File.Exists(upload.PANPath)
                };

                _logger.LogInformation($"File existence check: {System.Text.Json.JsonSerializer.Serialize(fileChecks)}");

                // Call the document processing service for extraction
                var extractionSuccess = await _documentProcessingService.ProcessDocumentExtractionAsync(uploadId);
                
                if (extractionSuccess)
                {
                    _logger.LogInformation($"Document extraction completed successfully for upload ID: {uploadId}");
                    
                    // Log admin activity
                    await LogAdminActivity($"Admin extracted documents for upload {uploadId}");

                    return Ok(new { 
                        message = "Document extraction completed successfully",
                        uploadId = uploadId,
                        fileChecks = fileChecks,
                        timestamp = DateTime.UtcNow
                    });
                }
                else
                {
                    _logger.LogError($"Document extraction failed for upload ID: {uploadId}");
                    return StatusCode(500, new { 
                        message = "Document extraction failed", 
                        uploadId = uploadId,
                        fileChecks = fileChecks
                    });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error in document extraction for upload {uploadId}");
                return StatusCode(500, new { 
                    message = "Internal server error", 
                    error = ex.Message 
                });
            }
        }

        // 9. Analytics & Reports
        [HttpGet("analytics")]
        public async Task<ActionResult> GetAnalytics()
        {
            try
            {
                if (!await IsAdminUser())
                    return Forbid("Admin access required");

                var totalUsers = await _context.Users.CountAsync();
                var totalAdmins = await _context.Users.CountAsync(u => u.Role == "Admin");
                var totalRegularUsers = await _context.Users.CountAsync(u => u.Role == "User");

                var totalUploads = await _context.UserUploadedDocuments.CountAsync();
                var submittedUploads = await _context.UserUploadedDocuments.CountAsync(ud => ud.IsSubmitted);
                var verifiedUploads = await _context.UserUploadedDocuments.CountAsync(ud => ud.IsVerified);

                var pendingVerification = submittedUploads - verifiedUploads;

                // Risk score summary
                var riskScoreSummary = await _context.UserUploadedDocuments
                    .Where(ud => ud.IsVerified)
                    .GroupBy(ud => new
                    {
                        LowRisk = ud.RiskScore <= 30,
                        MediumRisk = ud.RiskScore > 30 && ud.RiskScore <= 70,
                        HighRisk = ud.RiskScore > 70
                    })
                    .Select(g => new
                    {
                        LowRisk = g.Count(x => x.RiskScore <= 30),
                        MediumRisk = g.Count(x => x.RiskScore > 30 && x.RiskScore <= 70),
                        HighRisk = g.Count(x => x.RiskScore > 70)
                    })
                    .FirstOrDefaultAsync();

                // Upload trends (last 30 days)
                var thirtyDaysAgo = DateTime.UtcNow.AddDays(-30);
                var uploadTrends = await _context.UserUploadedDocuments
                    .Where(ud => ud.CreatedAt >= thirtyDaysAgo)
                    .GroupBy(ud => ud.CreatedAt.Date)
                    .Select(g => new
                    {
                        Date = g.Key,
                        Count = g.Count()
                    })
                    .OrderBy(x => x.Date)
                    .ToListAsync();

                // Recent activity
                var recentActivity = await _context.UserActivityLogs
                    .OrderByDescending(al => al.Timestamp)
                    .Take(20)
                    .Select(al => new
                    {
                        al.Activity,
                        al.Description,
                        al.Timestamp,
                        UserEmail = al.User.Email
                    })
                    .ToListAsync();

                return Ok(new
                {
                    userStats = new
                    {
                        totalUsers,
                        totalAdmins,
                        totalRegularUsers
                    },
                    documentStats = new
                    {
                        totalUploads,
                        submittedUploads,
                        verifiedUploads,
                        pendingVerification
                    },
                    riskScoreSummary = riskScoreSummary ?? new { LowRisk = 0, MediumRisk = 0, HighRisk = 0 },
                    uploadTrends,
                    recentActivity
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting analytics");
                return StatusCode(500, "Internal server error");
            }
        }

        // 10. Download document for audit
        [HttpGet("documents/{documentId}/download/{documentType}")]
        public async Task<ActionResult> DownloadDocument(int documentId, string documentType)
        {
            try
            {
                if (!await IsAdminUser())
                    return Forbid("Admin access required");

                var document = await _context.UserUploadedDocuments.FindAsync(documentId);
                if (document == null)
                    return NotFound("Document not found");

                string? filePath = documentType.ToLower() switch
                {
                    "ec" => document.ECPath,
                    "aadhaar" => document.AadhaarPath,
                    "pan" => document.PANPath,
                    _ => null
                };

                if (string.IsNullOrEmpty(filePath) || !System.IO.File.Exists(filePath))
                    return NotFound("Document file not found");

                var fileBytes = await System.IO.File.ReadAllBytesAsync(filePath);
                var fileName = Path.GetFileName(filePath);

                return File(fileBytes, "application/pdf", fileName);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error downloading document");
                return StatusCode(500, "Internal server error");
            }
        }

            // 11. Get user activity logs
        [HttpGet("activity-logs")]
        public async Task<ActionResult> GetActivityLogs([FromQuery] int page = 1, [FromQuery] int pageSize = 20)
        {
            try
            {
                if (!await IsAdminUser())
                    return Forbid("Admin access required");

                var logs = await _context.UserActivityLogs
                    .Include(al => al.User)
                    .OrderByDescending(al => al.Timestamp)
                    .Skip((page - 1) * pageSize)
                    .Take(pageSize)
                    .Select(al => new
                    {
                        al.Id,
                        al.Activity,
                        al.Description,
                        al.IPAddress,
                        al.UserAgent,
                        al.Timestamp,
                        UserName = al.User.FullName,
                        UserEmail = al.User.Email
                    })
                    .ToListAsync();

                var totalLogs = await _context.UserActivityLogs.CountAsync();

                return Ok(new
                {
                    logs,
                    totalLogs,
                    page,
                    pageSize,
                    totalPages = (int)Math.Ceiling((double)totalLogs / pageSize)
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting activity logs");
                return StatusCode(500, "Internal server error");
            }
        }

        // Helper method to call DLL verification
        private async Task CallDLLVerification(int documentId)
        {
            try
            {
                var result = await _documentExtractionService.VerifyDocumentsAsync(documentId);
                
                var document = await _context.UserUploadedDocuments.FindAsync(documentId);
                if (document != null)
                {
                    document.IsVerified = result.IsVerified;
                    document.RiskScore = result.RiskScore;
                    document.VerificationNotes = result.VerificationNotes;
                    document.FieldMismatches = result.FieldMismatches;
                    document.UpdatedAt = DateTime.UtcNow;
                    
                    await _context.SaveChangesAsync();
                }

                _logger.LogInformation($"Successfully verified documents for document {documentId}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error verifying documents for document {documentId}");
            }
        }

        // Helper method to log admin activity
        private async Task LogAdminActivity(string description)
        {
            try
            {
                var adminId = GetCurrentUserId();
                var activityLog = new UserActivityLog
                {
                    UserId = adminId,
                    Activity = "Admin Action",
                    Description = description,
                    IPAddress = HttpContext.Connection.RemoteIpAddress?.ToString(),
                    UserAgent = HttpContext.Request.Headers["User-Agent"].ToString()
                };

                _context.UserActivityLogs.Add(activityLog);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error logging admin activity");
            }
        }

        // 10. Get Document Extracted Data
        [HttpGet("documents/{documentId}/extracted-data")]
        public async Task<ActionResult<object>> GetDocumentExtractedData(int documentId)
        {
            try
            {
                if (!await IsAdminUser())
                    return Unauthorized("Admin access required");

                var document = await _context.UserUploadedDocuments
                    .Include(u => u.User)
                    .FirstOrDefaultAsync(u => u.Id == documentId);
                
                if (document == null)
                    return NotFound("Document not found");

                // Return all extracted data from the document
                var extractedData = new
                {
                    // Basic Info
                    Id = document.Id,
                    UserId = document.UserId,
                    UserName = document.User.FullName,
                    UserEmail = document.User.Email,
                    SubmittedAt = document.SubmittedAt,
                    IsVerified = document.IsVerified,
                    RiskScore = document.RiskScore,
                    
                    // EC Document Data
                    ECData = new
                    {
                        Name = document.Name,
                        ApplicationNumber = document.ApplicationNumber,
                        Address = document.ApplicantAddress,
                        SurveyNumber = document.SurveyNo,
                        MeasuringArea = document.MeasuringArea,
                        Village = document.Village,
                        Hobli = document.Hobli,
                        Taluk = document.Taluk,
                        District = document.District
                    },
                    
                    // Aadhaar Document Data
                    AadhaarData = new
                    {
                        Name = document.AdhaarFullName,
                        AadhaarNumber = document.AdhaarNo,
                        DOB = document.Dob,
                        FatherName = "N/A", // Not available in current model
                        MotherName = "N/A"  // Not available in current model
                    },
                    
                    // PAN Document Data
                    PANData = new
                    {
                        Name = document.PanFullName,
                        PANNumber = document.PanNo,
                        DOB = document.Dob,
                        FatherName = "N/A" // Not available in current model
                    },
                    
                    // Verification Data
                    VerificationData = new
                    {
                        VerificationNotes = document.VerificationNotes,
                        FieldMismatches = document.FieldMismatches,
                        CreatedAt = document.CreatedAt,
                        UpdatedAt = document.UpdatedAt
                    }
                };

                return Ok(extractedData);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error fetching extracted data for document {documentId}");
                return StatusCode(500, "Internal server error");
            }
        }

        // Get extracted data from ExtractedDataDocuments table by UserUploadedDocuments ID
        [HttpGet("extracted-data/{documentId}")]
        public async Task<ActionResult<ExtractedDataDocuments>> GetExtractedDataFromTable(int documentId)
        {
            try
            {
                // First try to get from ExtractedDataDocuments table
                var extractedData = await _context.ExtractedDataDocuments
                    .FirstOrDefaultAsync(ed => ed.Id == documentId);

                if (extractedData != null)
                {
                    return Ok(extractedData);
                }

                // If not found, try to get from UserUploadedDocuments and return the ExtractedData
                var userDocument = await _context.UserUploadedDocuments
                    .FirstOrDefaultAsync(ud => ud.Id == documentId);

                if (userDocument == null)
                    return NotFound("Document not found");

                // Parse the ExtractedData JSON from UserUploadedDocuments
                if (!string.IsNullOrEmpty(userDocument.ExtractedData))
                {
                    var extractedDataDto = JsonSerializer.Deserialize<ExtractedDataDto>(userDocument.ExtractedData);
                    
                    // Convert to ExtractedDataDocuments format
                    var extractedDataDocument = new ExtractedDataDocuments
                    {
                        ApplicationNumber = extractedDataDto.ApplicationNumber,
                        Name = extractedDataDto.Name,
                        Address = extractedDataDto.Address,
                        SurveyNumber = extractedDataDto.SurveyNumber,
                        MeasuringArea = extractedDataDto.MeasuringArea,
                        Village = extractedDataDto.Village,
                        Hobli = extractedDataDto.Hobli,
                        Taluk = extractedDataDto.Taluk,
                        District = extractedDataDto.District,
                        AadhaarNumber = extractedDataDto.AadhaarNumber,
                        PANNumber = extractedDataDto.PANNumber,
                        DOB = !string.IsNullOrEmpty(extractedDataDto.DOB) ? DateTime.Parse(extractedDataDto.DOB) : null,
                        CreatedAt = userDocument.CreatedAt,
                        UpdatedAt = userDocument.UpdatedAt
                    };

                    return Ok(extractedDataDocument);
                }

                return NotFound("No extracted data found for this document");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error fetching extracted data from table for document {documentId}");
                return StatusCode(500, "Internal server error");
            }
        }

        // Get all extracted data from ExtractedDataDocuments table
        [HttpGet("all-extracted-data")]
        public async Task<ActionResult<IEnumerable<ExtractedDataDocuments>>> GetAllExtractedData()
        {
            try
            {
                var extractedData = await _context.ExtractedDataDocuments
                    .OrderByDescending(ed => ed.CreatedAt)
                    .ToListAsync();

                return Ok(extractedData);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching all extracted data");
                return StatusCode(500, "Internal server error");
            }
        }

        // Test endpoint to check database connection and table existence
        [HttpGet("test-database")]
        public async Task<ActionResult> TestDatabase()
        {
            try
            {
                // Test if ExtractedDataDocuments table exists and is accessible
                var count = await _context.ExtractedDataDocuments.CountAsync();
                
                return Ok(new { 
                    message = "Database connection successful", 
                    tableExists = true,
                    recordCount = count,
                    timestamp = DateTime.UtcNow
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Database test failed");
                return StatusCode(500, new { 
                    message = "Database test failed", 
                    error = ex.Message,
                    tableExists = false
                });
            }
        }

        // Simple test endpoint
        // Verify documents endpoint
        [HttpPost("verify-documents/{extractedDataId}")]
        public async Task<ActionResult<webApitest.Models.DTOs.VerificationResultDto>> VerifyDocuments(int extractedDataId)
        {
            try
            {
                _logger.LogInformation($"Starting document verification for extracted data ID: {extractedDataId}");

                var result = await _documentVerificationService.VerifyExtractedDataAsync(extractedDataId);

                _logger.LogInformation($"Document verification completed for extracted data ID: {extractedDataId}. Risk Score: {result.RiskScore}, Verified: {result.IsVerified}");

                // If verified and risk score is 0, include coordinates for map redirect
                if (result.IsVerified && result.RiskScore == 0)
                {
                    return Ok(new
                    {
                        isVerified = result.IsVerified,
                        riskScore = result.RiskScore,
                        verificationNotes = result.VerificationNotes,
                        fieldMismatches = result.FieldMismatches,
                        latitude = result.Latitude,
                        longitude = result.Longitude,
                        message = "Documents verified successfully. Redirecting to map view."
                    });
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error during document verification for extracted data ID: {extractedDataId}");
                return StatusCode(500, new { message = "Internal server error during verification", details = ex.Message });
            }
        }

        [HttpGet("test")]
        public ActionResult Test()
        {
            return Ok(new { message = "AdminDashboard controller is working", timestamp = DateTime.UtcNow });
        }

        // Seed test data endpoint
        [HttpPost("seed-test-data")]
        public async Task<ActionResult> SeedTestData()
        {
            try
            {
                if (!await IsAdminUser())
                    return Forbid("Admin access required");

                // Clear existing test data
                _context.ExtractedDataDocuments.RemoveRange(_context.ExtractedDataDocuments);
                _context.OriginalSurveyNo.RemoveRange(_context.OriginalSurveyNo);
                _context.OriginalPan.RemoveRange(_context.OriginalPan);
                _context.OriginalAdhar.RemoveRange(_context.OriginalAdhar);
                await _context.SaveChangesAsync();

                // Seed OriginalAdhar data
                var aadhaarData = new List<OriginalAdhar>
                {
                    new OriginalAdhar { Name = "John Doe", Dob = "1990-05-15", AdhaarNo = "123456789012" },
                    new OriginalAdhar { Name = "Jane Smith", Dob = "1985-08-22", AdhaarNo = "987654321098" },
                    new OriginalAdhar { Name = "Mike Johnson", Dob = "1992-12-10", AdhaarNo = "456789123456" },
                    new OriginalAdhar { Name = "Sarah Wilson", Dob = "1988-03-25", AdhaarNo = "789123456789" },
                    new OriginalAdhar { Name = "David Brown", Dob = "1995-07-18", AdhaarNo = "321654987321" }
                };

                _context.OriginalAdhar.AddRange(aadhaarData);

                // Seed OriginalPan data
                var panData = new List<OriginalPan>
                {
                    new OriginalPan { Name = "John Doe", Dob = "1990-05-15", PanNo = "ABCDE1234F" },
                    new OriginalPan { Name = "Jane Smith", Dob = "1985-08-22", PanNo = "FGHIJ5678K" },
                    new OriginalPan { Name = "Mike Johnson", Dob = "1992-12-10", PanNo = "LMNOP9012Q" },
                    new OriginalPan { Name = "Sarah Wilson", Dob = "1988-03-25", PanNo = "RSTUV3456W" },
                    new OriginalPan { Name = "David Brown", Dob = "1995-07-18", PanNo = "XYZAB7890C" }
                };

                _context.OriginalPan.AddRange(panData);

                // Seed OriginalSurveyNo data
                var surveyData = new List<OriginalSurveyNo>
                {
                    new OriginalSurveyNo { SurveyNo = "123/45", MeasuringArea = "2.5 acres", Village = "Village A", Hobli = "Hobli 1", Taluk = "Taluk 1", District = "District 1", Latitude = 12.9716m, Longitude = 77.5946m },
                    new OriginalSurveyNo { SurveyNo = "456/78", MeasuringArea = "3.2 acres", Village = "Village B", Hobli = "Hobli 2", Taluk = "Taluk 2", District = "District 2", Latitude = 13.0827m, Longitude = 80.2707m },
                    new OriginalSurveyNo { SurveyNo = "789/12", MeasuringArea = "1.8 acres", Village = "Village C", Hobli = "Hobli 3", Taluk = "Taluk 3", District = "District 3", Latitude = 15.3173m, Longitude = 75.7139m },
                    new OriginalSurveyNo { SurveyNo = "321/65", MeasuringArea = "4.1 acres", Village = "Village D", Hobli = "Hobli 4", Taluk = "Taluk 4", District = "District 4", Latitude = 17.3850m, Longitude = 78.4867m },
                    new OriginalSurveyNo { SurveyNo = "654/98", MeasuringArea = "2.9 acres", Village = "Village E", Hobli = "Hobli 5", Taluk = "Taluk 5", District = "District 5", Latitude = 19.0760m, Longitude = 72.8777m }
                };

                _context.OriginalSurveyNo.AddRange(surveyData);

                // Seed ExtractedDataDocuments data
                var extractedData = new List<ExtractedDataDocuments>
                {
                    new ExtractedDataDocuments 
                    { 
                        ApplicationNumber = "APP001", 
                        Name = "John Doe", 
                        Address = "123 Main Street, City A", 
                        SurveyNumber = "123/45", 
                        MeasuringArea = "2.5 acres", 
                        Village = "Village A", 
                        Hobli = "Hobli 1", 
                        Taluk = "Taluk 1", 
                        District = "District 1", 
                        AadhaarNumber = "123456789012", 
                        PANNumber = "ABCDE1234F", 
                        DOB = new DateTime(1990, 5, 15) 
                    },
                    new ExtractedDataDocuments 
                    { 
                        ApplicationNumber = "APP002", 
                        Name = "Jane Smith", 
                        Address = "456 Oak Avenue, City B", 
                        SurveyNumber = "456/78", 
                        MeasuringArea = "3.2 acres", 
                        Village = "Village B", 
                        Hobli = "Hobli 2", 
                        Taluk = "Taluk 2", 
                        District = "District 2", 
                        AadhaarNumber = "987654321098", 
                        PANNumber = "FGHIJ5678K", 
                        DOB = new DateTime(1985, 8, 22) 
                    },
                    new ExtractedDataDocuments 
                    { 
                        ApplicationNumber = "APP003", 
                        Name = "Mike Johnson", 
                        Address = "789 Pine Road, City C", 
                        SurveyNumber = "789/12", 
                        MeasuringArea = "1.8 acres", 
                        Village = "Village C", 
                        Hobli = "Hobli 3", 
                        Taluk = "Taluk 3", 
                        District = "District 3", 
                        AadhaarNumber = "456789123456", 
                        PANNumber = "LMNOP9012Q", 
                        DOB = new DateTime(1992, 12, 10) 
                    },
                    new ExtractedDataDocuments 
                    { 
                        ApplicationNumber = "APP004", 
                        Name = "Sarah Wilson", 
                        Address = "321 Elm Street, City D", 
                        SurveyNumber = "321/65", 
                        MeasuringArea = "4.1 acres", 
                        Village = "Village D", 
                        Hobli = "Hobli 4", 
                        Taluk = "Taluk 4", 
                        District = "District 4", 
                        AadhaarNumber = "789123456789", 
                        PANNumber = "RSTUV3456W", 
                        DOB = new DateTime(1988, 3, 25) 
                    },
                    new ExtractedDataDocuments 
                    { 
                        ApplicationNumber = "APP005", 
                        Name = "David Brown", 
                        Address = "654 Maple Lane, City E", 
                        SurveyNumber = "654/98", 
                        MeasuringArea = "2.9 acres", 
                        Village = "Village E", 
                        Hobli = "Hobli 5", 
                        Taluk = "Taluk 5", 
                        District = "District 5", 
                        AadhaarNumber = "321654987321", 
                        PANNumber = "XYZAB7890C", 
                        DOB = new DateTime(1995, 7, 18) 
                    },
                    // Add one with mismatched data for testing verification failures
                    new ExtractedDataDocuments 
                    { 
                        ApplicationNumber = "APP006", 
                        Name = "Test User", 
                        Address = "999 Test Street, Test City", 
                        SurveyNumber = "999/99", 
                        MeasuringArea = "5.0 acres", 
                        Village = "Test Village", 
                        Hobli = "Test Hobli", 
                        Taluk = "Test Taluk", 
                        District = "Test District", 
                        AadhaarNumber = "999999999999", 
                        PANNumber = "TEST1234T", 
                        DOB = new DateTime(1990, 1, 1) 
                    }
                };

                _context.ExtractedDataDocuments.AddRange(extractedData);

                await _context.SaveChangesAsync();

                return Ok(new { 
                    message = "Test data seeded successfully!", 
                    aadhaarCount = aadhaarData.Count,
                    panCount = panData.Count,
                    surveyCount = surveyData.Count,
                    extractedCount = extractedData.Count,
                    timestamp = DateTime.UtcNow
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error seeding test data");
                return StatusCode(500, new { message = "Error seeding test data", details = ex.Message });
            }
        }
    }
}

# ExtractedDataDocuments Table Setup

## ✅ **Table Created Successfully**

### 📋 **Table Structure:**
```sql
CREATE TABLE ExtractedDataDocuments
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    ApplicationNumber NVARCHAR(50) NULL,
    Name NVARCHAR(200) NOT NULL,
    Address NVARCHAR(500) NULL,
    SurveyNumber NVARCHAR(50) NULL,
    MeasuringArea NVARCHAR(100) NULL,
    Village NVARCHAR(100) NULL,
    Hobli NVARCHAR(100) NULL,
    Taluk NVARCHAR(100) NULL,
    District NVARCHAR(100) NULL,
    AadhaarNumber CHAR(12) NULL,
    PANNumber CHAR(10) NULL,
    DOB DATE NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    UpdatedAt DATETIME2 NULL
);
```

### 🔧 **Model Class Created:**
- **File**: `webApitest/Models/ExtractedDataDocuments.cs`
- **Features**: Data annotations, validation attributes
- **Properties**: All fields with proper data types

### 🗄️ **Database Context Updated:**
- **DbSet Added**: `public DbSet<ExtractedDataDocuments> ExtractedDataDocuments { get; set; }`
- **Entity Configuration**: Added in `OnModelCreating` method
- **Constraints**: Proper field lengths and requirements

---

## 📊 **Field Mapping from DLL Extraction**

### **EC Document Fields:**
- ✅ **ApplicationNumber** - From EC extraction
- ✅ **Name** - From EC extraction  
- ✅ **Address** - From EC extraction
- ✅ **SurveyNumber** - From EC extraction
- ✅ **MeasuringArea** - From EC extraction
- ✅ **Village** - From EC extraction
- ✅ **Hobli** - From EC extraction
- ✅ **Taluk** - From EC extraction
- ✅ **District** - From EC extraction

### **Aadhaar Document Fields:**
- ✅ **Name** - From Aadhaar extraction
- ✅ **AadhaarNumber** - From Aadhaar extraction

### **PAN Document Fields:**
- ✅ **Name** - From PAN extraction
- ✅ **PANNumber** - From PAN extraction
- ✅ **DOB** - From PAN extraction

---

## 🚀 **Usage Instructions**

### **1. Run SQL Script:**
```sql
-- Execute the CREATE_EXTRACTED_DATA_DOCUMENTS_TABLE.sql script
-- This will create the table with indexes and documentation
```

### **2. Update Backend Service:**
```csharp
// In DocumentExtractionService.cs, add method to save extracted data:
public async Task<ExtractedDataDocuments> SaveExtractedDataAsync(ExtractedDataDto extractedData)
{
    var document = new ExtractedDataDocuments
    {
        ApplicationNumber = extractedData.ApplicationNumber,
        Name = extractedData.Name,
        Address = extractedData.Address,
        SurveyNumber = extractedData.SurveyNumber,
        MeasuringArea = extractedData.MeasuringArea,
        Village = extractedData.Village,
        Hobli = extractedData.Hobli,
        Taluk = extractedData.Taluk,
        District = extractedData.District,
        AadhaarNumber = extractedData.AadhaarNumber,
        PANNumber = extractedData.PANNumber,
        DOB = extractedData.DOB,
        CreatedAt = DateTime.UtcNow
    };

    _context.ExtractedDataDocuments.Add(document);
    await _context.SaveChangesAsync();
    return document;
}
```

### **3. API Endpoints:**
```csharp
// Add to controller:
[HttpGet("extracted-data")]
public async Task<ActionResult<IEnumerable<ExtractedDataDocuments>>> GetExtractedData()
{
    return await _context.ExtractedDataDocuments.ToListAsync();
}

[HttpGet("extracted-data/{id}")]
public async Task<ActionResult<ExtractedDataDocuments>> GetExtractedData(int id)
{
    var data = await _context.ExtractedDataDocuments.FindAsync(id);
    if (data == null) return NotFound();
    return data;
}
```

---

## 📈 **Performance Optimizations**

### **Indexes Created:**
- ✅ **IX_ExtractedDataDocuments_Name** - For name searches
- ✅ **IX_ExtractedDataDocuments_AadhaarNumber** - For Aadhaar lookups
- ✅ **IX_ExtractedDataDocuments_PANNumber** - For PAN lookups
- ✅ **IX_ExtractedDataDocuments_ApplicationNumber** - For EC lookups
- ✅ **IX_ExtractedDataDocuments_SurveyNumber** - For survey lookups
- ✅ **IX_ExtractedDataDocuments_CreatedAt** - For date range queries

### **Query Examples:**
```sql
-- Find by Aadhaar number
SELECT * FROM ExtractedDataDocuments WHERE AadhaarNumber = '123456789012';

-- Find by PAN number
SELECT * FROM ExtractedDataDocuments WHERE PANNumber = 'ABCDE1234F';

-- Find by survey number
SELECT * FROM ExtractedDataDocuments WHERE SurveyNumber = '123/45';

-- Find recent extractions
SELECT * FROM ExtractedDataDocuments WHERE CreatedAt >= DATEADD(day, -7, GETUTCDATE());
```

---

## 🔍 **Data Validation**

### **Field Constraints:**
- **Name**: Required, Max 200 characters
- **ApplicationNumber**: Max 50 characters
- **Address**: Max 500 characters
- **SurveyNumber**: Max 50 characters
- **MeasuringArea**: Max 100 characters
- **Village/Hobli/Taluk/District**: Max 100 characters each
- **AadhaarNumber**: Exactly 12 characters
- **PANNumber**: Exactly 10 characters
- **DOB**: Date format

### **Business Rules:**
- At least one document field must be populated
- Name is always required
- AadhaarNumber must be 12 digits
- PANNumber must follow format: 5 letters + 4 digits + 1 letter

---

## 📋 **Next Steps**

### **1. Database Migration:**
```bash
# Stop any running backend processes
# Run migration
dotnet ef database update
```

### **2. Test the Table:**
```sql
-- Insert test data
INSERT INTO ExtractedDataDocuments (Name, AadhaarNumber, CreatedAt) 
VALUES ('Test User', '123456789012', GETUTCDATE());

-- Verify data
SELECT * FROM ExtractedDataDocuments;
```

### **3. Update Services:**
- Modify DocumentExtractionService to save to new table
- Update API controllers to use new table
- Test document upload and extraction flow

---

## ✅ **Status: Ready for Implementation**

The `ExtractedDataDocuments` table is fully configured and ready to store extracted data from your DLL! 🎯

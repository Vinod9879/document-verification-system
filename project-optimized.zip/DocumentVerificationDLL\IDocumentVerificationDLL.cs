using System;
using System.Threading.Tasks;

namespace DocumentVerificationDLL
{
    public interface IDocumentVerificationDLL
    {
        /// <summary>
        /// Extract data from EC (Encumbrance Certificate) document
        /// </summary>
        /// <param name="filePath">Path to the EC PDF file</param>
        /// <returns>Extracted data from EC document</returns>
        Task<ExtractedData> ExtractECAsync(string filePath);

        /// <summary>
        /// Extract data from Aadhaar document
        /// </summary>
        /// <param name="filePath">Path to the Aadhaar PDF file</param>
        /// <returns>Extracted data from Aadhaar document</returns>
        Task<ExtractedData> ExtractAadhaarAsync(string filePath);

        /// <summary>
        /// Extract data from PAN document
        /// </summary>
        /// <param name="filePath">Path to the PAN PDF file</param>
        /// <returns>Extracted data from PAN document</returns>
        Task<ExtractedData> ExtractPANAsync(string filePath);

        // Verification method removed - DLL now focuses only on extraction
        // Verification logic has been moved to DocumentProcessingService in the backend

        // Validation method removed - DLL now focuses only on extraction
    }

    public class ExtractedData
    {
        public string? Name { get; set; }
        public string? DOB { get; set; }
        public string? SurveyNumber { get; set; }
        public string? PANNumber { get; set; }
        public string? AadhaarNumber { get; set; }
        public string? Address { get; set; }
        public string? FatherName { get; set; }
        public string? MotherName { get; set; }
        public string? ECNumber { get; set; }
        public string? PropertyDetails { get; set; }
        
        // EC Document specific fields
        public string? ApplicationNumber { get; set; }
        public string? MeasuringArea { get; set; }
        public string? Village { get; set; }
        public string? Hobli { get; set; }
        public string? Taluk { get; set; }
        public string? District { get; set; }
        
        public decimal ConfidenceScore { get; set; }
        public string? ExtractionNotes { get; set; }
    }

    // VerificationResult class removed - verification logic moved to backend
}

-- Create ExtractedDataDocuments table
CREATE TABLE ExtractedDataDocuments
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    ApplicationNumber NVARCHAR(50) NULL,
    Name NVARCHAR(200) NOT NULL,
    Address NVARCHAR(500) NULL,
    SurveyNumber NVARCHAR(50) NULL,
    MeasuringArea NVARCHAR(100) NULL,
    Village NVARCHAR(100) NULL,
    Hobli NVARCHAR(100) NULL,
    Taluk NVARCHAR(100) NULL,
    District NVARCHAR(100) NULL,
    AadhaarNumber CHAR(12) NULL,
    PANNumber CHAR(10) NULL,
    DOB DATE NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    UpdatedAt DATETIME2 NULL
);

-- Create indexes for better performance
CREATE INDEX IX_ExtractedDataDocuments_Name ON ExtractedDataDocuments (Name);
CREATE INDEX IX_ExtractedDataDocuments_AadhaarNumber ON ExtractedDataDocuments (AadhaarNumber);
CREATE INDEX IX_ExtractedDataDocuments_PANNumber ON ExtractedDataDocuments (PANNumber);
CREATE INDEX IX_ExtractedDataDocuments_ApplicationNumber ON ExtractedDataDocuments (ApplicationNumber);
CREATE INDEX IX_ExtractedDataDocuments_SurveyNumber ON ExtractedDataDocuments (SurveyNumber);
CREATE INDEX IX_ExtractedDataDocuments_CreatedAt ON ExtractedDataDocuments (CreatedAt);

-- Add comments for documentation
EXEC sp_addextendedproperty 
    @name = N'MS_Description', 
    @value = N'Table to store extracted data from documents (EC, Aadhaar, PAN)', 
    @level0type = N'SCHEMA', @level0name = N'dbo', 
    @level1type = N'TABLE', @level1name = N'ExtractedDataDocuments';

EXEC sp_addextendedproperty 
    @name = N'MS_Description', 
    @value = N'Primary key for extracted data records', 
    @level0type = N'SCHEMA', @level0name = N'dbo', 
    @level1type = N'TABLE', @level1name = N'ExtractedDataDocuments',
    @level2type = N'COLUMN', @level2name = N'Id';

EXEC sp_addextendedproperty 
    @name = N'MS_Description', 
    @value = N'Application number from EC document', 
    @level0type = N'SCHEMA', @level0name = N'dbo', 
    @level1type = N'TABLE', @level1name = N'ExtractedDataDocuments',
    @level2type = N'COLUMN', @level2name = N'ApplicationNumber';

EXEC sp_addextendedproperty 
    @name = N'MS_Description', 
    @value = N'Name extracted from documents', 
    @level0type = N'SCHEMA', @level0name = N'dbo', 
    @level1type = N'TABLE', @level1name = N'ExtractedDataDocuments',
    @level2type = N'COLUMN', @level2name = N'Name';

EXEC sp_addextendedproperty 
    @name = N'MS_Description', 
    @value = N'Address from EC document', 
    @level0type = N'SCHEMA', @level0name = N'dbo', 
    @level1type = N'TABLE', @level1name = N'ExtractedDataDocuments',
    @level2type = N'COLUMN', @level2name = N'Address';

EXEC sp_addextendedproperty 
    @name = N'MS_Description', 
    @value = N'Survey number from EC document', 
    @level0type = N'SCHEMA', @level0name = N'dbo', 
    @level1type = N'TABLE', @level1name = N'ExtractedDataDocuments',
    @level2type = N'COLUMN', @level2name = N'SurveyNumber';

EXEC sp_addextendedproperty 
    @name = N'MS_Description', 
    @value = N'Measuring area from EC document', 
    @level0type = N'SCHEMA', @level0name = N'dbo', 
    @level1type = N'TABLE', @level1name = N'ExtractedDataDocuments',
    @level2type = N'COLUMN', @level2name = N'MeasuringArea';

EXEC sp_addextendedproperty 
    @name = N'MS_Description', 
    @value = N'Village name from EC document', 
    @level0type = N'SCHEMA', @level0name = N'dbo', 
    @level1type = N'TABLE', @level1name = N'ExtractedDataDocuments',
    @level2type = N'COLUMN', @level2name = N'Village';

EXEC sp_addextendedproperty 
    @name = N'MS_Description', 
    @value = N'Hobli name from EC document', 
    @level0type = N'SCHEMA', @level0name = N'dbo', 
    @level1type = N'TABLE', @level1name = N'ExtractedDataDocuments',
    @level2type = N'COLUMN', @level2name = N'Hobli';

EXEC sp_addextendedproperty 
    @name = N'MS_Description', 
    @value = N'Taluk name from EC document', 
    @level0type = N'SCHEMA', @level0name = N'dbo', 
    @level1type = N'TABLE', @level1name = N'ExtractedDataDocuments',
    @level2type = N'COLUMN', @level2name = N'Taluk';

EXEC sp_addextendedproperty 
    @name = N'MS_Description', 
    @value = N'District name from EC document', 
    @level0type = N'SCHEMA', @level0name = N'dbo', 
    @level1type = N'TABLE', @level1name = N'ExtractedDataDocuments',
    @level2type = N'COLUMN', @level2name = N'District';

EXEC sp_addextendedproperty 
    @name = N'MS_Description', 
    @value = N'Aadhaar number from Aadhaar document', 
    @level0type = N'SCHEMA', @level0name = N'dbo', 
    @level1type = N'TABLE', @level1name = N'ExtractedDataDocuments',
    @level2type = N'COLUMN', @level2name = N'AadhaarNumber';

EXEC sp_addextendedproperty 
    @name = N'MS_Description', 
    @value = N'PAN number from PAN document', 
    @level0type = N'SCHEMA', @level0name = N'dbo', 
    @level1type = N'TABLE', @level1name = N'ExtractedDataDocuments',
    @level2type = N'COLUMN', @level2name = N'PANNumber';

EXEC sp_addextendedproperty 
    @name = N'MS_Description', 
    @value = N'Date of Birth from PAN document', 
    @level0type = N'SCHEMA', @level0name = N'dbo', 
    @level1type = N'TABLE', @level1name = N'ExtractedDataDocuments',
    @level2type = N'COLUMN', @level2name = N'DOB';

EXEC sp_addextendedproperty 
    @name = N'MS_Description', 
    @value = N'Record creation timestamp', 
    @level0type = N'SCHEMA', @level0name = N'dbo', 
    @level1type = N'TABLE', @level1name = N'ExtractedDataDocuments',
    @level2type = N'COLUMN', @level2name = N'CreatedAt';

EXEC sp_addextendedproperty 
    @name = N'MS_Description', 
    @value = N'Record last update timestamp', 
    @level0type = N'SCHEMA', @level0name = N'dbo', 
    @level1type = N'TABLE', @level1name = N'ExtractedDataDocuments',
    @level2type = N'COLUMN', @level2name = N'UpdatedAt';

PRINT 'ExtractedDataDocuments table created successfully with indexes and documentation!';

using Microsoft.EntityFrameworkCore;
using webApitest.Data;
using webApitest.Models;
using webApitest.Models.DTOs;

namespace webApitest.Services
{
    public interface IDocumentVerificationService
    {
        Task<VerificationResultDto> VerifyExtractedDataAsync(int extractedDataId);
    }

    public class DocumentVerificationService : IDocumentVerificationService
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<DocumentVerificationService> _logger;

        public DocumentVerificationService(ApplicationDbContext context, ILogger<DocumentVerificationService> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<VerificationResultDto> VerifyExtractedDataAsync(int extractedDataId)
        {
            try
            {
                _logger.LogInformation($"Starting verification for extracted data ID: {extractedDataId}");

                // Fetch the extracted data record
                var extractedData = await _context.ExtractedDataDocuments
                    .FirstOrDefaultAsync(ed => ed.Id == extractedDataId);

                if (extractedData == null)
                {
                    _logger.LogWarning($"Extracted data not found for ID: {extractedDataId}");
                    return new VerificationResultDto
                    {
                        IsVerified = false,
                        RiskScore = 100,
                        VerificationNotes = "Extracted data not found",
                        FieldMismatches = "Extracted data record not found"
                    };
                }

                var riskScore = 0;
                var fieldMismatches = new List<string>();
                var verificationNotes = new List<string>();

                // Verify Aadhaar data
                var aadhaarVerification = await VerifyAadhaarData(extractedData);
                riskScore += aadhaarVerification.RiskScore;
                fieldMismatches.AddRange(aadhaarVerification.FieldMismatches);
                verificationNotes.AddRange(aadhaarVerification.Notes);

                // Verify PAN data
                var panVerification = await VerifyPanData(extractedData);
                riskScore += panVerification.RiskScore;
                fieldMismatches.AddRange(panVerification.FieldMismatches);
                verificationNotes.AddRange(panVerification.Notes);

                // Verify Survey data
                var surveyVerification = await VerifySurveyData(extractedData);
                riskScore += surveyVerification.RiskScore;
                fieldMismatches.AddRange(surveyVerification.FieldMismatches);
                verificationNotes.AddRange(surveyVerification.Notes);

                var isVerified = riskScore == 0;
                var result = new VerificationResultDto
                {
                    IsVerified = isVerified,
                    RiskScore = riskScore,
                    VerificationNotes = string.Join("; ", verificationNotes),
                    FieldMismatches = string.Join("; ", fieldMismatches)
                };

                // If verified and risk score is 0, get coordinates
                if (isVerified)
                {
                    var surveyData = await _context.OriginalSurveyNo
                        .FirstOrDefaultAsync(s => s.SurveyNo == extractedData.SurveyNumber);
                    
                    if (surveyData != null)
                    {
                        result.Latitude = (double?)surveyData.Latitude;
                        result.Longitude = (double?)surveyData.Longitude;
                    }
                }

                // Update UserUploadedDocuments table
                // We'll need to find the user through the UserUploadedDocuments table
                await UpdateUserUploadedDocuments(extractedDataId, result);

                _logger.LogInformation($"Verification completed for extracted data ID: {extractedDataId}. Risk Score: {riskScore}, Verified: {isVerified}");

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error during verification for extracted data ID: {extractedDataId}");
                return new VerificationResultDto
                {
                    IsVerified = false,
                    RiskScore = 100,
                    VerificationNotes = "Verification failed due to system error",
                    FieldMismatches = "System error during verification"
                };
            }
        }

        private async Task<(int RiskScore, List<string> FieldMismatches, List<string> Notes)> VerifyAadhaarData(ExtractedDataDocuments extractedData)
        {
            var riskScore = 0;
            var fieldMismatches = new List<string>();
            var notes = new List<string>();

            var aadhaarData = await _context.OriginalAdhar
                .FirstOrDefaultAsync(a => a.AdhaarNo == extractedData.AadhaarNumber);

            if (aadhaarData == null)
            {
                riskScore += 30;
                fieldMismatches.Add("Aadhaar record not found in original data");
                notes.Add("Aadhaar verification failed - record not found");
                return (riskScore, fieldMismatches, notes);
            }

            // Compare name
            if (!CompareNames(extractedData.Name, aadhaarData.Name))
            {
                riskScore += 10;
                fieldMismatches.Add($"Aadhaar name mismatch: '{extractedData.Name}' vs '{aadhaarData.Name}'");
            }

            // Compare Aadhaar number
            if (extractedData.AadhaarNumber != aadhaarData.AdhaarNo)
            {
                riskScore += 10;
                fieldMismatches.Add($"Aadhaar number mismatch: '{extractedData.AadhaarNumber}' vs '{aadhaarData.AdhaarNo}'");
            }

            // Compare DOB
            if (!CompareDates(extractedData.DOB?.ToString("yyyy-MM-dd"), aadhaarData.Dob))
            {
                riskScore += 10;
                fieldMismatches.Add($"Aadhaar DOB mismatch: '{extractedData.DOB}' vs '{aadhaarData.Dob}'");
            }

            if (riskScore == 0)
            {
                notes.Add("Aadhaar verification passed");
            }

            return (riskScore, fieldMismatches, notes);
        }

        private async Task<(int RiskScore, List<string> FieldMismatches, List<string> Notes)> VerifyPanData(ExtractedDataDocuments extractedData)
        {
            var riskScore = 0;
            var fieldMismatches = new List<string>();
            var notes = new List<string>();

            var panData = await _context.OriginalPan
                .FirstOrDefaultAsync(p => p.PanNo == extractedData.PANNumber);

            if (panData == null)
            {
                riskScore += 30;
                fieldMismatches.Add("PAN record not found in original data");
                notes.Add("PAN verification failed - record not found");
                return (riskScore, fieldMismatches, notes);
            }

            // Compare name
            if (!CompareNames(extractedData.Name, panData.Name))
            {
                riskScore += 10;
                fieldMismatches.Add($"PAN name mismatch: '{extractedData.Name}' vs '{panData.Name}'");
            }

            // Compare PAN number
            if (extractedData.PANNumber != panData.PanNo)
            {
                riskScore += 10;
                fieldMismatches.Add($"PAN number mismatch: '{extractedData.PANNumber}' vs '{panData.PanNo}'");
            }

            // Compare DOB
            if (!CompareDates(extractedData.DOB?.ToString("yyyy-MM-dd"), panData.Dob))
            {
                riskScore += 10;
                fieldMismatches.Add($"PAN DOB mismatch: '{extractedData.DOB}' vs '{panData.Dob}'");
            }

            if (riskScore == 0)
            {
                notes.Add("PAN verification passed");
            }

            return (riskScore, fieldMismatches, notes);
        }

        private async Task<(int RiskScore, List<string> FieldMismatches, List<string> Notes)> VerifySurveyData(ExtractedDataDocuments extractedData)
        {
            var riskScore = 0;
            var fieldMismatches = new List<string>();
            var notes = new List<string>();

            var surveyData = await _context.OriginalSurveyNo
                .FirstOrDefaultAsync(s => s.SurveyNo == extractedData.SurveyNumber);

            if (surveyData == null)
            {
                riskScore += 30;
                fieldMismatches.Add("Survey record not found in original data");
                notes.Add("Survey verification failed - record not found");
                return (riskScore, fieldMismatches, notes);
            }

            // Compare survey number
            if (extractedData.SurveyNumber != surveyData.SurveyNo)
            {
                riskScore += 10;
                fieldMismatches.Add($"Survey number mismatch: '{extractedData.SurveyNumber}' vs '{surveyData.SurveyNo}'");
            }

            // Compare measuring area
            if (!CompareStrings(extractedData.MeasuringArea, surveyData.MeasuringArea))
            {
                riskScore += 10;
                fieldMismatches.Add($"Measuring area mismatch: '{extractedData.MeasuringArea}' vs '{surveyData.MeasuringArea}'");
            }

            // Compare village
            if (!CompareStrings(extractedData.Village, surveyData.Village))
            {
                riskScore += 10;
                fieldMismatches.Add($"Village mismatch: '{extractedData.Village}' vs '{surveyData.Village}'");
            }

            // Compare hobli
            if (!CompareStrings(extractedData.Hobli, surveyData.Hobli))
            {
                riskScore += 10;
                fieldMismatches.Add($"Hobli mismatch: '{extractedData.Hobli}' vs '{surveyData.Hobli}'");
            }

            // Compare taluk
            if (!CompareStrings(extractedData.Taluk, surveyData.Taluk))
            {
                riskScore += 10;
                fieldMismatches.Add($"Taluk mismatch: '{extractedData.Taluk}' vs '{surveyData.Taluk}'");
            }

            // Compare district
            if (!CompareStrings(extractedData.District, surveyData.District))
            {
                riskScore += 10;
                fieldMismatches.Add($"District mismatch: '{extractedData.District}' vs '{surveyData.District}'");
            }

            if (riskScore == 0)
            {
                notes.Add("Survey verification passed");
            }

            return (riskScore, fieldMismatches, notes);
        }

        private async Task UpdateUserUploadedDocuments(int extractedDataId, VerificationResultDto result)
        {
            try
            {
                // Get the extracted data record to find the user
                var extractedData = await _context.ExtractedDataDocuments
                    .FirstOrDefaultAsync(ed => ed.Id == extractedDataId);

                if (extractedData == null)
                {
                    _logger.LogWarning($"ExtractedDataDocuments record not found for ID: {extractedDataId}");
                    return;
                }

                // Find the user upload record by matching key fields
                // We'll match by name and other identifying fields
                var userUpload = await _context.UserUploadedDocuments
                    .Where(u => u.Name == extractedData.Name || 
                               u.AdhaarNo == extractedData.AadhaarNumber ||
                               u.PanNo == extractedData.PANNumber)
                    .FirstOrDefaultAsync();

                if (userUpload == null)
                {
                    _logger.LogWarning($"No matching UserUploadedDocuments found for extracted data ID: {extractedDataId}");
                    return;
                }

                // Update the specific user upload record
                userUpload.IsVerified = result.IsVerified;
                userUpload.RiskScore = (decimal)result.RiskScore;
                userUpload.VerificationNotes = result.VerificationNotes;
                userUpload.FieldMismatches = result.FieldMismatches;
                userUpload.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();
                _logger.LogInformation($"Updated UserUploadedDocuments record {userUpload.Id} for user {userUpload.UserId} with verification results");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating UserUploadedDocuments for extracted data ID: {extractedDataId}");
            }
        }

        private bool CompareNames(string name1, string name2)
        {
            if (string.IsNullOrEmpty(name1) || string.IsNullOrEmpty(name2))
                return false;

            // Normalize names for comparison (remove extra spaces, convert to lowercase)
            var normalizedName1 = name1.Trim().ToLowerInvariant();
            var normalizedName2 = name2.Trim().ToLowerInvariant();

            return normalizedName1 == normalizedName2;
        }

        private bool CompareDates(string date1, string date2)
        {
            if (string.IsNullOrEmpty(date1) || string.IsNullOrEmpty(date2))
                return false;

            // Try to parse dates and compare
            if (DateTime.TryParse(date1, out var parsedDate1) && DateTime.TryParse(date2, out var parsedDate2))
            {
                return parsedDate1.Date == parsedDate2.Date;
            }

            // If parsing fails, do string comparison
            return date1.Trim().Equals(date2.Trim(), StringComparison.OrdinalIgnoreCase);
        }

        private bool CompareStrings(string str1, string str2)
        {
            if (string.IsNullOrEmpty(str1) || string.IsNullOrEmpty(str2))
                return false;

            return str1.Trim().Equals(str2.Trim(), StringComparison.OrdinalIgnoreCase);
        }
    }
}

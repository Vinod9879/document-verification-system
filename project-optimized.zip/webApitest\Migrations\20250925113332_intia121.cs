﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace webApitest.Migrations
{
    /// <inheritdoc />
    public partial class intia121 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "PasswordHash" },
                values: new object[] { new DateTime(2025, 9, 25, 11, 33, 32, 48, DateTimeKind.Utc).AddTicks(7477), "$2a$11$6VZLp08MDAayVfBAZGXqS.rEi0H1/Xqqy9alEYre1V1YLukRfa8PW" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "PasswordHash" },
                values: new object[] { new DateTime(2025, 9, 25, 11, 28, 15, 177, DateTimeKind.Utc).AddTicks(2522), "$2a$11$dBEZgbEdDagp0wtTx6iJB.gPywHX0f0Aa1oQqHBfg.QYm46Ke9gw6" });
        }
    }
}

# 🔍 **DEBUG DATABASE ISSUES**

## **🚨 Problem: Data Not Saving to Database Tables**

### **Possible Causes:**
1. **Database Connection Issues** - Wrong connection string
2. **Table Doesn't Exist** - Migration not applied
3. **DLL Extraction Failing** - Files not found or extraction errors
4. **Transaction Issues** - SaveChanges failing silently
5. **File Path Issues** - Documents not saved correctly

---

## **🔧 Step-by-Step Debugging**

### **Step 1: Test Database Connection**
```bash
# Start the backend server
dotnet run --urls="http://localhost:5000"

# Test database connection
curl http://localhost:5000/api/UserDashboard/test-db-connection
```

**Expected Response:**
```json
{
  "message": "Database connection successful",
  "userUploadsCount": 0,
  "extractedDataCount": 0,
  "timestamp": "2024-01-01T00:00:00Z"
}
```

### **Step 2: Check Backend Logs**
Look for these log messages when uploading documents:

```
Starting DLL extraction for upload ID: 1
Found upload record with ID: 1, UserId: 1
Found upload record. EC Path: /path/to/EC.pdf
Extracting EC document: /path/to/EC.pdf
EC file does not exist: /path/to/EC.pdf  ← ERROR!
```

### **Step 3: Check File Paths**
Verify files are being saved correctly:
- **Upload Directory**: `webApitest/Uploads/UserDocuments/{userId}/`
- **File Names**: `EC_{timestamp}.pdf`, `Aadhaar_{timestamp}.png`, `PAN_{timestamp}.png`

### **Step 4: Check Database Tables**
```sql
-- Check if tables exist
SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES 
WHERE TABLE_NAME IN ('UserUploadedDocuments', 'ExtractedDataDocuments');

-- Check records
SELECT COUNT(*) FROM UserUploadedDocuments;
SELECT COUNT(*) FROM ExtractedDataDocuments;
```

---

## **🛠️ Quick Fixes**

### **Fix 1: Verify Connection String**
```json
// In appsettings.json
{
  "ConnectionStrings": {
    "DefaultConnection": "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ContactManagementDB_Dev;Integrated Security=True"
  }
}
```

### **Fix 2: Check Table Exists**
```sql
-- Run this in SQL Server Management Studio
USE ContactManagementDB_Dev;
GO

-- Check if ExtractedDataDocuments table exists
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ExtractedDataDocuments]') AND type in (N'U'))
BEGIN
    PRINT 'Table does not exist - creating...';
    -- Run the CREATE TABLE script
END
```

### **Fix 3: Check File Upload**
1. **Upload a document** as a user
2. **Check the upload directory** exists: `webApitest/Uploads/UserDocuments/{userId}/`
3. **Verify files are saved** with correct names and extensions

### **Fix 4: Check DLL Extraction**
1. **Check if DLL files exist** in the project
2. **Verify file paths** in the logs
3. **Check if OCR/Tesseract** is working

---

## **📊 Debugging Checklist**

### **Backend Issues:**
- [ ] Database connection working
- [ ] Tables exist in database
- [ ] Files are being saved correctly
- [ ] DLL extraction is being called
- [ ] No errors in backend logs

### **Frontend Issues:**
- [ ] Upload request reaches backend
- [ ] Files are being sent correctly
- [ ] No JavaScript errors in browser console
- [ ] API responses are successful

### **Database Issues:**
- [ ] Connection string is correct
- [ ] Database exists and is accessible
- [ ] Tables are created with correct schema
- [ ] No permission issues

---

## **🚀 Testing Commands**

### **Test Database Connection:**
```bash
curl http://localhost:5000/api/UserDashboard/test-db-connection
```

### **Test Admin Database:**
```bash
curl http://localhost:5000/api/AdminDashboard/test-database
```

### **Check Backend Logs:**
```bash
# Look for these messages in the console:
# "Starting DLL extraction for upload ID: X"
# "Found upload record with ID: X"
# "Extracting EC document: /path/to/file"
# "Saving extracted data to ExtractedDataDocuments table"
```

---

## **⚠️ Common Issues & Solutions**

### **Issue: "Table doesn't exist"**
**Solution:** Run migration or create table manually
```bash
dotnet ef database update
```

### **Issue: "File not found"**
**Solution:** Check file paths and upload directory permissions

### **Issue: "DLL extraction failing"**
**Solution:** Check DLL files and OCR dependencies

### **Issue: "Database connection failed"**
**Solution:** Verify connection string and database exists

### **Issue: "No data in tables"**
**Solution:** Check if extraction is being called and if files exist

---

## **🎯 Success Indicators**

### **When Everything Works:**
- ✅ Database connection test passes
- ✅ Files are saved to upload directory
- ✅ DLL extraction logs show successful extraction
- ✅ Data appears in both `UserUploadedDocuments` and `ExtractedDataDocuments` tables
- ✅ Admin can view extracted data

### **Debug Messages to Look For:**
```
About to call DLL extraction for upload ID: 1
Starting DLL extraction for upload ID: 1
Found upload record with ID: 1, UserId: 1
Extracting EC document: /path/to/EC.pdf
EC extraction completed. Name: John Doe
Saving extracted data to ExtractedDataDocuments table
Successfully extracted and saved data for upload 1
```

The system should now provide detailed logging to help identify exactly where the issue is occurring! 🔍

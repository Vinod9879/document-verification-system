﻿using webApitest.Models;
using webApitest.Models.DTOs;
using webApitest.Data;
using DocumentVerificationDLL;
using Microsoft.EntityFrameworkCore;

namespace webApitest.Services
{
    public interface IDocumentExtractionService
    {
        Task<ExtractedDataDto> ExtractECAsync(string filePath);
        Task<ExtractedDataDto> ExtractAadhaarAsync(string filePath);
        Task<ExtractedDataDto> ExtractPANAsync(string filePath);
        Task<VerificationResultDto> VerifyDocumentsAsync(int uploadedDocumentId);
    }

    public class DocumentExtractionService : IDocumentExtractionService
    {
        private readonly ILogger<DocumentExtractionService> _logger;
        private readonly IRiskCalculationService _riskCalculationService;
        private readonly ApplicationDbContext _context;

        public DocumentExtractionService(ILogger<DocumentExtractionService> logger, IRiskCalculationService riskCalculationService, ApplicationDbContext context)
        {
            _logger = logger;
            _riskCalculationService = riskCalculationService;
            _context = context;
        }

        public async Task<ExtractedDataDto> ExtractECAsync(string filePath)
        {
            try
            {
                _logger.LogInformation($"Extracting EC document: {filePath}");
                _logger.LogInformation($"File exists check: {System.IO.File.Exists(filePath)}");
                _logger.LogInformation($"File size: {new FileInfo(filePath).Length} bytes");
                
                // Call DLL for EC extraction
                var dll = new DocumentVerificationDLL.DocumentVerificationDLL(_logger as Microsoft.Extensions.Logging.ILogger<DocumentVerificationDLL.DocumentVerificationDLL> ?? 
                    Microsoft.Extensions.Logging.Abstractions.NullLogger<DocumentVerificationDLL.DocumentVerificationDLL>.Instance);
                var extractedData = await dll.ExtractECAsync(filePath);
                
                // Validate extracted data quality
                if (!IsValidExtractedData(extractedData, "EC"))
                {
                    _logger.LogWarning("EC document extraction quality is low - some fields may be missing");
                }
                
                return new ExtractedDataDto
                {
                    Name = extractedData.Name,
                    DOB = extractedData.DOB,
                    SurveyNumber = extractedData.SurveyNumber,
                    Address = extractedData.Address,
                    ECNumber = extractedData.ECNumber,
                    PropertyDetails = extractedData.PropertyDetails,
                    ApplicationNumber = extractedData.ApplicationNumber,
                    MeasuringArea = extractedData.MeasuringArea,
                    Village = extractedData.Village,
                    Hobli = extractedData.Hobli,
                    Taluk = extractedData.Taluk,
                    District = extractedData.District,
                    ConfidenceScore = extractedData.ConfidenceScore,
                    ExtractionNotes = extractedData.ExtractionNotes
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error extracting EC document: {filePath}");
                throw;
            }
        }

        public async Task<ExtractedDataDto> ExtractAadhaarAsync(string filePath)
        {
            try
            {
                _logger.LogInformation($"Extracting Aadhaar document: {filePath}");
                _logger.LogInformation($"File exists check: {System.IO.File.Exists(filePath)}");
                _logger.LogInformation($"File size: {new FileInfo(filePath).Length} bytes");
                
                // Call DLL for Aadhaar extraction
                var dll = new DocumentVerificationDLL.DocumentVerificationDLL(_logger as Microsoft.Extensions.Logging.ILogger<DocumentVerificationDLL.DocumentVerificationDLL> ?? 
                    Microsoft.Extensions.Logging.Abstractions.NullLogger<DocumentVerificationDLL.DocumentVerificationDLL>.Instance);
                var extractedData = await dll.ExtractAadhaarAsync(filePath);
                
                // Validate extracted data quality
                if (!IsValidExtractedData(extractedData, "Aadhaar"))
                {
                    _logger.LogWarning("Aadhaar document extraction quality is low - some fields may be missing");
                }
                
                return new ExtractedDataDto
                {
                    Name = extractedData.Name,
                    DOB = extractedData.DOB,
                    AadhaarNumber = extractedData.AadhaarNumber,
                    Address = extractedData.Address,
                    FatherName = extractedData.FatherName,
                    MotherName = extractedData.MotherName,
                    ConfidenceScore = extractedData.ConfidenceScore,
                    ExtractionNotes = extractedData.ExtractionNotes
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error extracting Aadhaar document: {filePath}");
                throw;
            }
        }

        public async Task<ExtractedDataDto> ExtractPANAsync(string filePath)
        {
            try
            {
                _logger.LogInformation($"Extracting PAN document: {filePath}");
                _logger.LogInformation($"File exists check: {System.IO.File.Exists(filePath)}");
                _logger.LogInformation($"File size: {new FileInfo(filePath).Length} bytes");
                
                // Call DLL for PAN extraction
                var dll = new DocumentVerificationDLL.DocumentVerificationDLL(_logger as Microsoft.Extensions.Logging.ILogger<DocumentVerificationDLL.DocumentVerificationDLL> ?? 
                    Microsoft.Extensions.Logging.Abstractions.NullLogger<DocumentVerificationDLL.DocumentVerificationDLL>.Instance);
                var extractedData = await dll.ExtractPANAsync(filePath);
                
                // Validate extracted data quality
                if (!IsValidExtractedData(extractedData, "PAN"))
                {
                    _logger.LogWarning("PAN document extraction quality is low - some fields may be missing");
                }
                
                return new ExtractedDataDto
                {
                    Name = extractedData.Name,
                    DOB = extractedData.DOB,
                    PANNumber = extractedData.PANNumber,
                    FatherName = extractedData.FatherName,
                    ConfidenceScore = extractedData.ConfidenceScore,
                    ExtractionNotes = extractedData.ExtractionNotes
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error extracting PAN document: {filePath}");
                throw;
            }
        }

        public async Task<VerificationResultDto> VerifyDocumentsAsync(int uploadedDocumentId)
        {
            try
            {
                _logger.LogInformation($"Verifying documents for upload ID: {uploadedDocumentId}");
                
                // Get uploaded document data
                var uploadedDoc = await _context.UserUploadedDocuments.FindAsync(uploadedDocumentId);
                if (uploadedDoc == null)
                {
                    return new VerificationResultDto
                    {
                        IsVerified = false,
                        RiskScore = 100,
                        VerificationNotes = "Document not found",
                        FieldMismatches = "Document not found"
                    };
                }

                var verificationResults = new List<string>();
                var fieldMismatches = new List<string>();
                var totalRiskScore = 0m;
                var verificationPoints = 0;

                // 1. AADHAAR VERIFICATION
                var aadhaarResult = await VerifyAadhaarAsync(uploadedDoc);
                verificationResults.Add($"Aadhaar: {aadhaarResult.Status}");
                if (aadhaarResult.Mismatches.Any())
                    fieldMismatches.AddRange(aadhaarResult.Mismatches);
                totalRiskScore += aadhaarResult.RiskScore;
                verificationPoints += aadhaarResult.Points;

                // 2. PAN VERIFICATION
                var panResult = await VerifyPANAsync(uploadedDoc);
                verificationResults.Add($"PAN: {panResult.Status}");
                if (panResult.Mismatches.Any())
                    fieldMismatches.AddRange(panResult.Mismatches);
                totalRiskScore += panResult.RiskScore;
                verificationPoints += panResult.Points;

                // 3. EC/SURVEY VERIFICATION
                var ecResult = await VerifyECAsync(uploadedDoc);
                verificationResults.Add($"EC: {ecResult.Status}");
                if (ecResult.Mismatches.Any())
                    fieldMismatches.AddRange(ecResult.Mismatches);
                totalRiskScore += ecResult.RiskScore;
                verificationPoints += ecResult.Points;

                // Calculate final verification status
                var isVerified = totalRiskScore <= 30 && verificationPoints >= 6; // Need at least 6 points and low risk
                var finalRiskScore = Math.Min(totalRiskScore, 100);

                return new VerificationResultDto
                {
                    IsVerified = isVerified,
                    RiskScore = (int)finalRiskScore,
                    VerificationNotes = string.Join("; ", verificationResults),
                    FieldMismatches = string.Join("; ", fieldMismatches)
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error verifying documents for upload ID: {uploadedDocumentId}");
                throw;
            }
        }

        #region Verification Methods

        private async Task<VerificationResult> VerifyAadhaarAsync(UserUploadedDocuments uploadedDoc)
        {
            var result = new VerificationResult();
            
            if (string.IsNullOrEmpty(uploadedDoc.AdhaarNo))
            {
                result.Status = "FAIL - No Aadhaar Number";
                result.RiskScore = 50;
                result.Mismatches.Add("AadhaarNo: Missing");
                return result;
            }

            // Find matching original Aadhaar record
            var originalAadhaar = await _context.OriginalAdhar
                .FirstOrDefaultAsync(o => o.AdhaarNo == uploadedDoc.AdhaarNo);

            if (originalAadhaar == null)
            {
                result.Status = "FAIL - Aadhaar Number Not Found in Records";
                result.RiskScore = 40;
                result.Mismatches.Add("AadhaarNo: Not found in original records");
                return result;
            }

            // Compare fields
            var mismatches = new List<string>();
            var riskScore = 0m;
            var points = 0;

            // Aadhaar Number match (primary)
            if (uploadedDoc.AdhaarNo == originalAadhaar.AdhaarNo)
            {
                points += 3; // Primary field
            }
            else
            {
                mismatches.Add("AadhaarNo: Mismatch");
                riskScore += 30;
            }

            // Name comparison
            if (CompareNames(uploadedDoc.AdhaarFullName, originalAadhaar.Name))
            {
                points += 2;
            }
            else
            {
                mismatches.Add("AadhaarName: Mismatch");
                riskScore += 20;
            }

            // DOB comparison
            if (CompareDates(uploadedDoc.Dob, originalAadhaar.Dob))
            {
                points += 2;
            }
            else
            {
                mismatches.Add("AadhaarDOB: Mismatch");
                riskScore += 20;
            }

            // Determine status
            if (points >= 6)
            {
                result.Status = "VERIFIED";
                result.Points = points;
                result.RiskScore = riskScore;
            }
            else if (points >= 4)
            {
                result.Status = "REVIEW REQUIRED";
                result.Points = points;
                result.RiskScore = riskScore + 10;
            }
            else
            {
                result.Status = "FAIL";
                result.Points = points;
                result.RiskScore = riskScore + 20;
            }

            result.Mismatches = mismatches;
            return result;
        }

        private async Task<VerificationResult> VerifyPANAsync(UserUploadedDocuments uploadedDoc)
        {
            var result = new VerificationResult();
            
            if (string.IsNullOrEmpty(uploadedDoc.PanNo))
            {
                result.Status = "FAIL - No PAN Number";
                result.RiskScore = 50;
                result.Mismatches.Add("PanNo: Missing");
                return result;
            }

            // Validate PAN format
            if (!IsValidPANFormat(uploadedDoc.PanNo))
            {
                result.Status = "FAIL - Invalid PAN Format";
                result.RiskScore = 40;
                result.Mismatches.Add("PanNo: Invalid format");
                return result;
            }

            // Find matching original PAN record
            var originalPAN = await _context.OriginalPan
                .FirstOrDefaultAsync(o => o.PanNo == uploadedDoc.PanNo);

            if (originalPAN == null)
            {
                result.Status = "FAIL - PAN Number Not Found in Records";
                result.RiskScore = 40;
                result.Mismatches.Add("PanNo: Not found in original records");
                return result;
            }

            // Compare fields
            var mismatches = new List<string>();
            var riskScore = 0m;
            var points = 0;

            // PAN Number match (primary)
            if (uploadedDoc.PanNo == originalPAN.PanNo)
            {
                points += 3; // Primary field
            }
            else
            {
                mismatches.Add("PanNo: Mismatch");
                riskScore += 30;
            }

            // Name comparison
            if (CompareNames(uploadedDoc.PanFullName, originalPAN.Name))
            {
                points += 2;
            }
            else
            {
                mismatches.Add("PanName: Mismatch");
                riskScore += 20;
            }

            // DOB comparison
            if (CompareDates(uploadedDoc.Dob, originalPAN.Dob))
            {
                points += 2;
            }
            else
            {
                mismatches.Add("PanDOB: Mismatch");
                riskScore += 20;
            }

            // Determine status
            if (points >= 6)
            {
                result.Status = "VERIFIED";
                result.Points = points;
                result.RiskScore = riskScore;
            }
            else if (points >= 4)
            {
                result.Status = "REVIEW REQUIRED";
                result.Points = points;
                result.RiskScore = riskScore + 10;
            }
            else
            {
                result.Status = "FAIL";
                result.Points = points;
                result.RiskScore = riskScore + 20;
            }

            result.Mismatches = mismatches;
            return result;
        }

        private async Task<VerificationResult> VerifyECAsync(UserUploadedDocuments uploadedDoc)
        {
            var result = new VerificationResult();
            
            if (string.IsNullOrEmpty(uploadedDoc.SurveyNo))
            {
                result.Status = "FAIL - No Survey Number";
                result.RiskScore = 50;
                result.Mismatches.Add("SurveyNo: Missing");
                return result;
            }

            // Find matching original Survey record
            var originalSurvey = await _context.OriginalSurveyNo
                .FirstOrDefaultAsync(o => o.SurveyNo == uploadedDoc.SurveyNo);

            if (originalSurvey == null)
            {
                result.Status = "FAIL - Survey Number Not Found in Records";
                result.RiskScore = 40;
                result.Mismatches.Add("SurveyNo: Not found in original records");
                return result;
            }

            // Compare fields
            var mismatches = new List<string>();
            var riskScore = 0m;
            var points = 0;

            // Survey Number match (primary)
            if (uploadedDoc.SurveyNo == originalSurvey.SurveyNo)
            {
                points += 3; // Primary field
            }
            else
            {
                mismatches.Add("SurveyNo: Mismatch");
                riskScore += 30;
            }

            // Location fields comparison
            if (CompareStrings(uploadedDoc.Village, originalSurvey.Village))
            {
                points += 1;
            }
            else
            {
                mismatches.Add("Village: Mismatch");
                riskScore += 10;
            }

            if (CompareStrings(uploadedDoc.Hobli, originalSurvey.Hobli))
            {
                points += 1;
            }
            else
            {
                mismatches.Add("Hobli: Mismatch");
                riskScore += 10;
            }

            if (CompareStrings(uploadedDoc.Taluk, originalSurvey.Taluk))
            {
                points += 1;
            }
            else
            {
                mismatches.Add("Taluk: Mismatch");
                riskScore += 10;
            }

            if (CompareStrings(uploadedDoc.District, originalSurvey.District))
            {
                points += 1;
            }
            else
            {
                mismatches.Add("District: Mismatch");
                riskScore += 10;
            }

            if (CompareStrings(uploadedDoc.MeasuringArea, originalSurvey.MeasuringArea))
            {
                points += 1;
            }
            else
            {
                mismatches.Add("MeasuringArea: Mismatch");
                riskScore += 10;
            }

            // Determine status
            if (points >= 6)
            {
                result.Status = "VERIFIED";
                result.Points = points;
                result.RiskScore = riskScore;
            }
            else if (points >= 4)
            {
                result.Status = "REVIEW REQUIRED";
                result.Points = points;
                result.RiskScore = riskScore + 10;
            }
            else
            {
                result.Status = "FAIL";
                result.Points = points;
                result.RiskScore = riskScore + 20;
            }

            result.Mismatches = mismatches;
            return result;
        }

        #endregion

        #region Helper Methods

        private bool CompareNames(string name1, string name2)
        {
            if (string.IsNullOrEmpty(name1) || string.IsNullOrEmpty(name2))
                return false;

            // Normalize names (remove extra spaces, convert to uppercase)
            var normalized1 = NormalizeName(name1);
            var normalized2 = NormalizeName(name2);

            // Exact match
            if (normalized1 == normalized2)
                return true;

            // Fuzzy match for minor differences
            return CalculateSimilarity(normalized1, normalized2) >= 0.8;
        }

        private bool CompareDates(string date1, string date2)
        {
            if (string.IsNullOrEmpty(date1) || string.IsNullOrEmpty(date2))
                return false;

            // Try to parse dates and compare
            if (DateTime.TryParse(date1, out var dt1) && DateTime.TryParse(date2, out var dt2))
            {
                return dt1.Date == dt2.Date;
            }

            // String comparison for different formats
            return NormalizeDate(date1) == NormalizeDate(date2);
        }

        private bool CompareStrings(string str1, string str2)
        {
            if (string.IsNullOrEmpty(str1) || string.IsNullOrEmpty(str2))
                return false;

            var normalized1 = str1.Trim().ToUpper();
            var normalized2 = str2.Trim().ToUpper();

            return normalized1 == normalized2;
        }

        private string NormalizeName(string name)
        {
            return name.Trim().ToUpper().Replace(" ", "");
        }

        private string NormalizeDate(string date)
        {
            return date.Trim().Replace("/", "").Replace("-", "");
        }

        private bool IsValidPANFormat(string pan)
        {
            if (string.IsNullOrEmpty(pan) || pan.Length != 10)
                return false;

            // PAN format: 5 letters + 4 digits + 1 letter
            return System.Text.RegularExpressions.Regex.IsMatch(pan, @"^[A-Z]{5}[0-9]{4}[A-Z]$");
        }

        private double CalculateSimilarity(string str1, string str2)
        {
            if (str1 == str2) return 1.0;
            if (string.IsNullOrEmpty(str1) || string.IsNullOrEmpty(str2)) return 0.0;

            var longer = str1.Length > str2.Length ? str1 : str2;
            var shorter = str1.Length > str2.Length ? str2 : str1;

            if (longer.Length == 0) return 1.0;

            var editDistance = LevenshteinDistance(longer, shorter);
            return (longer.Length - editDistance) / (double)longer.Length;
        }

        private int LevenshteinDistance(string str1, string str2)
        {
            var matrix = new int[str1.Length + 1, str2.Length + 1];

            for (int i = 0; i <= str1.Length; i++)
                matrix[i, 0] = i;

            for (int j = 0; j <= str2.Length; j++)
                matrix[0, j] = j;

            for (int i = 1; i <= str1.Length; i++)
            {
                for (int j = 1; j <= str2.Length; j++)
                {
                    var cost = str1[i - 1] == str2[j - 1] ? 0 : 1;
                    matrix[i, j] = Math.Min(
                        Math.Min(matrix[i - 1, j] + 1, matrix[i, j - 1] + 1),
                        matrix[i - 1, j - 1] + cost);
                }
            }

            return matrix[str1.Length, str2.Length];
        }

        private bool IsValidExtractedData(ExtractedData data, string documentType)
        {
            if (data == null) return false;

            switch (documentType.ToLower())
            {
                case "ec":
                    return !string.IsNullOrEmpty(data.Name) && 
                           !string.IsNullOrEmpty(data.SurveyNumber) &&
                           !string.IsNullOrEmpty(data.ApplicationNumber);
                
                case "aadhaar":
                    return !string.IsNullOrEmpty(data.Name) && 
                           !string.IsNullOrEmpty(data.AadhaarNumber) &&
                           !string.IsNullOrEmpty(data.DOB);
                
                case "pan":
                    return !string.IsNullOrEmpty(data.Name) && 
                           !string.IsNullOrEmpty(data.PANNumber) &&
                           !string.IsNullOrEmpty(data.DOB);
                
                default:
                    return false;
            }
        }

        #endregion
    }

    public class VerificationResult
    {
        public string Status { get; set; } = "";
        public decimal RiskScore { get; set; }
        public int Points { get; set; }
        public List<string> Mismatches { get; set; } = new List<string>();
    }

}

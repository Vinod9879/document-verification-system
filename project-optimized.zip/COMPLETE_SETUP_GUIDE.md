# Document Verification System - Complete Setup Guide

## 🚀 System Overview

A complete document verification and risk assessment platform with:
- **Frontend**: React 18 + Vite (Modern, fast development)
- **Backend**: ASP.NET Core 8 Web API
- **Database**: SQL Server LocalDB
- **Security**: JWT Authentication, CSP Headers, Input Validation
- **Features**: AI-powered document extraction, risk scoring, admin dashboard

## 📁 Project Structure

```
Document Verification System/
├── react-contacts-app/          # React Frontend (Vite)
│   ├── src/
│   │   ├── Components/          # React Components
│   │   ├── Services/            # API Services
│   │   ├── Routes/              # Routing
│   │   └── config/              # Configuration
│   ├── package.json             # Frontend Dependencies
│   ├── vite.config.js           # Vite Configuration
│   └── index.html               # Main HTML
├── webApitest/                  # ASP.NET Core Backend
│   ├── Controllers/             # API Controllers
│   ├── Services/                # Business Logic
│   ├── Models/                  # Data Models
│   ├── Data/                    # Database Context
│   └── webApitest.csproj        # Backend Project
└── DocumentVerificationDLL/     # Custom DLL for Document Processing
```

## 🛠️ Prerequisites

- **Node.js** 18+ (for React frontend)
- **.NET 8 SDK** (for backend API)
- **SQL Server LocalDB** (included with Visual Studio)
- **Git** (for version control)

## 🚀 Quick Start

### Option 1: Automated Setup
```bash
# Run the complete setup script
setup-complete.bat
```

### Option 2: Manual Setup

#### 1. Frontend Setup
```bash
cd react-contacts-app
npm install
npm run build
```

#### 2. Backend Setup
```bash
cd webApitest
dotnet build
dotnet ef database update
```

#### 3. Start Services
```bash
# Terminal 1 - Backend API
cd webApitest
dotnet run

# Terminal 2 - Frontend
cd react-contacts-app
npm run dev
```

## 🌐 Access Points

- **Frontend**: http://localhost:3000
- **Backend API**: https://localhost:50538
- **API Documentation**: https://localhost:50538/swagger

## 👤 Default Credentials

### Admin Access
- **Username**: `admin@contactmanager.com`
- **Password**: `admin123`

### User Registration
- Users can register through the frontend
- Email verification required
- Role-based access control

## 🔧 Configuration

### Frontend Configuration
```javascript
// react-contacts-app/src/config/api.js
const API_BASE_URL = process.env.REACT_APP_API_URL || 'https://localhost:50538/api';
```

### Backend Configuration
```json
// webApitest/appsettings.json
{
  "ConnectionStrings": {
    "DefaultConnection": "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=UserAuthDB;Integrated Security=True"
  }
}
```

## 📋 Features

### User Features
- ✅ User Registration & Login
- ✅ Document Upload (EC, Aadhaar, PAN)
- ✅ AI-powered Document Extraction
- ✅ Risk Assessment & Scoring
- ✅ Verification Status Tracking
- ✅ Upload History

### Admin Features
- ✅ User Management
- ✅ Document Monitoring
- ✅ Analytics Dashboard
- ✅ Activity Logs
- ✅ Manual Verification
- ✅ Risk Score Analysis

### Security Features
- ✅ JWT Authentication
- ✅ Role-based Authorization
- ✅ Content Security Policy (CSP)
- ✅ XSS Protection
- ✅ Input Validation
- ✅ Secure File Upload

## 🗄️ Database Schema

### Core Tables
- **Users**: User accounts and profiles
- **UserUploadedDocuments**: Document uploads and extracted data
- **OriginalDocuments**: Reference documents for verification
- **UserActivityLogs**: System activity tracking

### Key Fields
```sql
-- UserUploadedDocuments
- Id, UserId, ECPath, AadhaarPath, PANPath
- ExtractedData (JSON), IsVerified, RiskScore
- VerificationNotes, FieldMismatches
- SubmittedAt, CreatedAt, UpdatedAt
```

## 🔄 API Endpoints

### Authentication
- `POST /api/Auth/login` - User login
- `POST /api/Auth/register` - User registration
- `POST /api/Auth/admin-login` - Admin login

### User Dashboard
- `GET /api/UserDashboard/profile` - Get user profile
- `PUT /api/UserDashboard/profile` - Update profile
- `POST /api/UserDashboard/upload-documents` - Upload documents
- `GET /api/UserDashboard/document-status` - Get document status

### Admin Dashboard
- `GET /api/AdminDashboard/users` - Get all users
- `GET /api/AdminDashboard/documents` - Get all documents
- `POST /api/AdminDashboard/documents/{id}/verify` - Trigger verification
- `GET /api/AdminDashboard/analytics` - Get analytics

## 🚨 Troubleshooting

### Common Issues

#### Frontend Issues
```bash
# Clear cache and reinstall
npm run clean
npm install
npm run dev
```

#### Backend Issues
```bash
# Clean and rebuild
dotnet clean
dotnet build
dotnet run
```

#### Database Issues
```bash
# Reset database
dotnet ef database drop
dotnet ef database update
```

### Port Conflicts
- Frontend: Change port in `vite.config.js`
- Backend: Change port in `launchSettings.json`

## 📊 Performance

### Frontend (Vite)
- ⚡ Fast HMR (Hot Module Replacement)
- 📦 Optimized bundle splitting
- 🗜️ Gzip compression
- 🚀 Production builds in ~3 seconds

### Backend (ASP.NET Core)
- 🏃 High-performance async operations
- 🔄 Entity Framework Core optimization
- 📈 Built-in health checks
- 🛡️ Security middleware

## 🔒 Security Checklist

- ✅ HTTPS enforcement
- ✅ JWT token validation
- ✅ Input sanitization
- ✅ File upload restrictions
- ✅ CORS configuration
- ✅ Security headers
- ✅ SQL injection prevention
- ✅ XSS protection

## 📈 Monitoring

### Logs
- Application logs in `webApitest/Logs/`
- User activity tracking in database
- Error handling with detailed messages

### Analytics
- User registration trends
- Document upload statistics
- Risk score distribution
- Verification success rates

## 🚀 Deployment

### Frontend Deployment
```bash
npm run build
# Deploy dist/ folder to web server
```

### Backend Deployment
```bash
dotnet publish -c Release
# Deploy published files to server
```

### Database Migration
```bash
dotnet ef database update
```

## 📞 Support

For issues or questions:
1. Check the troubleshooting section
2. Review the logs for error details
3. Verify all prerequisites are installed
4. Ensure database connection is working

## 🎯 Next Steps

1. **Customize Branding**: Update logos, colors, and text
2. **Add Features**: Implement additional document types
3. **Enhance Security**: Add two-factor authentication
4. **Scale**: Configure for production deployment
5. **Monitor**: Set up application monitoring

---

**System Status**: ✅ Ready for Development & Production
**Last Updated**: January 2025
**Version**: 1.0.0

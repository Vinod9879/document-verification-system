import React, { useState, useEffect } from 'react';
import { useAuth } from '../../Services/AuthService';
import userService from '../../Services/UserService';
import documentService from '../../Services/DocumentService';
import Card from '../Common/Card';
import Button from '../Common/Button';
import VerificationResults from './VerificationResults';

const UserDashboard = () => {
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');
  
  // Document upload states
  const [documentStatus, setDocumentStatus] = useState(null);
  const [extractedData, setExtractedData] = useState(null);
  const [uploadHistory, setUploadHistory] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [processingStatus, setProcessingStatus] = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState({
    EC: null,
    Aadhaar: null,
    PAN: null
  });

  // Profile editing states
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [editProfileData, setEditProfileData] = useState({
    fullName: '',
    phone: '',
    city: '',
    state: '',
    pincode: ''
  });
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [updating, setUpdating] = useState(false);
  const [statusUpdated, setStatusUpdated] = useState(false);

  useEffect(() => {
    fetchUserProfile();
    fetchDocumentStatus();
    fetchUploadHistory();
    
    // Auto-refresh document status every 30 seconds
    const interval = setInterval(() => {
      fetchDocumentStatus();
    }, 30000);
    
    return () => clearInterval(interval);
  }, []);

  const fetchUserProfile = async () => {
    try {
      setLoading(true);
      const profileData = await documentService.getUserProfile();
      setProfile(profileData);
    } catch (error) {
      console.error('Profile loading error:', error);
      setMessage('Failed to load profile information.');
    } finally {
      setLoading(false);
    }
  };

  const fetchDocumentStatus = async () => {
    try {
      setRefreshing(true);
      console.log('Fetching document status...');
      const status = await documentService.getDocumentStatus();
      console.log('Document status response:', status);
      
      // Check if status has changed
      if (documentStatus && status) {
        const statusChanged = documentStatus.isVerified !== status.isVerified || 
                             documentStatus.riskScore !== status.riskScore;
        if (statusChanged) {
          setStatusUpdated(true);
          setTimeout(() => setStatusUpdated(false), 3000); // Hide notification after 3 seconds
        }
      }
      
      setDocumentStatus(status);
      
      if (status && status.extractedData) {
        const extracted = await documentService.getExtractedData();
        console.log('Extracted data response:', extracted);
        setExtractedData(extracted);
      }
    } catch (error) {
      console.log('No documents uploaded yet or API error:', error);
      // Don't set mock data - let the user upload real documents
      setDocumentStatus(null);
      setExtractedData(null);
    } finally {
      setRefreshing(false);
    }
  };

  const fetchUploadHistory = async () => {
    try {
      const history = await documentService.getUploadHistory();
      console.log('Upload history response:', history);
      
      // Handle different response structures
      if (Array.isArray(history)) {
        setUploadHistory(history);
      } else if (history && Array.isArray(history.uploads)) {
        setUploadHistory(history.uploads);
      } else if (history && Array.isArray(history.data)) {
        setUploadHistory(history.data);
      } else {
        // No history available
        setUploadHistory([]);
      }
    } catch (error) {
      console.log('No upload history available:', error);
      // No mock data - show empty state
      setUploadHistory([]);
    }
  };

  const handleFileChange = (documentType, file) => {
    setSelectedFiles(prev => ({
      ...prev,
      [documentType]: file
    }));
  };

  const handleDocumentUpload = async () => {
    if (!selectedFiles.EC || !selectedFiles.Aadhaar || !selectedFiles.PAN) {
      setMessage('Please select all three documents (EC, Aadhaar, PAN)');
      return;
    }

    try {
      setUploading(true);
      setMessage('');

      const formData = new FormData();
      formData.append('EC', selectedFiles.EC);
      formData.append('Aadhaar', selectedFiles.Aadhaar);
      formData.append('PAN', selectedFiles.PAN);

      const response = await documentService.uploadDocuments(formData);
      
      if (response.isSecondRound) {
        setMessage('Second round documents uploaded successfully! New verification will be processed...');
      } else {
        setMessage('Documents uploaded successfully! Processing...');
      }
      
      // Force immediate refresh first
      await fetchDocumentStatus();
      await fetchUploadHistory();
      
      // Then refresh again after a delay to ensure backend processing is complete
      setTimeout(async () => {
        await fetchDocumentStatus();
        await fetchUploadHistory();
        
        // Check processing status if document ID is returned
        if (response.documentId) {
          await checkProcessingStatus(response.documentId);
        }
      }, 2000);
      
      // Clear selected files
      setSelectedFiles({ EC: null, Aadhaar: null, PAN: null });
    } catch (error) {
      setMessage('Failed to upload documents. Please try again.');
    } finally {
      setUploading(false);
    }
  };


  const checkProcessingStatus = async (documentId) => {
    try {
      const status = await documentService.getProcessingStatus(documentId);
      setProcessingStatus(status);
      
      // If still processing, check again in 5 seconds
      if (status.ProcessingStatus === 'Processing') {
        setTimeout(() => checkProcessingStatus(documentId), 5000);
      }
    } catch (error) {
      console.log('Error checking processing status:', error);
    }
  };

  const getRiskScoreColor = (score) => {
    if (score <= 30) return 'success';
    if (score <= 70) return 'warning';
    return 'danger';
  };

  const getRiskScoreText = (score) => {
    if (score <= 30) return 'Low Risk';
    if (score <= 70) return 'Medium Risk';
    return 'High Risk';
  };

  const viewUploadDetails = (upload) => {
    // Show detailed information about the upload
    const details = `
Upload Date: ${new Date(upload.submittedAt).toLocaleString()}
Status: ${upload.isVerified ? 'Verified' : 'Pending'}
Risk Score: ${upload.riskScore}/100 - ${getRiskScoreText(upload.riskScore)}
Documents: ${upload.ecPath ? 'EC ✓' : 'EC ✗'} | ${upload.aadhaarPath ? 'Aadhaar ✓' : 'Aadhaar ✗'} | ${upload.panPath ? 'PAN ✓' : 'PAN ✗'}
Verification Notes: ${upload.verificationNotes || 'None'}
Field Mismatches: ${upload.fieldMismatches || 'None'}
    `;
    alert(details);
  };

  const getInitials = (name) => {
    return name
      .split(' ')
      .map(word => word.charAt(0))
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  // Profile editing handlers
  const handleEditProfile = () => {
    if (profile) {
      setEditProfileData({
        fullName: profile.fullName || '',
        phone: profile.phone || '',
        city: profile.city || '',
        state: profile.state || '',
        pincode: profile.pincode || ''
      });
    }
    setShowEditProfile(true);
  };

  const handleSaveProfile = async () => {
    try {
      setUpdating(true);
      setMessage('');
      
      console.log('Updating profile with data:', editProfileData);
      console.log('API endpoint: /UserDashboard/profile');
      
      const response = await documentService.updateUserProfile(editProfileData);
      console.log('Profile update response:', response);
      
      setMessage('Profile updated successfully!');
      setShowEditProfile(false);
      
      // Refresh profile data
      await fetchUserProfile();
    } catch (error) {
      console.error('Profile update error:', error);
      console.error('Error details:', {
        message: error.message,
        status: error.response?.status,
        data: error.response?.data,
        config: error.config
      });
      
      let errorMessage = 'Failed to update profile. Please try again.';
      
      if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.response?.status === 400) {
        errorMessage = 'Cannot update profile after document submission.';
      } else if (error.response?.status === 401) {
        errorMessage = 'Please log in again to update your profile.';
      } else if (error.response?.status === 404) {
        errorMessage = 'User not found. Please log in again.';
      } else if (error.response?.status === 500) {
        errorMessage = 'Server error. Please try again later.';
      }
      
      setMessage(errorMessage);
    } finally {
      setUpdating(false);
    }
  };

  const handleChangePassword = () => {
    setPasswordData({
      currentPassword: '',
      newPassword: '',
      confirmPassword: ''
    });
    setShowChangePassword(true);
  };

  const handleSavePassword = async () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      setMessage('New passwords do not match.');
      return;
    }

    if (passwordData.newPassword.length < 6) {
      setMessage('Password must be at least 6 characters long.');
      return;
    }

    try {
      setUpdating(true);
      setMessage('');
      
      console.log('Changing password...');
      console.log('API endpoint: /UserDashboard/change-password');
      console.log('Password data:', { 
        currentPassword: '***', 
        newPassword: '***', 
        confirmPassword: '***' 
      });
      
      const response = await documentService.changePassword(passwordData);
      console.log('Password change response:', response);
      
      setMessage('Password changed successfully!');
      setShowChangePassword(false);
    } catch (error) {
      console.error('Password change error:', error);
      console.error('Error details:', {
        message: error.message,
        status: error.response?.status,
        data: error.response?.data,
        config: error.config
      });
      
      let errorMessage = 'Failed to change password. Please try again.';
      
      if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.response?.status === 400) {
        errorMessage = 'Current password is incorrect.';
      } else if (error.response?.status === 401) {
        errorMessage = 'Please log in again to change your password.';
      } else if (error.response?.status === 404) {
        errorMessage = 'User not found. Please log in again.';
      } else if (error.response?.status === 500) {
        errorMessage = 'Server error. Please try again later.';
      }
      
      setMessage(errorMessage);
    } finally {
      setUpdating(false);
    }
  };

  if (loading) {
    return (
      <div className="row justify-content-center">
        <div className="col-md-6">
          <Card className="mt-5 text-center">
            <div className="card-body">
              <div className="spinner-border text-primary" role="status">
                <span className="visually-hidden">Loading...</span>
              </div>
              <p className="mt-3">Loading your profile...</p>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid py-4">
      <div className="row">
        <div className="col-12">
          <h1 className="h2 mb-4">Welcome, {user?.fullName || 'User'}!</h1>
        </div>
      </div>

      {message && (
        <div className="row">
          <div className="col-12">
            <div className="alert alert-warning" role="alert">
              {message}
            </div>
          </div>
        </div>
      )}

      {statusUpdated && (
        <div className="row">
          <div className="col-12">
            <div className="alert alert-success alert-dismissible fade show" role="alert">
              <i className="fas fa-check-circle me-2"></i>
              <strong>Status Updated!</strong> Your document verification status has been refreshed.
              <button 
                type="button" 
                className="btn-close" 
                onClick={() => setStatusUpdated(false)}
                aria-label="Close"
              ></button>
            </div>
          </div>
        </div>
      )}

      {/* Processing Status */}
      {processingStatus && processingStatus.ProcessingStatus === 'Processing' && (
        <div className="row">
          <div className="col-12">
            <div className="alert alert-info" role="alert">
              <div className="d-flex align-items-center">
                <div className="spinner-border spinner-border-sm me-2" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
                <strong>Processing Documents...</strong>
                <span className="ms-2">Estimated completion: {processingStatus.EstimatedCompletion ? new Date(processingStatus.EstimatedCompletion).toLocaleTimeString() : 'Soon'}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Document Summary Section */}
      {documentStatus && (
        <div className="row mb-4">
          <div className="col-md-3">
            <Card title="Current Status" className="text-center">
              <div className="d-flex justify-content-between align-items-center mb-2">
                <h4 className={`text-${documentStatus.isVerified ? 'success' : 'warning'} mb-0`}>
                  {documentStatus.isVerified ? '✅ Verified' : '⏳ Pending'}
                </h4>
                <button 
                  className="btn btn-sm btn-outline-primary"
                  onClick={fetchDocumentStatus}
                  disabled={refreshing}
                  title="Refresh Status"
                >
                  {refreshing ? (
                    <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                  ) : (
                    <i className="fas fa-sync-alt"></i>
                  )}
                </button>
              </div>
              <small className="text-muted">Latest Submission</small>
            </Card>
          </div>
          <div className="col-md-3">
            <Card title="Risk Score" className="text-center">
              <h4 className={`text-${getRiskScoreColor(documentStatus.riskScore)}`}>
                {documentStatus.riskScore}/100
              </h4>
              <small className="text-muted">{getRiskScoreText(documentStatus.riskScore)}</small>
            </Card>
          </div>
          <div className="col-md-3">
            <Card title="Total Uploads" className="text-center">
              <h4 className="text-info">{uploadHistory.length}</h4>
              <small className="text-muted">Document Submissions</small>
            </Card>
          </div>
          <div className="col-md-3">
            <Card title="Last Upload" className="text-center">
              <h6 className="text-muted">
                {uploadHistory.length > 0 ? 
                  new Date(uploadHistory[0].submittedAt).toLocaleDateString() : 
                  'No uploads yet'
                }
              </h6>
              <small className="text-muted">Most Recent</small>
            </Card>
          </div>
        </div>
      )}

      {/* Document Upload Section - Always allow uploads */}
      <div className="row mb-4">
          <div className="col-12">
            <Card title="Document Upload" className="dashboard-card">
              {documentStatus?.isSubmitted && (
                <div className="alert alert-warning mb-3">
                  <strong>Second Round Submission:</strong> You are submitting new documents. 
                  Previous verification results will be reset and new verification will be processed.
                </div>
              )}
              <div className="row">
                <div className="col-md-4">
                  <div className="mb-3">
                    <label className="form-label">EC Document (PDF)</label>
                    <input 
                      type="file" 
                      className="form-control" 
                      accept=".pdf"
                      onChange={(e) => handleFileChange('EC', e.target.files[0])}
                    />
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="mb-3">
                    <label className="form-label">Aadhaar Card (PNG)</label>
                    <input 
                      type="file" 
                      className="form-control" 
                      accept=".png"
                      onChange={(e) => handleFileChange('Aadhaar', e.target.files[0])}
                    />
                    <small className="text-muted">Upload Aadhaar card as PNG image</small>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="mb-3">
                    <label className="form-label">PAN Card (PNG)</label>
                    <input 
                      type="file" 
                      className="form-control" 
                      accept=".png"
                      onChange={(e) => handleFileChange('PAN', e.target.files[0])}
                    />
                    <small className="text-muted">Upload PAN card as PNG image</small>
                  </div>
                </div>
              </div>
              <div className="text-center">
                <Button 
                  variant="primary" 
                  onClick={handleDocumentUpload}
                  disabled={uploading}
                >
                  {uploading ? 'Uploading...' : 'Upload Documents'}
                </Button>
              </div>
            </Card>
          </div>
        </div>

      {/* Document Status Section */}
      {documentStatus && (
        <div className="row mb-4">
          <div className="col-12">
            <Card 
              title={
                <div className="d-flex justify-content-between align-items-center">
                  <span>Document Verification Status</span>
                  <button 
                    className="btn btn-sm btn-outline-primary"
                    onClick={fetchDocumentStatus}
                    disabled={refreshing}
                    title="Refresh Status"
                  >
                    {refreshing ? (
                      <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                    ) : (
                      <i className="fas fa-sync-alt"></i>
                    )}
                  </button>
                </div>
              } 
              className="dashboard-card"
            >
              <div className="row">
                <div className="col-md-3">
                  <div className="text-center">
                    <h6 className="text-muted">Status</h6>
                    <span className={`badge bg-${documentStatus.isVerified ? 'success' : 'warning'}`}>
                      {documentStatus.isVerified ? 'Verified' : 'Pending'}
                    </span>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="text-center">
                    <h6 className="text-muted">Risk Score</h6>
                    <span className={`badge bg-${getRiskScoreColor(documentStatus.riskScore)}`}>
                      {documentStatus.riskScore}/100 - {getRiskScoreText(documentStatus.riskScore)}
                    </span>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="text-center">
                    <h6 className="text-muted">Submitted</h6>
                    <span className="badge bg-info">
                      {documentStatus.isSubmitted ? 'Yes' : 'No'}
                    </span>
                  </div>
                </div>
              </div>
              {documentStatus.verificationNotes && (
                <div className="mt-3">
                  <h6>Verification Notes:</h6>
                  <p className="text-muted">{documentStatus.verificationNotes}</p>
                </div>
              )}
            </Card>
          </div>
        </div>
      )}

      {/* Verification Results Section */}
      <div className="row mb-4">
        <div className="col-12">
          {refreshing && (
            <div className="alert alert-info">
              <i className="fas fa-spinner fa-spin me-2"></i>
              Refreshing document status...
            </div>
          )}
          <VerificationResults 
            documentStatus={documentStatus}
            extractedData={extractedData}
            onRefresh={fetchDocumentStatus}
          />
        </div>
      </div>

      {/* Extracted Data Section */}
      {extractedData && (
        <div className="row mb-4">
          <div className="col-12">
            <Card title="Extracted Document Data" className="dashboard-card">
              <div className="row">
                <div className="col-md-4">
                  <h6>EC Document:</h6>
                  <ul className="list-unstyled">
                    <li><strong>Name:</strong> {extractedData.name || 'N/A'}</li>
                    <li><strong>Survey No:</strong> {extractedData.surveyNumber || 'N/A'}</li>
                    <li><strong>Address:</strong> {extractedData.address || 'N/A'}</li>
                    <li><strong>Application No:</strong> {extractedData.applicationNumber || 'N/A'}</li>
                    <li><strong>Village:</strong> {extractedData.village || 'N/A'}</li>
                    <li><strong>District:</strong> {extractedData.district || 'N/A'}</li>
                  </ul>
                </div>
                <div className="col-md-4">
                  <h6>Aadhaar Card:</h6>
                  <ul className="list-unstyled">
                    <li><strong>Name:</strong> {extractedData.adhaarFullName || 'N/A'}</li>
                    <li><strong>Aadhaar No:</strong> {extractedData.aadhaarNumber || 'N/A'}</li>
                    <li><strong>DOB:</strong> {extractedData.dob || 'N/A'}</li>
                    <li><strong>Father Name:</strong> {extractedData.fatherName || 'N/A'}</li>
                    <li><strong>Mother Name:</strong> {extractedData.motherName || 'N/A'}</li>
                  </ul>
                </div>
                <div className="col-md-4">
                  <h6>PAN Card:</h6>
                  <ul className="list-unstyled">
                    <li><strong>Name:</strong> {extractedData.panFullName || 'N/A'}</li>
                    <li><strong>PAN No:</strong> {extractedData.panNumber || 'N/A'}</li>
                    <li><strong>DOB:</strong> {extractedData.dob || 'N/A'}</li>
                    <li><strong>Father Name:</strong> {extractedData.fatherName || 'N/A'}</li>
                  </ul>
                </div>
              </div>
            </Card>
          </div>
        </div>
      )}

      {/* Upload History Section */}
      {uploadHistory.length > 0 && (
        <div className="row mb-4">
          <div className="col-12">
            <Card title="Document Upload History" className="dashboard-card">
              <div className="table-responsive">
                <table className="table table-hover">
                  <thead>
                    <tr>
                      <th>Upload Date</th>
                      <th>Documents</th>
                      <th>Status</th>
                      <th>Risk Score</th>
                      <th>Verification Notes</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {uploadHistory.map((upload, index) => (
                      <tr key={upload.id || index}>
                        <td>
                          <div>
                            <strong>{new Date(upload.submittedAt).toLocaleDateString()}</strong>
                            <br />
                            <small className="text-muted">
                              {new Date(upload.submittedAt).toLocaleTimeString()}
                            </small>
                          </div>
                        </td>
                        <td>
                          <div className="d-flex flex-wrap gap-1">
                            <span className={`badge ${upload.ecPath ? 'bg-success' : 'bg-secondary'}`}>
                              EC
                            </span>
                            <span className={`badge ${upload.aadhaarPath ? 'bg-success' : 'bg-secondary'}`}>
                              Aadhaar
                            </span>
                            <span className={`badge ${upload.panPath ? 'bg-success' : 'bg-secondary'}`}>
                              PAN
                            </span>
                          </div>
                        </td>
                        <td>
                          <span className={`badge ${upload.isVerified ? 'bg-success' : 'bg-warning'}`}>
                            {upload.isVerified ? 'Verified' : 'Pending'}
                          </span>
                        </td>
                        <td>
                          <span className={`badge ${getRiskScoreColor(upload.riskScore)}`}>
                            {upload.riskScore}/100 - {getRiskScoreText(upload.riskScore)}
                          </span>
                        </td>
                        <td>
                          {upload.verificationNotes ? (
                            <small className="text-muted">{upload.verificationNotes}</small>
                          ) : (
                            <span className="text-muted">-</span>
                          )}
                        </td>
                        <td>
                          <Button 
                            variant="outline-info" 
                            size="sm"
                            onClick={() => viewUploadDetails(upload)}
                          >
                            View Details
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        </div>
      )}

      <div className="row">
        <div className="col-md-8">
          <Card title="Your Profile Information" className="dashboard-card">
            {profile ? (
              <div className="row">
                <div className="col-md-3 text-center mb-3">
                  <div className="user-avatar mx-auto">
                    {getInitials(profile.fullName)}
                  </div>
                </div>
                <div className="col-md-9">
                  <div className="row">
                    <div className="col-sm-6">
                      <h6 className="text-muted">Full Name</h6>
                      <p className="mb-3">{profile.fullName}</p>
                    </div>
                    <div className="col-sm-6">
                      <h6 className="text-muted">Email</h6>
                      <p className="mb-3">{profile.email}</p>
                    </div>
                    <div className="col-sm-6">
                      <h6 className="text-muted">Phone</h6>
                      <p className="mb-3">{profile.phone}</p>
                    </div>
                    <div className="col-sm-6">
                      <h6 className="text-muted">Role</h6>
                      <p className="mb-3">
                        <span className="badge bg-primary">{profile.role}</span>
                      </p>
                    </div>
                    <div className="col-sm-6">
                      <h6 className="text-muted">City</h6>
                      <p className="mb-3">{profile.city}</p>
                    </div>
                    <div className="col-sm-6">
                      <h6 className="text-muted">State</h6>
                      <p className="mb-3">{profile.state}</p>
                    </div>
                    <div className="col-sm-6">
                      <h6 className="text-muted">Pincode</h6>
                      <p className="mb-3">{profile.pincode}</p>
                    </div>
                    <div className="col-sm-6">
                      <h6 className="text-muted">Member Since</h6>
                      <p className="mb-3">
                        {new Date(profile.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-4">
                <p className="text-muted">No profile information available.</p>
                <Button variant="primary" onClick={fetchUserProfile}>
                  Refresh Profile
                </Button>
              </div>
            )}
          </Card>
        </div>

        <div className="col-md-4">
          <Card title="Quick Actions" className="dashboard-card">
            <div className="d-grid gap-2">
              <Button variant="outline-primary" onClick={fetchUserProfile}>
                Refresh Profile
              </Button>
              <Button variant="outline-secondary" onClick={handleEditProfile}>
                Edit Profile
              </Button>
              <Button variant="outline-info" onClick={handleChangePassword}>
                Change Password
              </Button>
            </div>
          </Card>

          <Card title="Account Status" className="dashboard-card">
            <div className="text-center">
              <div className="user-avatar mx-auto mb-3">
                {getInitials(user?.fullName || 'U')}
              </div>
              <h5>{user?.fullName || 'User'}</h5>
              <p className="text-muted">{user?.email}</p>
              <span className="badge bg-success">Active</span>
            </div>
          </Card>
        </div>
      </div>

      {/* Edit Profile Modal */}
      {showEditProfile && (
        <div className="modal show d-block" tabIndex="-1" style={{backgroundColor: 'rgba(0,0,0,0.5)'}}>
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Edit Profile</h5>
                <button type="button" className="btn-close" onClick={() => setShowEditProfile(false)}></button>
              </div>
              <div className="modal-body">
                <div className="mb-3">
                  <label className="form-label">Full Name</label>
                  <input
                    type="text"
                    className="form-control"
                    value={editProfileData.fullName}
                    onChange={(e) => setEditProfileData({...editProfileData, fullName: e.target.value})}
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Phone</label>
                  <input
                    type="text"
                    className="form-control"
                    value={editProfileData.phone}
                    onChange={(e) => setEditProfileData({...editProfileData, phone: e.target.value})}
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">City</label>
                  <input
                    type="text"
                    className="form-control"
                    value={editProfileData.city}
                    onChange={(e) => setEditProfileData({...editProfileData, city: e.target.value})}
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">State</label>
                  <input
                    type="text"
                    className="form-control"
                    value={editProfileData.state}
                    onChange={(e) => setEditProfileData({...editProfileData, state: e.target.value})}
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Pincode</label>
                  <input
                    type="text"
                    className="form-control"
                    value={editProfileData.pincode}
                    onChange={(e) => setEditProfileData({...editProfileData, pincode: e.target.value})}
                  />
                </div>
              </div>
              <div className="modal-footer">
                <Button variant="secondary" onClick={() => setShowEditProfile(false)}>
                  Cancel
                </Button>
                <Button variant="primary" onClick={handleSaveProfile} disabled={updating}>
                  {updating ? 'Saving...' : 'Save Changes'}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Change Password Modal */}
      {showChangePassword && (
        <div className="modal show d-block" tabIndex="-1" style={{backgroundColor: 'rgba(0,0,0,0.5)'}}>
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Change Password</h5>
                <button type="button" className="btn-close" onClick={() => setShowChangePassword(false)}></button>
              </div>
              <div className="modal-body">
                <div className="mb-3">
                  <label className="form-label">Current Password</label>
                  <input
                    type="password"
                    className="form-control"
                    value={passwordData.currentPassword}
                    onChange={(e) => setPasswordData({...passwordData, currentPassword: e.target.value})}
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">New Password</label>
                  <input
                    type="password"
                    className="form-control"
                    value={passwordData.newPassword}
                    onChange={(e) => setPasswordData({...passwordData, newPassword: e.target.value})}
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Confirm New Password</label>
                  <input
                    type="password"
                    className="form-control"
                    value={passwordData.confirmPassword}
                    onChange={(e) => setPasswordData({...passwordData, confirmPassword: e.target.value})}
                  />
                </div>
              </div>
              <div className="modal-footer">
                <Button variant="secondary" onClick={() => setShowChangePassword(false)}>
                  Cancel
                </Button>
                <Button variant="primary" onClick={handleSavePassword} disabled={updating}>
                  {updating ? 'Changing...' : 'Change Password'}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserDashboard;

# Document Verification System - React Frontend

A secure React application for document verification and risk assessment with AI-powered document processing.

## Features

- 🔐 **Secure Authentication** - User and Admin login with JWT tokens
- 📄 **Document Upload** - Upload EC, Aadhaar, and PAN documents
- 🤖 **AI Processing** - Automated document data extraction
- 🛡️ **Risk Assessment** - Comprehensive fraud detection and scoring
- 👥 **User Management** - Admin panel for user and document management
- 📊 **Analytics Dashboard** - Real-time statistics and insights

## Security Features

- Content Security Policy (CSP) headers
- XSS Protection
- CSRF Protection
- Secure cookie handling
- Input validation and sanitization
- HTTPS enforcement

## Technology Stack

- **Frontend**: React 18.2.0, React Router 6.20.1
- **UI Framework**: Bootstrap 5.3.2
- **HTTP Client**: Axios 1.6.2
- **Authentication**: JWT with secure cookies
- **Build Tool**: Create React App 5.0.1

## Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd react-contacts-app
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Environment Setup**
   ```bash
   cp env.example .env.local
   ```
   Edit `.env.local` with your configuration:
   ```
   REACT_APP_API_URL=https://localhost:50538/api
   REACT_APP_ENABLE_SECURITY_HEADERS=true
   REACT_APP_ENABLE_CSP=true
   ```

4. **Start development server**
   ```bash
   npm start
   ```

## Available Scripts

- `npm start` - Start development server
- `npm run build` - Build for production
- `npm test` - Run tests
- `npm run audit` - Check for security vulnerabilities
- `npm run security-check` - Run security audit
- `npm run clean` - Clean node_modules
- `npm run reinstall` - Clean and reinstall dependencies
- `npm run build-prod` - Security check + production build

## Project Structure

```
src/
├── Components/
│   ├── Auth/           # Authentication components
│   ├── Common/         # Reusable UI components
│   ├── Dashboard/      # Dashboard components
│   ├── Home/           # Home page components
│   └── Layout/         # Layout components
├── Services/           # API service layers
├── Routes/             # Routing configuration
├── config/             # Configuration files
└── App.jsx             # Main application component
```

## Security Configuration

The application includes comprehensive security measures:

- **Content Security Policy** - Prevents XSS attacks
- **Security Headers** - X-Frame-Options, X-Content-Type-Options
- **Dependency Overrides** - Force secure versions of vulnerable packages
- **Environment Variables** - Secure API configuration
- **Input Validation** - Client and server-side validation

## API Integration

The frontend integrates with a .NET Core Web API backend:

- **Base URL**: Configurable via environment variables
- **Authentication**: JWT token-based authentication
- **File Upload**: Multipart form data for document uploads
- **Error Handling**: Comprehensive error handling and user feedback

## Development

### Security Best Practices

1. **Regular Security Audits**
   ```bash
   npm run security-check
   ```

2. **Dependency Updates**
   ```bash
   npm audit fix
   ```

3. **Environment Security**
   - Never commit `.env` files
   - Use environment variables for sensitive data
   - Enable HTTPS in production

### Code Quality

- ESLint configuration for code quality
- React best practices
- Component-based architecture
- Proper error boundaries

## Production Deployment

1. **Security Check**
   ```bash
   npm run security-check
   ```

2. **Build for Production**
   ```bash
   npm run build-prod
   ```

3. **Deploy Build Folder**
   - Upload the `build/` folder to your web server
   - Configure HTTPS
   - Set up proper security headers

## Troubleshooting

### Common Issues

1. **Security Vulnerabilities**
   ```bash
   npm run audit-fix
   ```

2. **Build Failures**
   ```bash
   npm run clean
   npm install
   npm run build
   ```

3. **API Connection Issues**
   - Check environment variables
   - Verify API server is running
   - Check CORS configuration

## Contributing

1. Follow security best practices
2. Run security checks before committing
3. Update dependencies regularly
4. Test all authentication flows
5. Validate input handling

## License

This project is licensed under the MIT License.
